package transUnion.Skyfall.javaUtils;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import transUnion.Skayfall.utils.RuntimeEnvironment;

public class DataBaseUtils {
	static Logger logger = Logger.getLogger(DataBaseUtils.class);
	static  Connection connection = null;
	static Statement stmt;
	static ResultSet result;

	public static Connection getDefaultConnection() {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String strDbName = RuntimeEnvironment.getDefaultDataBaseUrl();
			String strDbUserName = ReadProjectProperties.valueOf("credentials", "dbUser");
			String strDbPassword = ReadProjectProperties.valueOf("credentials", "dbPassword");
			String strConnection = "jdbc:oracle:thin:@" + strDbName;
			DataBaseUtils.connection = DriverManager.getConnection(strConnection, strDbUserName, strDbPassword);
			if (DataBaseUtils.connection == null) {
				logger.error("No se realizo conexión a Base de Datos");
				DataBaseUtils.connection = null;
			}

		} catch (Exception e) {
			logger.error("No se realizo conexión a Base de Datos--> " + e.getMessage());
			DataBaseUtils.connection = null;
		}

		return DataBaseUtils.connection;

	}

	public static ResultSet getResultSet(String query) throws SQLException {

		try {
			//logger.info("Query--> " + query);
			DataBaseUtils.stmt = DataBaseUtils.connection.createStatement();
			DataBaseUtils.result = DataBaseUtils.stmt.executeQuery(query);
		} catch (Exception e) {
			logger.error("Error mientras se ejecutaba el query en getResultSet" + e.getMessage()+" query--> "
					+ query);
		}
		  
		return DataBaseUtils.result;
	}

	public static void closeConnection() {
		try {
			
			if(!DataBaseUtils.connection.isClosed() || DataBaseUtils.connection !=null )
				DataBaseUtils.connection.close();

		} catch (Exception ignore) {
			logger.error("Error al cerrar Conexion");
		}
	}
	
	public static void closeStatement() {
		try {
			if (DataBaseUtils.stmt != null) {
				DataBaseUtils.stmt.close();
			}
			if (DataBaseUtils.result != null) {
				DataBaseUtils.result.close();
			}

		} catch (Exception ignore) {
			logger.error("Error al cerrar Conexion");
		}
	}

	public static List<List<String>> getDataFromResultset() {
		List<String> stockList;
		List<List<String>> ejemploLista = new ArrayList<List<String>>();
		ResultSetMetaData rsmd; 
		try {
			while (DataBaseUtils.result.next()) {
				stockList = new ArrayList<>();
				rsmd = DataBaseUtils.result.getMetaData();
				
				
				for(int a=1; a<= rsmd.getColumnCount(); a++) {
					try {
						if (DataBaseUtils.result.getString(a) == null || DataBaseUtils.result.getString(a).trim().isEmpty()) {
							stockList.add(" ");
						} else {
							stockList.add(DataBaseUtils.result.getString(a));
						}
						
					} catch (Exception e) {
						logger.error("Error DataBaseUtils.result.next() --> "+ e.getMessage());
						
					}

				}
				ejemploLista.add(stockList);

			}
			closeStatement();
			
		} catch (SQLException e) {

			logger.error("Error--> DataBaseUtils.result.next2"+ e.getMessage());
			closeStatement();
			closeConnection();
			System.exit(1);
		}

		return ejemploLista;

	}

	public static void executeUpdate(String query) {

		try {
			DataBaseUtils.stmt = DataBaseUtils.connection.createStatement();
			//logger.info("Query--> " + query);
			DataBaseUtils.stmt.executeUpdate(query);
			int update = stmt.getUpdateCount();
			if (update > 0) {
				//logger.info("Se actualizo registro correctamente");
				DataBaseUtils.connection.commit();
			}

		} catch (Exception e) {
			// stmt.close();
			// connection.close();
			logger.error("Error mientras se ejecutaba el query en executeUpdate" + e.getMessage());

		}

	}

	public static String executeStoredProcedure(String query) {
		String res="";
		try {
			CallableStatement stmt = DataBaseUtils.connection.prepareCall(query);
			stmt.execute();
			res="ok";
					
		} catch (Exception e) {
			//logger.error("Error mientras se ejecutaba el query en executeStoredProcedure " + e.getMessage()+"\n Query--> "+query);
			//logger.info("Fail");
			res="Fail";
			/*try {
				DataBaseUtils.stmt.close();
				DataBaseUtils.connection.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}*/

		}
		//logger.info("OK");
return res;
	}

	private DataBaseUtils() {
		throw new IllegalStateException("Utility class");
	}

}
