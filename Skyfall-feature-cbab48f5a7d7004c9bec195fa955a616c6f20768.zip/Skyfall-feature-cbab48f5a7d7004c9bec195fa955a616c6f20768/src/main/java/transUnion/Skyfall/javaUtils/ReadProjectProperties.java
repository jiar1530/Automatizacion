package transUnion.Skyfall.javaUtils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class ReadProjectProperties {
	static Logger logger = Logger.getLogger(ReadProjectProperties.class);

	public static String valueOf(String fileName, String variable) throws IOException {

		String result = "";
		String propFileName = "";
		InputStream inputStream = null;
		Properties prop = null;
		Boolean read = false;

		try {
			propFileName = "./"+fileName+".properties";
			prop = new Properties();
			inputStream = new FileInputStream(propFileName);
			read = getStreamState(inputStream);//
			if (Boolean.TRUE.equals(read)) {
				prop.load(inputStream);
			} else {
				logger.error("Archivo de Propiedades '" + propFileName + "' no encontrado.");
				throw new FileNotFoundException("Archivo de Propiedades '" + propFileName + "' no encontrado.");
			}

			result = prop.getProperty(variable);
			if (result.isEmpty()) {
				logger.error("Error! Validar contnido de la variable " + variable + " en archivo project.properties");
				System.exit(1);
			}

		} catch (Exception e) {
			logger.info("Error leyendo el archivo project.properties. Exception--> " + e.getMessage());
			System.exit(1);
		}

		return result;
	}

	private static Boolean getStreamState(InputStream inputStream) {
		return inputStream != null;
	}

	private ReadProjectProperties() {
		throw new IllegalStateException("Utility class");
	}
}
