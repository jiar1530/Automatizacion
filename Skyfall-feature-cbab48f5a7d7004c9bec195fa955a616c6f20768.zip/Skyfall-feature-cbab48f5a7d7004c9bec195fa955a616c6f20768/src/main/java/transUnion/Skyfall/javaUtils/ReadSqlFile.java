package transUnion.Skyfall.javaUtils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class ReadSqlFile {

	static Logger logger = Logger.getLogger(ReadSqlFile.class);

	public static List<String> getAllQueriesFromFile(String strScriptSqlName) throws IOException {
		File sqlFile = new File(".\\src\\test\\resources\\SqlScripts\\" + strScriptSqlName);
		List<String> listaQueries = new ArrayList<String>();
		try (BufferedReader buffReader = new BufferedReader(
				new InputStreamReader(new BufferedInputStream(new FileInputStream(sqlFile)), "UTF-8"))) {
			String data;

			while ((data = buffReader.readLine()) != null) {
				if ((data != null || !data.isEmpty())
						&& (data.toUpperCase().startsWith("SELECT") || data.toUpperCase().startsWith("UPDATE"))) {
					listaQueries.add(data);
					logger.info("Query from File: {}" + data);
				}

			}
		}

		return listaQueries;

	}

	@SuppressWarnings("null")
	public static List<String> getQueriesFromFileByTagName(String strScriptSqlName, String strTagName)
			throws IOException {
		File sqlFile = new File(".\\src\\test\\resources\\SqlScripts\\" + strScriptSqlName);
		List<String> listaQueries = new ArrayList<String>();
		try (BufferedReader buffReader = new BufferedReader(
				new InputStreamReader(new BufferedInputStream(new FileInputStream(sqlFile)), "UTF-8"))) {
			String data;
			String contains = "";
			while ((data = buffReader.readLine()) != null) {
				try {
					contains = data.split("@")[1];
				} catch (Exception e) {
					contains="++";
				}
				if (strTagName.split("@")[1].equals(contains)) {
					try {
						data = buffReader.readLine();
						if ((data != null || !data.isEmpty())
								&& (data.toUpperCase().startsWith("SELECT") || data.toUpperCase().startsWith("UPDATE")
										|| data.toUpperCase().startsWith("INSERT") || data.toUpperCase().startsWith("BEGIN"))) {
							listaQueries.add(data);
							
						} else {
							logger.error("Error en formato de archivo");
							System.exit(1);
						}
					} catch (Exception e) {
						logger.error("Error Leyendo archivo SQL");
						System.exit(1);
					}

				}

			}
		}
		if (listaQueries.isEmpty()) {
			//logger.error("Validar archivo Sql, formato incorrecto. Lista de Queries vacia");
			System.exit(1);

		}
		//logger.info("Se finaliza lectura de Archivo " + strScriptSqlName + " exitosamente");
		return listaQueries;

	}

	private ReadSqlFile() {
		throw new IllegalStateException("Utility class");
	}

}
