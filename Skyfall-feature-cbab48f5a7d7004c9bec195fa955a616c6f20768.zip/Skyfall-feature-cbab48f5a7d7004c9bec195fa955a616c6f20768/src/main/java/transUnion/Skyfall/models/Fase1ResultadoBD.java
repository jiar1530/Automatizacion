package transUnion.Skyfall.models;

import java.text.ParseException;
import java.util.List;



public class Fase1ResultadoBD {

	
	private static String G212SF = "";
	private static String G218BF = "";
	private static String G306S = "";
	private static String PER223 = "";
	private static String RVLR09 = "";
	private static String TRD = "";
	private static String WD21 = "";
	private static String WD51 = "";
	private static String BI34S = "";
	private static String CO04SF = "";
	private static String RR21S = "";
	private static String TEL21S = "";
	private static String UL29S = "";
	private static String AGG301 = "";
	private static String AGG302 = "";
	private static String AGG303 = "";
	private static String AGG304 = "";
	private static String AGG305 = "";
	private static String AGG306 = "";
	private static String AGG307 = "";
	private static String AGG308 = "";
	private static String AGG309 = "";
	private static String AGG310 = "";
	private static String AGG311 = "";
	private static String AGG312 = "";
	private static String AGG313 = "";
	private static String AGG314 = "";
	private static String AGG315 = "";
	private static String AGG316 = "";
	private static String AGG317 = "";
	private static String AGG318 = "";
	private static String AGG319 = "";
	private static String AGG320 = "";
	private static String AGG321 = "";
	private static String AGG322 = "";
	private static String AGG323 = "";
	private static String AGG324 = "";
	private static String TRV03 = "";
	private static String UL_TRD = "";
	private static String BR27S = "";
	private static String BR29S = "";
	private static String BR34S = "";
	private static String BU09S = "";
	private static String DM214S = "";
	private static String FR34S = "";
	private static String IN34S = "";
	private static String LL09S = "";
	private static String LL30S = "";
	private static String LMD30S = "";
	private static String LS34S = "";
	private static String OF09S = "";
	private static String PT09S = "";
	private static String PT30S = "";
	private static String RR25S = "";
	private static String RT21S = "";
	private static String TEL09S = "";
	private static String AGG2401 = "";
	private static String AGG2402 = "";
	private static String AGG2403 = "";
	private static String AGG2404 = "";
	private static String AGG2405 = "";
	private static String AGG2406 = "";
	private static String AGG2407 = "";
	private static String AGG2408 = "";
	private static String AGG2409 = "";
	private static String AGG2410 = "";
	private static String AGG2411 = "";
	private static String AGG2412 = "";
	private static String AGG2413 = "";
	private static String AGG2414 = "";
	private static String AGG2415 = "";
	private static String AGG2416 = "";
	private static String AGG2417 = "";
	private static String AGG2418 = "";
	private static String AGG2419 = "";
	private static String AGG2420 = "";
	private static String AGG2421 = "";
	private static String AGG2422 = "";
	private static String AGG2423 = "";
	private static String AGG2424 = "";
	private static String BKC112 = "";
	private static String BKC225 = "";
	private static String RET13 = "";
	private static String TRV12 = "";
	private static String WD31 = "";
	private static String WD61 = "";
	private static String WD81 = "";
	private static String CT24S = "";
	private static String G410S = "";
	private static String IN01S = "";
	private static String OF06S = "";
	private static String UL34S = "";
	private static String REV14 = "";
	private static String RLE907 = "";
	private static String AT34A = "";
	private static String CA09S = "";
	private static String CA70S = "";
	private static String CT30S = "";
	private static String CT31S = "";
	private static String DM211S = "";
	private static String G220A = "";
	private static String OD34S = "";
	private static String RI06S = "";
	private static String RR24S = "";
	private static String RT24S = "";
	private static String SE09S = "";
	private static String TEL30S = "";
	private static String AGG905 = "";
	private static String AGG906 = "";
	private static String PAYMNT50 = "";
	private static String PAYMNT65 = "";
	private static String PER233 = "";
	private static String RET152 = "";
	private static String RET201 = "";
	private static String RET81 = "";
	private static String REV253 = "";
	private static String FR29S = "";
	private static String FS20S = "";
	private static String G221D = "";
	private static String LS29S = "";
	private static String LS30S = "";
	private static String PER201 = "";
	private static String CV_SCORE ="";

	
	
	public static void setDatosBD(List<String> list) throws ParseException {
		
		
		Fase1ResultadoBD.AGG2401 = list.get(0).trim();
		Fase1ResultadoBD.AGG2402 = list.get(1).trim();
		Fase1ResultadoBD.AGG2403 = list.get(2).trim();
		Fase1ResultadoBD.AGG2404 = list.get(3).trim();
		Fase1ResultadoBD.AGG2405 = list.get(4).trim();
		Fase1ResultadoBD.AGG2406 = list.get(5).trim();
		Fase1ResultadoBD.AGG2407 = list.get(6).trim();
		Fase1ResultadoBD.AGG2408 = list.get(7).trim();
		Fase1ResultadoBD.AGG2409 = list.get(8).trim();
		Fase1ResultadoBD.AGG2410 = list.get(9).trim();
		Fase1ResultadoBD.AGG2411 = list.get(10).trim();
		Fase1ResultadoBD.AGG2412 = list.get(11).trim();
		Fase1ResultadoBD.AGG2413 = list.get(12).trim();
		Fase1ResultadoBD.AGG2414 = list.get(13).trim();
		Fase1ResultadoBD.AGG2415 = list.get(14).trim();
		Fase1ResultadoBD.AGG2416 = list.get(15).trim();
		Fase1ResultadoBD.AGG2417 = list.get(16).trim();
		Fase1ResultadoBD.AGG2418 = list.get(17).trim();
		Fase1ResultadoBD.AGG2419 = list.get(18).trim();
		Fase1ResultadoBD.AGG2420 = list.get(19).trim();
		Fase1ResultadoBD.AGG2421 = list.get(20).trim();
		Fase1ResultadoBD.AGG2422 = list.get(21).trim();
		Fase1ResultadoBD.AGG2423 = list.get(22).trim();
		Fase1ResultadoBD.AGG2424 = list.get(23).trim();
		Fase1ResultadoBD.AGG301  = list.get(24).trim();
		Fase1ResultadoBD.AGG302  = list.get(25).trim();
		Fase1ResultadoBD.AGG303 = list.get(26).trim();
		Fase1ResultadoBD.AGG304 = list.get(27).trim();
		Fase1ResultadoBD.AGG305 = list.get(28).trim();
		Fase1ResultadoBD.AGG306 = list.get(29).trim();
		Fase1ResultadoBD.AGG307 = list.get(30).trim();
		Fase1ResultadoBD.AGG308 = list.get(31).trim();
		Fase1ResultadoBD.AGG309 = list.get(32).trim();
		Fase1ResultadoBD.AGG310 = list.get(33).trim();
		Fase1ResultadoBD.AGG311 = list.get(34).trim();
		Fase1ResultadoBD.AGG312 = list.get(35).trim();
		Fase1ResultadoBD.AGG313 = list.get(36).trim();
		Fase1ResultadoBD.AGG314 = list.get(37).trim();
		Fase1ResultadoBD.AGG315 = list.get(38).trim();
		Fase1ResultadoBD.AGG316 = list.get(39).trim();
		Fase1ResultadoBD.AGG317 = list.get(40).trim();
		Fase1ResultadoBD.AGG318 = list.get(41).trim();
		Fase1ResultadoBD.AGG319 = list.get(42).trim();
		Fase1ResultadoBD.AGG320 = list.get(43).trim();
		Fase1ResultadoBD.AGG321 = list.get(44).trim();
		Fase1ResultadoBD.AGG322 = list.get(45).trim();
		Fase1ResultadoBD.AGG323 = list.get(46).trim();
		Fase1ResultadoBD.AGG324 = list.get(47).trim();
		Fase1ResultadoBD.AGG905 = list.get(48).trim();
		Fase1ResultadoBD.AGG906 = list.get(49).trim();
		Fase1ResultadoBD.AT34A  = list.get(50).trim();
		Fase1ResultadoBD.BI34S  = list.get(51).trim();
		Fase1ResultadoBD.BKC112 = list.get(52).trim();
		Fase1ResultadoBD.BKC225 = list.get(53).trim();
		Fase1ResultadoBD.BR27S = list.get(54).trim();
		Fase1ResultadoBD.BR29S = list.get(55).trim();
		Fase1ResultadoBD.BR34S = list.get(56).trim();
		Fase1ResultadoBD.BU09S = list.get(57).trim();
		Fase1ResultadoBD.CA09S = list.get(58).trim();
		Fase1ResultadoBD.CA70S = list.get(59).trim();
		Fase1ResultadoBD.CO04SF = list.get(60).trim();
		Fase1ResultadoBD.CT24S = list.get(61).trim();
		Fase1ResultadoBD.CT30S = list.get(62).trim();
		Fase1ResultadoBD.CT31S = list.get(63).trim();
		Fase1ResultadoBD.DM211S = list.get(64).trim();
		Fase1ResultadoBD.DM214S = list.get(65).trim();
		Fase1ResultadoBD.FR29S = list.get(66).trim();
		Fase1ResultadoBD.FR34S = list.get(67).trim();
		Fase1ResultadoBD.FS20S = list.get(68).trim();
		Fase1ResultadoBD.G212SF = list.get(69).trim();
		Fase1ResultadoBD.G218BF = list.get(70).trim();
		Fase1ResultadoBD.G220A = list.get(71).trim();
		Fase1ResultadoBD.G221D = list.get(72).trim();
		Fase1ResultadoBD.G306S = list.get(73).trim();
		Fase1ResultadoBD.G410S = list.get(74).trim();
		Fase1ResultadoBD.IN01S = list.get(75).trim();
		Fase1ResultadoBD.IN34S = list.get(76).trim();
		Fase1ResultadoBD.LL09S = list.get(77).trim();
		Fase1ResultadoBD.LL30S = list.get(78).trim();
		Fase1ResultadoBD.LMD30S = list.get(79).trim();
		Fase1ResultadoBD.LS29S = list.get(80).trim();
		Fase1ResultadoBD.LS30S = list.get(81).trim();
		Fase1ResultadoBD.LS34S = list.get(82).trim();
		Fase1ResultadoBD.OD34S = list.get(83).trim();
		Fase1ResultadoBD.OF06S = list.get(84).trim();
		Fase1ResultadoBD.OF09S = list.get(85).trim();
		Fase1ResultadoBD.PAYMNT50 = list.get(86).trim();
		Fase1ResultadoBD.PAYMNT65 = list.get(87).trim();
		Fase1ResultadoBD.PER201 = list.get(88).trim();
		Fase1ResultadoBD.PER223 = list.get(89).trim();
		Fase1ResultadoBD.PER233 = list.get(90).trim();
		Fase1ResultadoBD.PT09S = list.get(91).trim();
		Fase1ResultadoBD.PT30S = list.get(92).trim();
		Fase1ResultadoBD.RET13 = list.get(93).trim();
		Fase1ResultadoBD.RET152 = list.get(94).trim();
		Fase1ResultadoBD.RET201 = list.get(95).trim();
		Fase1ResultadoBD.RET81 = list.get(96).trim();
		Fase1ResultadoBD.REV14 = list.get(97).trim();
		Fase1ResultadoBD.REV253 = list.get(98).trim();
		Fase1ResultadoBD.RI06S = list.get(99).trim();
		Fase1ResultadoBD.RLE907 = list.get(100).trim();
		Fase1ResultadoBD.RR21S = list.get(101).trim();
		Fase1ResultadoBD.RR24S = list.get(102).trim();
		Fase1ResultadoBD.RR25S = list.get(103).trim();
		Fase1ResultadoBD.RT21S = list.get(104).trim();
		Fase1ResultadoBD.RT24S = list.get(105).trim();
		Fase1ResultadoBD.RVLR09 = list.get(106).trim();
		Fase1ResultadoBD.SE09S = list.get(107).trim();
		Fase1ResultadoBD.TEL09S = list.get(108).trim();
		Fase1ResultadoBD.TEL21S = list.get(109).trim();
		Fase1ResultadoBD.TEL30S = list.get(110).trim();
		Fase1ResultadoBD.TRD = list.get(111).trim();
		Fase1ResultadoBD.TRV03 = list.get(112).trim();
		Fase1ResultadoBD.TRV12 = list.get(113).trim();
		Fase1ResultadoBD.UL_TRD = list.get(114).trim();
		Fase1ResultadoBD.UL29S = list.get(115).trim();
		Fase1ResultadoBD.UL34S = list.get(116).trim();
		Fase1ResultadoBD.WD21 = list.get(117).trim();
		Fase1ResultadoBD.WD31 = list.get(118).trim();
		Fase1ResultadoBD.WD51 = list.get(119).trim();
		Fase1ResultadoBD.WD61 = list.get(120).trim();
		Fase1ResultadoBD.WD81 = list.get(121).trim();
		Fase1ResultadoBD.CV_SCORE = list.get(121).trim();
		

	}

	
	public static String getCV_Score() {
		return CV_SCORE;
	}

	public static String getG212SF() {
		return G212SF;
	}




	public static String getG218BF() {
		return G218BF;
	}




	public static String getG306S() {
		return G306S;
	}




	public static String getPER223() {
		return PER223;
	}




	public static String getRVLR09() {
		return RVLR09;
	}




	public static String getTRD() {
		return TRD;
	}




	public static String getWD21() {
		return WD21;
	}




	public static String getWD51() {
		return WD51;
	}




	public static String getBI34S() {
		return BI34S;
	}




	public static String getCO04SF() {
		return CO04SF;
	}




	public static String getRR21S() {
		return RR21S;
	}




	public static String getTEL21S() {
		return TEL21S;
	}




	public static String getUL29S() {
		return UL29S;
	}




	public static String getAGG301() {
		return AGG301;
	}




	public static String getAGG302() {
		return AGG302;
	}




	public static String getAGG303() {
		return AGG303;
	}




	public static String getAGG304() {
		return AGG304;
	}




	public static String getAGG305() {
		return AGG305;
	}




	public static String getAGG306() {
		return AGG306;
	}




	public static String getAGG307() {
		return AGG307;
	}




	public static String getAGG308() {
		return AGG308;
	}




	public static String getAGG309() {
		return AGG309;
	}




	public static String getAGG310() {
		return AGG310;
	}




	public static String getAGG311() {
		return AGG311;
	}




	public static String getAGG312() {
		return AGG312;
	}




	public static String getAGG313() {
		return AGG313;
	}




	public static String getAGG314() {
		return AGG314;
	}




	public static String getAGG315() {
		return AGG315;
	}




	public static String getAGG316() {
		return AGG316;
	}




	public static String getAGG317() {
		return AGG317;
	}




	public static String getAGG318() {
		return AGG318;
	}




	public static String getAGG319() {
		return AGG319;
	}




	public static String getAGG320() {
		return AGG320;
	}




	public static String getAGG321() {
		return AGG321;
	}




	public static String getAGG322() {
		return AGG322;
	}




	public static String getAGG323() {
		return AGG323;
	}




	public static String getAGG324() {
		return AGG324;
	}




	public static String getTRV03() {
		return TRV03;
	}




	public static String getUL_TRD() {
		return UL_TRD;
	}




	public static String getBR27S() {
		return BR27S;
	}




	public static String getBR29S() {
		return BR29S;
	}




	public static String getBR34S() {
		return BR34S;
	}




	public static String getBU09S() {
		return BU09S;
	}




	public static String getDM214S() {
		return DM214S;
	}




	public static String getFR34S() {
		return FR34S;
	}




	public static String getIN34S() {
		return IN34S;
	}




	public static String getLL09S() {
		return LL09S;
	}




	public static String getLL30S() {
		return LL30S;
	}




	public static String getLMD30S() {
		return LMD30S;
	}




	public static String getLS34S() {
		return LS34S;
	}




	public static String getOF09S() {
		return OF09S;
	}




	public static String getPT09S() {
		return PT09S;
	}




	public static String getPT30S() {
		return PT30S;
	}




	public static String getRR25S() {
		return RR25S;
	}




	public static String getRT21S() {
		return RT21S;
	}




	public static String getTEL09S() {
		return TEL09S;
	}




	public static String getAGG2401() {
		return AGG2401;
	}




	public static String getAGG2402() {
		return AGG2402;
	}




	public static String getAGG2403() {
		return AGG2403;
	}




	public static String getAGG2404() {
		return AGG2404;
	}




	public static String getAGG2405() {
		return AGG2405;
	}




	public static String getAGG2406() {
		return AGG2406;
	}




	public static String getAGG2407() {
		return AGG2407;
	}




	public static String getAGG2408() {
		return AGG2408;
	}




	public static String getAGG2409() {
		return AGG2409;
	}




	public static String getAGG2410() {
		return AGG2410;
	}




	public static String getAGG2411() {
		return AGG2411;
	}




	public static String getAGG2412() {
		return AGG2412;
	}




	public static String getAGG2413() {
		return AGG2413;
	}




	public static String getAGG2414() {
		return AGG2414;
	}




	public static String getAGG2415() {
		return AGG2415;
	}




	public static String getAGG2416() {
		return AGG2416;
	}




	public static String getAGG2417() {
		return AGG2417;
	}




	public static String getAGG2418() {
		return AGG2418;
	}




	public static String getAGG2419() {
		return AGG2419;
	}




	public static String getAGG2420() {
		return AGG2420;
	}




	public static String getAGG2421() {
		return AGG2421;
	}




	public static String getAGG2422() {
		return AGG2422;
	}




	public static String getAGG2423() {
		return AGG2423;
	}




	public static String getAGG2424() {
		return AGG2424;
	}




	public static String getBKC112() {
		return BKC112;
	}




	public static String getBKC225() {
		return BKC225;
	}




	public static String getRET13() {
		return RET13;
	}




	public static String getTRV12() {
		return TRV12;
	}




	public static String getWD31() {
		return WD31;
	}




	public static String getWD61() {
		return WD61;
	}




	public static String getWD81() {
		return WD81;
	}




	public static String getCT24S() {
		return CT24S;
	}




	public static String getG410S() {
		return G410S;
	}




	public static String getIN01S() {
		return IN01S;
	}




	public static String getOF06S() {
		return OF06S;
	}




	public static String getUL34S() {
		return UL34S;
	}




	public static String getREV14() {
		return REV14;
	}




	public static String getRLE907() {
		return RLE907;
	}




	public static String getAT34A() {
		return AT34A;
	}




	public static String getCA09S() {
		return CA09S;
	}




	public static String getCA70S() {
		return CA70S;
	}




	public static String getCT30S() {
		return CT30S;
	}




	public static String getCT31S() {
		return CT31S;
	}




	public static String getDM211S() {
		return DM211S;
	}




	public static String getG220A() {
		return G220A;
	}




	public static String getOD34S() {
		return OD34S;
	}




	public static String getRI06S() {
		return RI06S;
	}




	public static String getRR24S() {
		return RR24S;
	}




	public static String getRT24S() {
		return RT24S;
	}




	public static String getSE09S() {
		return SE09S;
	}




	public static String getTEL30S() {
		return TEL30S;
	}




	public static String getAGG905() {
		return AGG905;
	}




	public static String getAGG906() {
		return AGG906;
	}




	public static String getPAYMNT50() {
		return PAYMNT50;
	}




	public static String getPAYMNT65() {
		return PAYMNT65;
	}




	public static String getPER233() {
		return PER233;
	}




	public static String getRET152() {
		return RET152;
	}




	public static String getRET201() {
		return RET201;
	}




	public static String getRET81() {
		return RET81;
	}




	public static String getREV253() {
		return REV253;
	}




	public static String getFR29S() {
		return FR29S;
	}




	public static String getFS20S() {
		return FS20S;
	}




	public static String getG221D() {
		return G221D;
	}




	public static String getLS29S() {
		return LS29S;
	}




	public static String getLS30S() {
		return LS30S;
	}




	public static String getPER201() {
		return PER201;
	}



}
