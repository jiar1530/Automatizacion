package transUnion.Skyfall.models;

import java.text.ParseException;

public class Fase2ResultadoArchivoPlano {
	//cambiar variables nuevas archivo plano
	private static String SECUENCIA = "";
	private static String AGG1101 = "";
	private static String AGG1102 = "";
	private static String AGG1103 = "";
	private static String AGG1104 = "";
	private static String AGG1105 = "";
	private static String AGG1106 = "";
	private static String AGG1107 = "";
	private static String AGG1108 = "";
	private static String AGG1109 = "";
	private static String AGG1110 = "";
	private static String AGG1111 = "";
	private static String AGG1112 = "";
	private static String AGG1113 = "";
	private static String AGG1114 = "";
	private static String AGG1115 = "";
	private static String AGG1116 = "";
	private static String AGG1117 = "";
	private static String AGG1118 = "";
	private static String AGG1119 = "";
	private static String AGG1120 = "";
	private static String AGG1121 = "";
	private static String AGG1122 = "";
	private static String AGG1123 = "";
	private static String AGG1124 = "";
	private static String AGG2401 = "";
	private static String AGG2402 = "";
	private static String AGG2403 = "";
	private static String AGG2404 = "";
	private static String AGG2405 = "";
	private static String AGG2406 = "";
	private static String AGG2407 = "";
	private static String AGG2408 = "";
	private static String AGG2409 = "";
	private static String AGG2410 = "";
	private static String AGG2411 = "";
	private static String AGG2412 = "";
	private static String AGG2413 = "";
	private static String AGG2414 = "";
	private static String AGG2415 = "";
	private static String AGG2416 = "";
	private static String AGG2417 = "";
	private static String AGG2418 = "";
	private static String AGG2419 = "";
	private static String AGG2420 = "";
	private static String AGG2421 = "";
	private static String AGG2422 = "";
	private static String AGG2423 = "";
	private static String AGG2424 = "";
	private static String AGG301 = "";
	private static String AGG302 = "";
	private static String AGG303 = "";
	private static String AGG304 = "";
	private static String AGG305 = "";
	private static String AGG306 = "";
	private static String AGG307 = "";
	private static String AGG308 = "";
	private static String AGG309 = "";
	private static String AGG310 = "";
	private static String AGG311 = "";
	private static String AGG312 = "";
	private static String AGG313 = "";
	private static String AGG314 = "";
	private static String AGG315 = "";
	private static String AGG316 = "";
	private static String AGG317 = "";
	private static String AGG318 = "";
	private static String AGG319 = "";
	private static String AGG320 = "";
	private static String AGG321 = "";
	private static String AGG322 = "";
	private static String AGG323 = "";
	private static String AGG324 = "";
	private static String AGG701 = "";
	private static String AGG702 = "";
	private static String AGG703 = "";
	private static String AGG704 = "";
	private static String AGG705 = "";
	private static String AGG706 = "";
	private static String AGG707 = "";
	private static String AGG708 = "";
	private static String AGG709 = "";
	private static String AGG710 = "";
	private static String AGG711 = "";
	private static String AGG712 = "";
	private static String AGG713 = "";
	private static String AGG714 = "";
	private static String AGG715 = "";
	private static String AGG716 = "";
	private static String AGG717 = "";
	private static String AGG718 = "";
	private static String AGG719 = "";
	private static String AGG720 = "";
	private static String AGG721 = "";
	private static String AGG722 = "";
	private static String AGG723 = "";
	private static String AGG724 = "";
	private static String AGG904 = "";
	private static String AGG905 = "";
	private static String AGG906 = "";
	private static String AGG909 = "";
	private static String AGG910 = "";
	private static String AGG911 = "";
	private static String AT31S = "";
	private static String AT34A = "";
	private static String AU21S = "";
	private static String BC01S = "";
	private static String BC20S = "";
	private static String BC21S = "";
	private static String BI20S = "";
	private static String BI21S = "";
	private static String BI29S = "";
	private static String BI32S = "";
	private static String BI34S = "";
	private static String BKC112 = "";
	private static String BKC225 = "";
	private static String BKC231 = "";
	private static String BKC232 = "";
	private static String BKC233 = "";
	private static String BKC235 = "";
	private static String BKC252 = "";
	private static String BKC253 = "";
	private static String BKC254 = "";
	private static String BKC255 = "";
	private static String BR12S = "";
	private static String BR20S = "";
	private static String BR27S = "";
	private static String BR29S = "";
	private static String BR34S = "";
	private static String BU09S = "";
	private static String BU21S = "";
	private static String BU32S = "";
	private static String CA09S = "";
	private static String CA70S = "";
	private static String CO04S = "";
	private static String CO04SF = "";
	private static String COLLECTION_TRD = "";
	private static String CT20S = "";
	private static String CT24S = "";
	private static String CT30S = "";
	private static String CT31S = "";
	private static String CT32S = "";
	private static String CV25 = "";
	private static String DM211S = "";
	private static String DM214S = "";
	private static String FI20S = "";
	private static String FI21S = "";
	private static String FI34S = "";
	private static String FMD21S = "";
	private static String FR21S = "";
	private static String FR29S = "";
	private static String FR32S = "";
	private static String FR34S = "";
	private static String FS20S = "";
	private static String FU20S = "";
	private static String FU21S = "";
	private static String FU32S = "";
	private static String FU34S = "";
	private static String G103S = "";
	private static String G209SF = "";
	private static String G211S = "";
	private static String G212SF = "";
	private static String G218BF = "";
	private static String G220A = "";
	private static String G221D = "";
	private static String G306S = "";
	private static String G410S = "";
	private static String G417S = "";
	private static String G500S = "";
	private static String G540S = "";
	private static String G547S = "";
	private static String G960S = "";
	private static String IN01S = "";
	private static String IN06S = "";
	private static String IN09S = "";
	private static String IN21S = "";
	private static String IN25S = "";
	private static String IN27S = "";
	private static String IN31S = "";
	private static String IN34S = "";
	private static String LL09S = "";
	private static String LL21S = "";
	private static String LL30S = "";
	private static String LL34S = "";
	private static String LMD21S = "";
	private static String LMD30S = "";
	private static String LMD32S = "";
	private static String LMD34S = "";
	private static String LS29S = "";
	private static String LS30S = "";
	private static String LS34S = "";
	private static String MF20S = "";
	private static String MF24S = "";
	private static String MF31S = "";
	private static String MF32S = "";
	private static String MT24S = "";
	private static String MT33S = "";
	private static String MT34B = "";
	private static String MT34S = "";
	private static String NON_FINANCIAL_TRD = "";
	private static String OD34S = "";
	private static String OF06S = "";
	private static String OF09S = "";
	private static String OF32S = "";
	private static String OF34S = "";
	private static String PAYMNT03 = "";
	private static String PAYMNT50 = "";
	private static String PAYMNT65 = "";
	private static String PER201 = "";
	private static String PER222 = "";
	private static String PER223 = "";
	private static String PER224 = "";
	private static String PER233 = "";
	private static String PT09S = "";
	private static String PT20S = "";
	private static String PT21S = "";
	private static String PT30S = "";
	private static String PT34S = "";
	private static String PUBLIC_SERVICE_TRD = "";
	private static String RE102S = "";
	private static String RE12S = "";
	private static String RE30S = "";
	private static String RE32S = "";
	private static String RET11 = "";
	private static String RET13 = "";
	private static String RET132 = "";
	private static String RET14 = "";
	private static String RET142 = "";
	private static String RET152 = "";
	private static String RET201 = "";
	private static String RET222 = "";
	private static String RET223 = "";
	private static String RET224 = "";
	private static String RET225 = "";
	private static String RET315 = "";
	private static String RET320 = "";
	private static String RET51 = "";
	private static String RET81 = "";
	private static String RET84 = "";
	private static String REV14 = "";
	private static String REV202 = "";
	private static String REV203 = "";
	private static String REV204 = "";
	private static String REV222 = "";
	private static String REV223 = "";
	private static String REV225 = "";
	private static String REV253 = "";
	private static String REV320 = "";
	private static String REVBAL01 = "";
	private static String REVBAL02 = "";
	private static String REVBAL03 = "";
	private static String REVBAL04 = "";
	private static String REVBAL05 = "";
	private static String REVBAL06 = "";
	private static String REVBAL07 = "";
	private static String REVBAL08 = "";
	private static String REVBAL09 = "";
	private static String REVBAL10 = "";
	private static String REVBAL11 = "";
	private static String REVBAL12 = "";
	private static String REVBAL13 = "";
	private static String REVBAL14 = "";
	private static String REVBAL15 = "";
	private static String REVBAL16 = "";
	private static String REVBAL17 = "";
	private static String REVBAL18 = "";
	private static String REVBAL19 = "";
	private static String REVBAL20 = "";
	private static String REVBAL21 = "";
	private static String REVBAL22 = "";
	private static String REVBAL23 = "";
	private static String REVBAL24 = "";
	private static String RI06S = "";
	private static String RI20S = "";
	private static String RI21S = "";
	private static String RI24S = "";
	private static String RI27S = "";
	private static String RI29S = "";
	private static String RI30S = "";
	private static String RI31S = "";
	private static String RI32S = "";
	private static String RLE904 = "";
	private static String RLE905 = "";
	private static String RLE907 = "";
	private static String RR102S = "";
	private static String RR201S = "";
	private static String RR21S = "";
	private static String RR24S = "";
	private static String RR25S = "";
	private static String RT06S = "";
	private static String RT201S = "";
	private static String RT21S = "";
	private static String RT24S = "";
	private static String RT31S = "";
	private static String RVLR03 = "";
	private static String RVLR06 = "";
	private static String RVLR09 = "";
	private static String S064D = "";
	private static String S209D = "";
	private static String SE09S = "";
	private static String SE21S = "";
	private static String SE34S = "";
	private static String TEL09S = "";
	private static String TEL21S = "";
	private static String TEL30S = "";
	private static String TEL31S = "";
	private static String TEL32S = "";
	private static String TRANBAL01 = "";
	private static String TRANBAL02 = "";
	private static String TRANBAL03 = "";
	private static String TRANBAL04 = "";
	private static String TRANBAL05 = "";
	private static String TRANBAL06 = "";
	private static String TRANBAL07 = "";
	private static String TRANBAL08 = "";
	private static String TRANBAL09 = "";
	private static String TRANBAL10 = "";
	private static String TRANBAL11 = "";
	private static String TRANBAL12 = "";
	private static String TRANBAL13 = "";
	private static String TRANBAL14 = "";
	private static String TRANBAL15 = "";
	private static String TRANBAL16 = "";
	private static String TRANBAL17 = "";
	private static String TRANBAL18 = "";
	private static String TRANBAL19 = "";
	private static String TRANBAL20 = "";
	private static String TRANBAL21 = "";
	private static String TRANBAL22 = "";
	private static String TRANBAL23 = "";
	private static String TRANBAL24 = "";
	private static String TRD = "";
	private static String TRV03 = "";
	private static String TRV05 = "";
	private static String TRV12 = "";
	private static String TRV14 = "";
	private static String TRV17 = "";
	private static String TRV18 = "";
	private static String UL_TRD = "";
	private static String UL01S = "";
	private static String UL06S = "";
	private static String UL21S = "";
	private static String UL25S = "";
	private static String UL29S = "";
	private static String UL30S = "";
	private static String UL32S = "";
	private static String UL34S = "";
	private static String US25S = "";
	private static String WALSHR07 = "";
	private static String WD21 = "";
	private static String WD31 = "";
	private static String WD51 = "";
	private static String WD61 = "";
	private static String WD71 = "";
	private static String WD81 = "";
	private static String CV_SCORE = "";	


	
	
	public static void setDatosArchivoPlano(String data) throws ParseException {

		Fase2ResultadoArchivoPlano.SECUENCIA	=	data.split("\\|")[0].trim();
		Fase2ResultadoArchivoPlano.AGG1101	=	data.split("\\|")[1].trim();
		Fase2ResultadoArchivoPlano.AGG1102	=	data.split("\\|")[2].trim();
		Fase2ResultadoArchivoPlano.AGG1103	=	data.split("\\|")[3].trim();
		Fase2ResultadoArchivoPlano.AGG1104	=	data.split("\\|")[4].trim();
		Fase2ResultadoArchivoPlano.AGG1105	=	data.split("\\|")[5].trim();
		Fase2ResultadoArchivoPlano.AGG1106	=	data.split("\\|")[6].trim();
		Fase2ResultadoArchivoPlano.AGG1107	=	data.split("\\|")[7].trim();
		Fase2ResultadoArchivoPlano.AGG1108	=	data.split("\\|")[8].trim();
		Fase2ResultadoArchivoPlano.AGG1109	=	data.split("\\|")[9].trim();
		Fase2ResultadoArchivoPlano.AGG1110	=	data.split("\\|")[10].trim();
		Fase2ResultadoArchivoPlano.AGG1111	=	data.split("\\|")[11].trim();
		Fase2ResultadoArchivoPlano.AGG1112	=	data.split("\\|")[12].trim();
		Fase2ResultadoArchivoPlano.AGG1113	=	data.split("\\|")[13].trim();
		Fase2ResultadoArchivoPlano.AGG1114	=	data.split("\\|")[14].trim();
		Fase2ResultadoArchivoPlano.AGG1115	=	data.split("\\|")[15].trim();
		Fase2ResultadoArchivoPlano.AGG1116	=	data.split("\\|")[16].trim();
		Fase2ResultadoArchivoPlano.AGG1117	=	data.split("\\|")[17].trim();
		Fase2ResultadoArchivoPlano.AGG1118	=	data.split("\\|")[18].trim();
		Fase2ResultadoArchivoPlano.AGG1119	=	data.split("\\|")[19].trim();
		Fase2ResultadoArchivoPlano.AGG1120	=	data.split("\\|")[20].trim();
		Fase2ResultadoArchivoPlano.AGG1121	=	data.split("\\|")[21].trim();
		Fase2ResultadoArchivoPlano.AGG1122	=	data.split("\\|")[22].trim();
		Fase2ResultadoArchivoPlano.AGG1123	=	data.split("\\|")[23].trim();
		Fase2ResultadoArchivoPlano.AGG1124	=	data.split("\\|")[24].trim();
		Fase2ResultadoArchivoPlano.AGG2401	=	data.split("\\|")[25].trim();
		Fase2ResultadoArchivoPlano.AGG2402	=	data.split("\\|")[26].trim();
		Fase2ResultadoArchivoPlano.AGG2403	=	data.split("\\|")[27].trim();
		Fase2ResultadoArchivoPlano.AGG2404	=	data.split("\\|")[28].trim();
		Fase2ResultadoArchivoPlano.AGG2405	=	data.split("\\|")[29].trim();
		Fase2ResultadoArchivoPlano.AGG2406	=	data.split("\\|")[30].trim();
		Fase2ResultadoArchivoPlano.AGG2407	=	data.split("\\|")[31].trim();
		Fase2ResultadoArchivoPlano.AGG2408	=	data.split("\\|")[32].trim();
		Fase2ResultadoArchivoPlano.AGG2409	=	data.split("\\|")[33].trim();
		Fase2ResultadoArchivoPlano.AGG2410	=	data.split("\\|")[34].trim();
		Fase2ResultadoArchivoPlano.AGG2411	=	data.split("\\|")[35].trim();
		Fase2ResultadoArchivoPlano.AGG2412	=	data.split("\\|")[36].trim();
		Fase2ResultadoArchivoPlano.AGG2413	=	data.split("\\|")[37].trim();
		Fase2ResultadoArchivoPlano.AGG2414	=	data.split("\\|")[38].trim();
		Fase2ResultadoArchivoPlano.AGG2415	=	data.split("\\|")[39].trim();
		Fase2ResultadoArchivoPlano.AGG2416	=	data.split("\\|")[40].trim();
		Fase2ResultadoArchivoPlano.AGG2417	=	data.split("\\|")[41].trim();
		Fase2ResultadoArchivoPlano.AGG2418	=	data.split("\\|")[42].trim();
		Fase2ResultadoArchivoPlano.AGG2419	=	data.split("\\|")[43].trim();
		Fase2ResultadoArchivoPlano.AGG2420	=	data.split("\\|")[44].trim();
		Fase2ResultadoArchivoPlano.AGG2421	=	data.split("\\|")[45].trim();
		Fase2ResultadoArchivoPlano.AGG2422	=	data.split("\\|")[46].trim();
		Fase2ResultadoArchivoPlano.AGG2423	=	data.split("\\|")[47].trim();
		Fase2ResultadoArchivoPlano.AGG2424	=	data.split("\\|")[48].trim();
		Fase2ResultadoArchivoPlano.AGG301	=	data.split("\\|")[49].trim();
		Fase2ResultadoArchivoPlano.AGG302	=	data.split("\\|")[50].trim();
		Fase2ResultadoArchivoPlano.AGG303	=	data.split("\\|")[51].trim();
		Fase2ResultadoArchivoPlano.AGG304	=	data.split("\\|")[52].trim();
		Fase2ResultadoArchivoPlano.AGG305	=	data.split("\\|")[53].trim();
		Fase2ResultadoArchivoPlano.AGG306	=	data.split("\\|")[54].trim();
		Fase2ResultadoArchivoPlano.AGG307	=	data.split("\\|")[55].trim();
		Fase2ResultadoArchivoPlano.AGG308	=	data.split("\\|")[56].trim();
		Fase2ResultadoArchivoPlano.AGG309	=	data.split("\\|")[57].trim();
		Fase2ResultadoArchivoPlano.AGG310	=	data.split("\\|")[58].trim();
		Fase2ResultadoArchivoPlano.AGG311	=	data.split("\\|")[59].trim();
		Fase2ResultadoArchivoPlano.AGG312	=	data.split("\\|")[60].trim();
		Fase2ResultadoArchivoPlano.AGG313	=	data.split("\\|")[61].trim();
		Fase2ResultadoArchivoPlano.AGG314	=	data.split("\\|")[62].trim();
		Fase2ResultadoArchivoPlano.AGG315	=	data.split("\\|")[63].trim();
		Fase2ResultadoArchivoPlano.AGG316	=	data.split("\\|")[64].trim();
		Fase2ResultadoArchivoPlano.AGG317	=	data.split("\\|")[65].trim();
		Fase2ResultadoArchivoPlano.AGG318	=	data.split("\\|")[66].trim();
		Fase2ResultadoArchivoPlano.AGG319	=	data.split("\\|")[67].trim();
		Fase2ResultadoArchivoPlano.AGG320	=	data.split("\\|")[68].trim();
		Fase2ResultadoArchivoPlano.AGG321	=	data.split("\\|")[69].trim();
		Fase2ResultadoArchivoPlano.AGG322	=	data.split("\\|")[70].trim();
		Fase2ResultadoArchivoPlano.AGG323	=	data.split("\\|")[71].trim();
		Fase2ResultadoArchivoPlano.AGG324	=	data.split("\\|")[72].trim();
		Fase2ResultadoArchivoPlano.AGG701	=	data.split("\\|")[73].trim();
		Fase2ResultadoArchivoPlano.AGG702	=	data.split("\\|")[74].trim();
		Fase2ResultadoArchivoPlano.AGG703	=	data.split("\\|")[75].trim();
		Fase2ResultadoArchivoPlano.AGG704	=	data.split("\\|")[76].trim();
		Fase2ResultadoArchivoPlano.AGG705	=	data.split("\\|")[77].trim();
		Fase2ResultadoArchivoPlano.AGG706	=	data.split("\\|")[78].trim();
		Fase2ResultadoArchivoPlano.AGG707	=	data.split("\\|")[79].trim();
		Fase2ResultadoArchivoPlano.AGG708	=	data.split("\\|")[80].trim();
		Fase2ResultadoArchivoPlano.AGG709	=	data.split("\\|")[81].trim();
		Fase2ResultadoArchivoPlano.AGG710	=	data.split("\\|")[82].trim();
		Fase2ResultadoArchivoPlano.AGG711	=	data.split("\\|")[83].trim();
		Fase2ResultadoArchivoPlano.AGG712	=	data.split("\\|")[84].trim();
		Fase2ResultadoArchivoPlano.AGG713	=	data.split("\\|")[85].trim();
		Fase2ResultadoArchivoPlano.AGG714	=	data.split("\\|")[86].trim();
		Fase2ResultadoArchivoPlano.AGG715	=	data.split("\\|")[87].trim();
		Fase2ResultadoArchivoPlano.AGG716	=	data.split("\\|")[88].trim();
		Fase2ResultadoArchivoPlano.AGG717	=	data.split("\\|")[89].trim();
		Fase2ResultadoArchivoPlano.AGG718	=	data.split("\\|")[90].trim();
		Fase2ResultadoArchivoPlano.AGG719	=	data.split("\\|")[91].trim();
		Fase2ResultadoArchivoPlano.AGG720	=	data.split("\\|")[92].trim();
		Fase2ResultadoArchivoPlano.AGG721	=	data.split("\\|")[93].trim();
		Fase2ResultadoArchivoPlano.AGG722	=	data.split("\\|")[94].trim();
		Fase2ResultadoArchivoPlano.AGG723	=	data.split("\\|")[95].trim();
		Fase2ResultadoArchivoPlano.AGG724	=	data.split("\\|")[96].trim();
		Fase2ResultadoArchivoPlano.AGG904	=	data.split("\\|")[97].trim();
		Fase2ResultadoArchivoPlano.AGG905	=	data.split("\\|")[98].trim();
		Fase2ResultadoArchivoPlano.AGG906	=	data.split("\\|")[99].trim();
		Fase2ResultadoArchivoPlano.AGG909	=	data.split("\\|")[100].trim();
		Fase2ResultadoArchivoPlano.AGG910	=	data.split("\\|")[101].trim();
		Fase2ResultadoArchivoPlano.AGG911	=	data.split("\\|")[102].trim();
		Fase2ResultadoArchivoPlano.AT31S	=	data.split("\\|")[103].trim();
		Fase2ResultadoArchivoPlano.AT34A	=	data.split("\\|")[104].trim();
		Fase2ResultadoArchivoPlano.AU21S	=	data.split("\\|")[105].trim();
		Fase2ResultadoArchivoPlano.BC01S	=	data.split("\\|")[106].trim();
		Fase2ResultadoArchivoPlano.BC20S	=	data.split("\\|")[107].trim();
		Fase2ResultadoArchivoPlano.BC21S	=	data.split("\\|")[108].trim();
		Fase2ResultadoArchivoPlano.BI20S	=	data.split("\\|")[109].trim();
		Fase2ResultadoArchivoPlano.BI21S	=	data.split("\\|")[110].trim();
		Fase2ResultadoArchivoPlano.BI29S	=	data.split("\\|")[111].trim();
		Fase2ResultadoArchivoPlano.BI32S	=	data.split("\\|")[112].trim();
		Fase2ResultadoArchivoPlano.BI34S	=	data.split("\\|")[113].trim();
		Fase2ResultadoArchivoPlano.BKC112	=	data.split("\\|")[114].trim();
		Fase2ResultadoArchivoPlano.BKC225	=	data.split("\\|")[115].trim();
		Fase2ResultadoArchivoPlano.BKC231	=	data.split("\\|")[116].trim();
		Fase2ResultadoArchivoPlano.BKC232	=	data.split("\\|")[117].trim();
		Fase2ResultadoArchivoPlano.BKC233	=	data.split("\\|")[118].trim();
		Fase2ResultadoArchivoPlano.BKC235	=	data.split("\\|")[119].trim();
		Fase2ResultadoArchivoPlano.BKC252	=	data.split("\\|")[120].trim();
		Fase2ResultadoArchivoPlano.BKC253	=	data.split("\\|")[121].trim();
		Fase2ResultadoArchivoPlano.BKC254	=	data.split("\\|")[122].trim();
		Fase2ResultadoArchivoPlano.BKC255	=	data.split("\\|")[123].trim();
		Fase2ResultadoArchivoPlano.BR12S	=	data.split("\\|")[124].trim();
		Fase2ResultadoArchivoPlano.BR20S	=	data.split("\\|")[125].trim();
		Fase2ResultadoArchivoPlano.BR27S	=	data.split("\\|")[126].trim();
		Fase2ResultadoArchivoPlano.BR29S	=	data.split("\\|")[127].trim();
		Fase2ResultadoArchivoPlano.BR34S	=	data.split("\\|")[128].trim();
		Fase2ResultadoArchivoPlano.BU09S	=	data.split("\\|")[129].trim();
		Fase2ResultadoArchivoPlano.BU21S	=	data.split("\\|")[130].trim();
		Fase2ResultadoArchivoPlano.BU32S	=	data.split("\\|")[131].trim();
		Fase2ResultadoArchivoPlano.CA09S	=	data.split("\\|")[132].trim();
		Fase2ResultadoArchivoPlano.CA70S	=	data.split("\\|")[133].trim();
		Fase2ResultadoArchivoPlano.CO04S	=	data.split("\\|")[134].trim();
		Fase2ResultadoArchivoPlano.CO04SF	=	data.split("\\|")[135].trim();
		Fase2ResultadoArchivoPlano.COLLECTION_TRD	=	data.split("\\|")[136].trim();
		Fase2ResultadoArchivoPlano.CT20S	=	data.split("\\|")[137].trim();
		Fase2ResultadoArchivoPlano.CT24S	=	data.split("\\|")[138].trim();
		Fase2ResultadoArchivoPlano.CT30S	=	data.split("\\|")[139].trim();
		Fase2ResultadoArchivoPlano.CT31S	=	data.split("\\|")[140].trim();
		Fase2ResultadoArchivoPlano.CT32S	=	data.split("\\|")[141].trim();
		Fase2ResultadoArchivoPlano.CV25	=	data.split("\\|")[142].trim();
		Fase2ResultadoArchivoPlano.DM211S	=	data.split("\\|")[143].trim();
		Fase2ResultadoArchivoPlano.DM214S	=	data.split("\\|")[144].trim();
		Fase2ResultadoArchivoPlano.FI20S	=	data.split("\\|")[145].trim();
		Fase2ResultadoArchivoPlano.FI21S	=	data.split("\\|")[146].trim();
		Fase2ResultadoArchivoPlano.FI34S	=	data.split("\\|")[147].trim();
		Fase2ResultadoArchivoPlano.FMD21S	=	data.split("\\|")[148].trim();
		Fase2ResultadoArchivoPlano.FR21S	=	data.split("\\|")[149].trim();
		Fase2ResultadoArchivoPlano.FR29S	=	data.split("\\|")[150].trim();
		Fase2ResultadoArchivoPlano.FR32S	=	data.split("\\|")[151].trim();
		Fase2ResultadoArchivoPlano.FR34S	=	data.split("\\|")[152].trim();
		Fase2ResultadoArchivoPlano.FS20S	=	data.split("\\|")[153].trim();
		Fase2ResultadoArchivoPlano.FU20S	=	data.split("\\|")[154].trim();
		Fase2ResultadoArchivoPlano.FU21S	=	data.split("\\|")[155].trim();
		Fase2ResultadoArchivoPlano.FU32S	=	data.split("\\|")[156].trim();
		Fase2ResultadoArchivoPlano.FU34S	=	data.split("\\|")[157].trim();
		Fase2ResultadoArchivoPlano.G103S	=	data.split("\\|")[158].trim();
		Fase2ResultadoArchivoPlano.G209SF	=	data.split("\\|")[159].trim();
		Fase2ResultadoArchivoPlano.G211S	=	data.split("\\|")[160].trim();
		Fase2ResultadoArchivoPlano.G212SF	=	data.split("\\|")[161].trim();
		Fase2ResultadoArchivoPlano.G218BF	=	data.split("\\|")[162].trim();
		Fase2ResultadoArchivoPlano.G220A	=	data.split("\\|")[163].trim();
		Fase2ResultadoArchivoPlano.G221D	=	data.split("\\|")[164].trim();
		Fase2ResultadoArchivoPlano.G306S	=	data.split("\\|")[165].trim();
		Fase2ResultadoArchivoPlano.G410S	=	data.split("\\|")[166].trim();
		Fase2ResultadoArchivoPlano.G417S	=	data.split("\\|")[167].trim();
		Fase2ResultadoArchivoPlano.G500S	=	data.split("\\|")[168].trim();
		Fase2ResultadoArchivoPlano.G540S	=	data.split("\\|")[169].trim();
		Fase2ResultadoArchivoPlano.G547S	=	data.split("\\|")[170].trim();
		Fase2ResultadoArchivoPlano.G960S	=	data.split("\\|")[171].trim();
		Fase2ResultadoArchivoPlano.IN01S	=	data.split("\\|")[172].trim();
		Fase2ResultadoArchivoPlano.IN06S	=	data.split("\\|")[173].trim();
		Fase2ResultadoArchivoPlano.IN09S	=	data.split("\\|")[174].trim();
		Fase2ResultadoArchivoPlano.IN21S	=	data.split("\\|")[175].trim();
		Fase2ResultadoArchivoPlano.IN25S	=	data.split("\\|")[176].trim();
		Fase2ResultadoArchivoPlano.IN27S	=	data.split("\\|")[177].trim();
		Fase2ResultadoArchivoPlano.IN31S	=	data.split("\\|")[178].trim();
		Fase2ResultadoArchivoPlano.IN34S	=	data.split("\\|")[179].trim();
		Fase2ResultadoArchivoPlano.LL09S	=	data.split("\\|")[180].trim();
		Fase2ResultadoArchivoPlano.LL21S	=	data.split("\\|")[181].trim();
		Fase2ResultadoArchivoPlano.LL30S	=	data.split("\\|")[182].trim();
		Fase2ResultadoArchivoPlano.LL34S	=	data.split("\\|")[183].trim();
		Fase2ResultadoArchivoPlano.LMD21S	=	data.split("\\|")[184].trim();
		Fase2ResultadoArchivoPlano.LMD30S	=	data.split("\\|")[185].trim();
		Fase2ResultadoArchivoPlano.LMD32S	=	data.split("\\|")[186].trim();
		Fase2ResultadoArchivoPlano.LMD34S	=	data.split("\\|")[187].trim();
		Fase2ResultadoArchivoPlano.LS29S	=	data.split("\\|")[188].trim();
		Fase2ResultadoArchivoPlano.LS30S	=	data.split("\\|")[189].trim();
		Fase2ResultadoArchivoPlano.LS34S	=	data.split("\\|")[190].trim();
		Fase2ResultadoArchivoPlano.MF20S	=	data.split("\\|")[191].trim();
		Fase2ResultadoArchivoPlano.MF24S	=	data.split("\\|")[192].trim();
		Fase2ResultadoArchivoPlano.MF31S	=	data.split("\\|")[193].trim();
		Fase2ResultadoArchivoPlano.MF32S	=	data.split("\\|")[194].trim();
		Fase2ResultadoArchivoPlano.MT24S	=	data.split("\\|")[195].trim();
		Fase2ResultadoArchivoPlano.MT33S	=	data.split("\\|")[196].trim();
		Fase2ResultadoArchivoPlano.MT34B	=	data.split("\\|")[197].trim();
		Fase2ResultadoArchivoPlano.MT34S	=	data.split("\\|")[198].trim();
		Fase2ResultadoArchivoPlano.NON_FINANCIAL_TRD	=	data.split("\\|")[199].trim();
		Fase2ResultadoArchivoPlano.OD34S	=	data.split("\\|")[200].trim();
		Fase2ResultadoArchivoPlano.OF06S	=	data.split("\\|")[201].trim();
		Fase2ResultadoArchivoPlano.OF09S	=	data.split("\\|")[202].trim();
		Fase2ResultadoArchivoPlano.OF32S	=	data.split("\\|")[203].trim();
		Fase2ResultadoArchivoPlano.OF34S	=	data.split("\\|")[204].trim();
		Fase2ResultadoArchivoPlano.PAYMNT03	=	data.split("\\|")[205].trim();
		Fase2ResultadoArchivoPlano.PAYMNT50	=	data.split("\\|")[206].trim();
		Fase2ResultadoArchivoPlano.PAYMNT65	=	data.split("\\|")[207].trim();
		Fase2ResultadoArchivoPlano.PER201	=	data.split("\\|")[208].trim();
		Fase2ResultadoArchivoPlano.PER222	=	data.split("\\|")[209].trim();
		Fase2ResultadoArchivoPlano.PER223	=	data.split("\\|")[210].trim();
		Fase2ResultadoArchivoPlano.PER224	=	data.split("\\|")[211].trim();
		Fase2ResultadoArchivoPlano.PER233	=	data.split("\\|")[212].trim();
		Fase2ResultadoArchivoPlano.PT09S	=	data.split("\\|")[213].trim();
		Fase2ResultadoArchivoPlano.PT20S	=	data.split("\\|")[214].trim();
		Fase2ResultadoArchivoPlano.PT21S	=	data.split("\\|")[215].trim();
		Fase2ResultadoArchivoPlano.PT30S	=	data.split("\\|")[216].trim();
		Fase2ResultadoArchivoPlano.PT34S	=	data.split("\\|")[217].trim();
		Fase2ResultadoArchivoPlano.PUBLIC_SERVICE_TRD	=	data.split("\\|")[218].trim();
		Fase2ResultadoArchivoPlano.RE102S	=	data.split("\\|")[219].trim();
		Fase2ResultadoArchivoPlano.RE12S	=	data.split("\\|")[220].trim();
		Fase2ResultadoArchivoPlano.RE30S	=	data.split("\\|")[221].trim();
		Fase2ResultadoArchivoPlano.RE32S	=	data.split("\\|")[222].trim();
		Fase2ResultadoArchivoPlano.RET11	=	data.split("\\|")[223].trim();
		Fase2ResultadoArchivoPlano.RET13	=	data.split("\\|")[224].trim();
		Fase2ResultadoArchivoPlano.RET132	=	data.split("\\|")[225].trim();
		Fase2ResultadoArchivoPlano.RET14	=	data.split("\\|")[226].trim();
		Fase2ResultadoArchivoPlano.RET142	=	data.split("\\|")[227].trim();
		Fase2ResultadoArchivoPlano.RET152	=	data.split("\\|")[228].trim();
		Fase2ResultadoArchivoPlano.RET201	=	data.split("\\|")[229].trim();
		Fase2ResultadoArchivoPlano.RET222	=	data.split("\\|")[230].trim();
		Fase2ResultadoArchivoPlano.RET223	=	data.split("\\|")[231].trim();
		Fase2ResultadoArchivoPlano.RET224	=	data.split("\\|")[232].trim();
		Fase2ResultadoArchivoPlano.RET225	=	data.split("\\|")[233].trim();
		Fase2ResultadoArchivoPlano.RET315	=	data.split("\\|")[234].trim();
		Fase2ResultadoArchivoPlano.RET320	=	data.split("\\|")[235].trim();
		Fase2ResultadoArchivoPlano.RET51	=	data.split("\\|")[236].trim();
		Fase2ResultadoArchivoPlano.RET81	=	data.split("\\|")[237].trim();
		Fase2ResultadoArchivoPlano.RET84	=	data.split("\\|")[238].trim();
		Fase2ResultadoArchivoPlano.REV14	=	data.split("\\|")[239].trim();
		Fase2ResultadoArchivoPlano.REV202	=	data.split("\\|")[240].trim();
		Fase2ResultadoArchivoPlano.REV203	=	data.split("\\|")[241].trim();
		Fase2ResultadoArchivoPlano.REV204	=	data.split("\\|")[242].trim();
		Fase2ResultadoArchivoPlano.REV222	=	data.split("\\|")[243].trim();
		Fase2ResultadoArchivoPlano.REV223	=	data.split("\\|")[244].trim();
		Fase2ResultadoArchivoPlano.REV225	=	data.split("\\|")[245].trim();
		Fase2ResultadoArchivoPlano.REV253	=	data.split("\\|")[246].trim();
		Fase2ResultadoArchivoPlano.REV320	=	data.split("\\|")[247].trim();
		Fase2ResultadoArchivoPlano.REVBAL01	=	data.split("\\|")[248].trim();
		Fase2ResultadoArchivoPlano.REVBAL02	=	data.split("\\|")[249].trim();
		Fase2ResultadoArchivoPlano.REVBAL03	=	data.split("\\|")[250].trim();
		Fase2ResultadoArchivoPlano.REVBAL04	=	data.split("\\|")[251].trim();
		Fase2ResultadoArchivoPlano.REVBAL05	=	data.split("\\|")[252].trim();
		Fase2ResultadoArchivoPlano.REVBAL06	=	data.split("\\|")[253].trim();
		Fase2ResultadoArchivoPlano.REVBAL07	=	data.split("\\|")[254].trim();
		Fase2ResultadoArchivoPlano.REVBAL08	=	data.split("\\|")[255].trim();
		Fase2ResultadoArchivoPlano.REVBAL09	=	data.split("\\|")[256].trim();
		Fase2ResultadoArchivoPlano.REVBAL10	=	data.split("\\|")[257].trim();
		Fase2ResultadoArchivoPlano.REVBAL11	=	data.split("\\|")[258].trim();
		Fase2ResultadoArchivoPlano.REVBAL12	=	data.split("\\|")[259].trim();
		Fase2ResultadoArchivoPlano.REVBAL13	=	data.split("\\|")[260].trim();
		Fase2ResultadoArchivoPlano.REVBAL14	=	data.split("\\|")[261].trim();
		Fase2ResultadoArchivoPlano.REVBAL15	=	data.split("\\|")[262].trim();
		Fase2ResultadoArchivoPlano.REVBAL16	=	data.split("\\|")[263].trim();
		Fase2ResultadoArchivoPlano.REVBAL17	=	data.split("\\|")[264].trim();
		Fase2ResultadoArchivoPlano.REVBAL18	=	data.split("\\|")[265].trim();
		Fase2ResultadoArchivoPlano.REVBAL19	=	data.split("\\|")[266].trim();
		Fase2ResultadoArchivoPlano.REVBAL20	=	data.split("\\|")[267].trim();
		Fase2ResultadoArchivoPlano.REVBAL21	=	data.split("\\|")[268].trim();
		Fase2ResultadoArchivoPlano.REVBAL22	=	data.split("\\|")[269].trim();
		Fase2ResultadoArchivoPlano.REVBAL23	=	data.split("\\|")[270].trim();
		Fase2ResultadoArchivoPlano.REVBAL24	=	data.split("\\|")[271].trim();
		Fase2ResultadoArchivoPlano.RI06S	=	data.split("\\|")[272].trim();
		Fase2ResultadoArchivoPlano.RI20S	=	data.split("\\|")[273].trim();
		Fase2ResultadoArchivoPlano.RI21S	=	data.split("\\|")[274].trim();
		Fase2ResultadoArchivoPlano.RI24S	=	data.split("\\|")[275].trim();
		Fase2ResultadoArchivoPlano.RI27S	=	data.split("\\|")[276].trim();
		Fase2ResultadoArchivoPlano.RI29S	=	data.split("\\|")[277].trim();
		Fase2ResultadoArchivoPlano.RI30S	=	data.split("\\|")[278].trim();
		Fase2ResultadoArchivoPlano.RI31S	=	data.split("\\|")[279].trim();
		Fase2ResultadoArchivoPlano.RI32S	=	data.split("\\|")[280].trim();
		Fase2ResultadoArchivoPlano.RLE904	=	data.split("\\|")[281].trim();
		Fase2ResultadoArchivoPlano.RLE905	=	data.split("\\|")[282].trim();
		Fase2ResultadoArchivoPlano.RLE907	=	data.split("\\|")[283].trim();
		Fase2ResultadoArchivoPlano.RR102S	=	data.split("\\|")[284].trim();
		Fase2ResultadoArchivoPlano.RR201S	=	data.split("\\|")[285].trim();
		Fase2ResultadoArchivoPlano.RR21S	=	data.split("\\|")[286].trim();
		Fase2ResultadoArchivoPlano.RR24S	=	data.split("\\|")[287].trim();
		Fase2ResultadoArchivoPlano.RR25S	=	data.split("\\|")[288].trim();
		Fase2ResultadoArchivoPlano.RT06S	=	data.split("\\|")[289].trim();
		Fase2ResultadoArchivoPlano.RT201S	=	data.split("\\|")[290].trim();
		Fase2ResultadoArchivoPlano.RT21S	=	data.split("\\|")[291].trim();
		Fase2ResultadoArchivoPlano.RT24S	=	data.split("\\|")[292].trim();
		Fase2ResultadoArchivoPlano.RT31S	=	data.split("\\|")[293].trim();
		Fase2ResultadoArchivoPlano.RVLR03	=	data.split("\\|")[294].trim();
		Fase2ResultadoArchivoPlano.RVLR06	=	data.split("\\|")[295].trim();
		Fase2ResultadoArchivoPlano.RVLR09	=	data.split("\\|")[296].trim();
		Fase2ResultadoArchivoPlano.S064D	=	data.split("\\|")[297].trim();
		Fase2ResultadoArchivoPlano.S209D	=	data.split("\\|")[298].trim();
		Fase2ResultadoArchivoPlano.SE09S	=	data.split("\\|")[299].trim();
		Fase2ResultadoArchivoPlano.SE21S	=	data.split("\\|")[300].trim();
		Fase2ResultadoArchivoPlano.SE34S	=	data.split("\\|")[301].trim();
		Fase2ResultadoArchivoPlano.TEL09S	=	data.split("\\|")[302].trim();
		Fase2ResultadoArchivoPlano.TEL21S	=	data.split("\\|")[303].trim();
		Fase2ResultadoArchivoPlano.TEL30S	=	data.split("\\|")[304].trim();
		Fase2ResultadoArchivoPlano.TEL31S	=	data.split("\\|")[305].trim();
		Fase2ResultadoArchivoPlano.TEL32S	=	data.split("\\|")[306].trim();
		Fase2ResultadoArchivoPlano.TRANBAL01	=	data.split("\\|")[307].trim();
		Fase2ResultadoArchivoPlano.TRANBAL02	=	data.split("\\|")[308].trim();
		Fase2ResultadoArchivoPlano.TRANBAL03	=	data.split("\\|")[309].trim();
		Fase2ResultadoArchivoPlano.TRANBAL04	=	data.split("\\|")[310].trim();
		Fase2ResultadoArchivoPlano.TRANBAL05	=	data.split("\\|")[311].trim();
		Fase2ResultadoArchivoPlano.TRANBAL06	=	data.split("\\|")[312].trim();
		Fase2ResultadoArchivoPlano.TRANBAL07	=	data.split("\\|")[313].trim();
		Fase2ResultadoArchivoPlano.TRANBAL08	=	data.split("\\|")[314].trim();
		Fase2ResultadoArchivoPlano.TRANBAL09	=	data.split("\\|")[315].trim();
		Fase2ResultadoArchivoPlano.TRANBAL10	=	data.split("\\|")[316].trim();
		Fase2ResultadoArchivoPlano.TRANBAL11	=	data.split("\\|")[317].trim();
		Fase2ResultadoArchivoPlano.TRANBAL12	=	data.split("\\|")[318].trim();
		Fase2ResultadoArchivoPlano.TRANBAL13	=	data.split("\\|")[319].trim();
		Fase2ResultadoArchivoPlano.TRANBAL14	=	data.split("\\|")[320].trim();
		Fase2ResultadoArchivoPlano.TRANBAL15	=	data.split("\\|")[321].trim();
		Fase2ResultadoArchivoPlano.TRANBAL16	=	data.split("\\|")[322].trim();
		Fase2ResultadoArchivoPlano.TRANBAL17	=	data.split("\\|")[323].trim();
		Fase2ResultadoArchivoPlano.TRANBAL18	=	data.split("\\|")[324].trim();
		Fase2ResultadoArchivoPlano.TRANBAL19	=	data.split("\\|")[325].trim();
		Fase2ResultadoArchivoPlano.TRANBAL20	=	data.split("\\|")[326].trim();
		Fase2ResultadoArchivoPlano.TRANBAL21	=	data.split("\\|")[327].trim();
		Fase2ResultadoArchivoPlano.TRANBAL22	=	data.split("\\|")[328].trim();
		Fase2ResultadoArchivoPlano.TRANBAL23	=	data.split("\\|")[329].trim();
		Fase2ResultadoArchivoPlano.TRANBAL24	=	data.split("\\|")[330].trim();
		Fase2ResultadoArchivoPlano.TRD	=	data.split("\\|")[331].trim();
		Fase2ResultadoArchivoPlano.TRV03	=	data.split("\\|")[332].trim();
		Fase2ResultadoArchivoPlano.TRV05	=	data.split("\\|")[333].trim();
		Fase2ResultadoArchivoPlano.TRV12	=	data.split("\\|")[334].trim();
		Fase2ResultadoArchivoPlano.TRV14	=	data.split("\\|")[335].trim();
		Fase2ResultadoArchivoPlano.TRV17	=	data.split("\\|")[336].trim();
		Fase2ResultadoArchivoPlano.TRV18	=	data.split("\\|")[337].trim();
		Fase2ResultadoArchivoPlano.UL_TRD	=	data.split("\\|")[338].trim();
		Fase2ResultadoArchivoPlano.UL01S	=	data.split("\\|")[339].trim();
		Fase2ResultadoArchivoPlano.UL06S	=	data.split("\\|")[340].trim();
		Fase2ResultadoArchivoPlano.UL21S	=	data.split("\\|")[341].trim();
		Fase2ResultadoArchivoPlano.UL25S	=	data.split("\\|")[342].trim();
		Fase2ResultadoArchivoPlano.UL29S	=	data.split("\\|")[343].trim();
		Fase2ResultadoArchivoPlano.UL30S	=	data.split("\\|")[344].trim();
		Fase2ResultadoArchivoPlano.UL32S	=	data.split("\\|")[345].trim();
		Fase2ResultadoArchivoPlano.UL34S	=	data.split("\\|")[346].trim();
		Fase2ResultadoArchivoPlano.US25S	=	data.split("\\|")[347].trim();
		Fase2ResultadoArchivoPlano.WALSHR07	=	data.split("\\|")[348].trim();
		Fase2ResultadoArchivoPlano.WD21	=	data.split("\\|")[349].trim();
		Fase2ResultadoArchivoPlano.WD31	=	data.split("\\|")[350].trim();
		Fase2ResultadoArchivoPlano.WD51	=	data.split("\\|")[351].trim();
		Fase2ResultadoArchivoPlano.WD61	=	data.split("\\|")[352].trim();
		Fase2ResultadoArchivoPlano.WD71	=	data.split("\\|")[353].trim();
		Fase2ResultadoArchivoPlano.WD81	=	data.split("\\|")[354].trim();
		Fase2ResultadoArchivoPlano.CV_SCORE	=	data.split("\\|")[355].trim();
	


	}
	
	public static String getSECUENCIA() {
		return Fase2ResultadoArchivoPlano.SECUENCIA;
	}

	public static String getAGG1101() {
		return Fase2ResultadoArchivoPlano.AGG1101;
	}

	public static String getAGG1102() {
		return Fase2ResultadoArchivoPlano.AGG1102;
	}

	public static String getAGG1103() {
		return Fase2ResultadoArchivoPlano.AGG1103;
	}

	public static String getAGG1104() {
		return Fase2ResultadoArchivoPlano.AGG1104;
	}

	public static String getAGG1105() {
		return Fase2ResultadoArchivoPlano.AGG1105;
	}

	public static String getAGG1106() {
		return Fase2ResultadoArchivoPlano.AGG1106;
	}

	public static String getAGG1107() {
		return Fase2ResultadoArchivoPlano.AGG1107;
	}

	public static String getAGG1108() {
		return Fase2ResultadoArchivoPlano.AGG1108;
	}

	public static String getAGG1109() {
		return Fase2ResultadoArchivoPlano.AGG1109;
	}

	public static String getAGG1110() {
		return Fase2ResultadoArchivoPlano.AGG1110;
	}

	public static String getAGG1111() {
		return Fase2ResultadoArchivoPlano.AGG1111;
	}

	public static String getAGG1112() {
		return Fase2ResultadoArchivoPlano.AGG1112;
	}

	public static String getAGG1113() {
		return Fase2ResultadoArchivoPlano.AGG1113;
	}

	public static String getAGG1114() {
		return Fase2ResultadoArchivoPlano.AGG1114;
	}

	public static String getAGG1115() {
		return Fase2ResultadoArchivoPlano.AGG1115;
	}

	public static String getAGG1116() {
		return Fase2ResultadoArchivoPlano.AGG1116;
	}

	public static String getAGG1117() {
		return Fase2ResultadoArchivoPlano.AGG1117;
	}

	public static String getAGG1118() {
		return Fase2ResultadoArchivoPlano.AGG1118;
	}

	public static String getAGG1119() {
		return Fase2ResultadoArchivoPlano.AGG1119;
	}

	public static String getAGG1120() {
		return Fase2ResultadoArchivoPlano.AGG1120;
	}

	public static String getAGG1121() {
		return Fase2ResultadoArchivoPlano.AGG1121;
	}

	public static String getAGG1122() {
		return Fase2ResultadoArchivoPlano.AGG1122;
	}

	public static String getAGG1123() {
		return Fase2ResultadoArchivoPlano.AGG1123;
	}

	public static String getAGG1124() {
		return Fase2ResultadoArchivoPlano.AGG1124;
	}

	public static String getAGG2401() {
		return Fase2ResultadoArchivoPlano.AGG2401;
	}

	public static String getAGG2402() {
		return Fase2ResultadoArchivoPlano.AGG2402;
	}

	public static String getAGG2403() {
		return Fase2ResultadoArchivoPlano.AGG2403;
	}

	public static String getAGG2404() {
		return Fase2ResultadoArchivoPlano.AGG2404;
	}

	public static String getAGG2405() {
		return Fase2ResultadoArchivoPlano.AGG2405;
	}

	public static String getAGG2406() {
		return Fase2ResultadoArchivoPlano.AGG2406;
	}

	public static String getAGG2407() {
		return Fase2ResultadoArchivoPlano.AGG2407;
	}

	public static String getAGG2408() {
		return Fase2ResultadoArchivoPlano.AGG2408;
	}

	public static String getAGG2409() {
		return Fase2ResultadoArchivoPlano.AGG2409;
	}

	public static String getAGG2410() {
		return Fase2ResultadoArchivoPlano.AGG2410;
	}

	public static String getAGG2411() {
		return Fase2ResultadoArchivoPlano.AGG2411;
	}

	public static String getAGG2412() {
		return Fase2ResultadoArchivoPlano.AGG2412;
	}

	public static String getAGG2413() {
		return Fase2ResultadoArchivoPlano.AGG2413;
	}

	public static String getAGG2414() {
		return Fase2ResultadoArchivoPlano.AGG2414;
	}

	public static String getAGG2415() {
		return Fase2ResultadoArchivoPlano.AGG2415;
	}

	public static String getAGG2416() {
		return Fase2ResultadoArchivoPlano.AGG2416;
	}

	public static String getAGG2417() {
		return Fase2ResultadoArchivoPlano.AGG2417;
	}

	public static String getAGG2418() {
		return Fase2ResultadoArchivoPlano.AGG2418;
	}

	public static String getAGG2419() {
		return Fase2ResultadoArchivoPlano.AGG2419;
	}

	public static String getAGG2420() {
		return Fase2ResultadoArchivoPlano.AGG2420;
	}

	public static String getAGG2421() {
		return Fase2ResultadoArchivoPlano.AGG2421;
	}

	public static String getAGG2422() {
		return Fase2ResultadoArchivoPlano.AGG2422;
	}

	public static String getAGG2423() {
		return Fase2ResultadoArchivoPlano.AGG2423;
	}

	public static String getAGG2424() {
		return Fase2ResultadoArchivoPlano.AGG2424;
	}

	public static String getAGG301() {
		return Fase2ResultadoArchivoPlano.AGG301;
	}

	public static String getAGG302() {
		return Fase2ResultadoArchivoPlano.AGG302;
	}

	public static String getAGG303() {
		return Fase2ResultadoArchivoPlano.AGG303;
	}

	public static String getAGG304() {
		return Fase2ResultadoArchivoPlano.AGG304;
	}

	public static String getAGG305() {
		return Fase2ResultadoArchivoPlano.AGG305;
	}

	public static String getAGG306() {
		return Fase2ResultadoArchivoPlano.AGG306;
	}

	public static String getAGG307() {
		return Fase2ResultadoArchivoPlano.AGG307;
	}

	public static String getAGG308() {
		return Fase2ResultadoArchivoPlano.AGG308;
	}

	public static String getAGG309() {
		return Fase2ResultadoArchivoPlano.AGG309;
	}

	public static String getAGG310() {
		return Fase2ResultadoArchivoPlano.AGG310;
	}

	public static String getAGG311() {
		return Fase2ResultadoArchivoPlano.AGG311;
	}

	public static String getAGG312() {
		return Fase2ResultadoArchivoPlano.AGG312;
	}

	public static String getAGG313() {
		return Fase2ResultadoArchivoPlano.AGG313;
	}

	public static String getAGG314() {
		return Fase2ResultadoArchivoPlano.AGG314;
	}

	public static String getAGG315() {
		return Fase2ResultadoArchivoPlano.AGG315;
	}

	public static String getAGG316() {
		return Fase2ResultadoArchivoPlano.AGG316;
	}

	public static String getAGG317() {
		return Fase2ResultadoArchivoPlano.AGG317;
	}

	public static String getAGG318() {
		return Fase2ResultadoArchivoPlano.AGG318;
	}

	public static String getAGG319() {
		return Fase2ResultadoArchivoPlano.AGG319;
	}

	public static String getAGG320() {
		return Fase2ResultadoArchivoPlano.AGG320;
	}

	public static String getAGG321() {
		return Fase2ResultadoArchivoPlano.AGG321;
	}

	public static String getAGG322() {
		return Fase2ResultadoArchivoPlano.AGG322;
	}

	public static String getAGG323() {
		return Fase2ResultadoArchivoPlano.AGG323;
	}

	public static String getAGG324() {
		return Fase2ResultadoArchivoPlano.AGG324;
	}

	public static String getAGG701() {
		return Fase2ResultadoArchivoPlano.AGG701;
	}

	public static String getAGG702() {
		return Fase2ResultadoArchivoPlano.AGG702;
	}

	public static String getAGG703() {
		return Fase2ResultadoArchivoPlano.AGG703;
	}

	public static String getAGG704() {
		return Fase2ResultadoArchivoPlano.AGG704;
	}

	public static String getAGG705() {
		return Fase2ResultadoArchivoPlano.AGG705;
	}

	public static String getAGG706() {
		return Fase2ResultadoArchivoPlano.AGG706;
	}

	public static String getAGG707() {
		return Fase2ResultadoArchivoPlano.AGG707;
	}

	public static String getAGG708() {
		return Fase2ResultadoArchivoPlano.AGG708;
	}

	public static String getAGG709() {
		return Fase2ResultadoArchivoPlano.AGG709;
	}

	public static String getAGG710() {
		return Fase2ResultadoArchivoPlano.AGG710;
	}

	public static String getAGG711() {
		return Fase2ResultadoArchivoPlano.AGG711;
	}

	public static String getAGG712() {
		return Fase2ResultadoArchivoPlano.AGG712;
	}

	public static String getAGG713() {
		return Fase2ResultadoArchivoPlano.AGG713;
	}

	public static String getAGG714() {
		return Fase2ResultadoArchivoPlano.AGG714;
	}

	public static String getAGG715() {
		return Fase2ResultadoArchivoPlano.AGG715;
	}

	public static String getAGG716() {
		return Fase2ResultadoArchivoPlano.AGG716;
	}

	public static String getAGG717() {
		return Fase2ResultadoArchivoPlano.AGG717;
	}

	public static String getAGG718() {
		return Fase2ResultadoArchivoPlano.AGG718;
	}

	public static String getAGG719() {
		return Fase2ResultadoArchivoPlano.AGG719;
	}

	public static String getAGG720() {
		return Fase2ResultadoArchivoPlano.AGG720;
	}

	public static String getAGG721() {
		return Fase2ResultadoArchivoPlano.AGG721;
	}

	public static String getAGG722() {
		return Fase2ResultadoArchivoPlano.AGG722;
	}

	public static String getAGG723() {
		return Fase2ResultadoArchivoPlano.AGG723;
	}

	public static String getAGG724() {
		return Fase2ResultadoArchivoPlano.AGG724;
	}

	public static String getAGG904() {
		return Fase2ResultadoArchivoPlano.AGG904;
	}

	public static String getAGG905() {
		return Fase2ResultadoArchivoPlano.AGG905;
	}

	public static String getAGG906() {
		return Fase2ResultadoArchivoPlano.AGG906;
	}

	public static String getAGG909() {
		return Fase2ResultadoArchivoPlano.AGG909;
	}

	public static String getAGG910() {
		return Fase2ResultadoArchivoPlano.AGG910;
	}

	public static String getAGG911() {
		return Fase2ResultadoArchivoPlano.AGG911;
	}

	public static String getAT31S() {
		return Fase2ResultadoArchivoPlano.AT31S;
	}

	public static String getAT34A() {
		return Fase2ResultadoArchivoPlano.AT34A;
	}

	public static String getAU21S() {
		return Fase2ResultadoArchivoPlano.AU21S;
	}

	public static String getBC01S() {
		return Fase2ResultadoArchivoPlano.BC01S;
	}

	public static String getBC20S() {
		return Fase2ResultadoArchivoPlano.BC20S;
	}

	public static String getBC21S() {
		return Fase2ResultadoArchivoPlano.BC21S;
	}

	public static String getBI20S() {
		return Fase2ResultadoArchivoPlano.BI20S;
	}

	public static String getBI21S() {
		return Fase2ResultadoArchivoPlano.BI21S;
	}

	public static String getBI29S() {
		return Fase2ResultadoArchivoPlano.BI29S;
	}

	public static String getBI32S() {
		return Fase2ResultadoArchivoPlano.BI32S;
	}

	public static String getBI34S() {
		return Fase2ResultadoArchivoPlano.BI34S;
	}

	public static String getBKC112() {
		return Fase2ResultadoArchivoPlano.BKC112;
	}

	public static String getBKC225() {
		return Fase2ResultadoArchivoPlano.BKC225;
	}

	public static String getBKC231() {
		return Fase2ResultadoArchivoPlano.BKC231;
	}

	public static String getBKC232() {
		return Fase2ResultadoArchivoPlano.BKC232;
	}

	public static String getBKC233() {
		return Fase2ResultadoArchivoPlano.BKC233;
	}

	public static String getBKC235() {
		return Fase2ResultadoArchivoPlano.BKC235;
	}

	public static String getBKC252() {
		return Fase2ResultadoArchivoPlano.BKC252;
	}

	public static String getBKC253() {
		return Fase2ResultadoArchivoPlano.BKC253;
	}

	public static String getBKC254() {
		return Fase2ResultadoArchivoPlano.BKC254;
	}

	public static String getBKC255() {
		return Fase2ResultadoArchivoPlano.BKC255;
	}

	public static String getBR12S() {
		return Fase2ResultadoArchivoPlano.BR12S;
	}

	public static String getBR20S() {
		return Fase2ResultadoArchivoPlano.BR20S;
	}

	public static String getBR27S() {
		return Fase2ResultadoArchivoPlano.BR27S;
	}

	public static String getBR29S() {
		return Fase2ResultadoArchivoPlano.BR29S;
	}

	public static String getBR34S() {
		return Fase2ResultadoArchivoPlano.BR34S;
	}

	public static String getBU09S() {
		return Fase2ResultadoArchivoPlano.BU09S;
	}

	public static String getBU21S() {
		return Fase2ResultadoArchivoPlano.BU21S;
	}

	public static String getBU32S() {
		return Fase2ResultadoArchivoPlano.BU32S;
	}

	public static String getCA09S() {
		return Fase2ResultadoArchivoPlano.CA09S;
	}

	public static String getCA70S() {
		return Fase2ResultadoArchivoPlano.CA70S;
	}

	public static String getCO04S() {
		return Fase2ResultadoArchivoPlano.CO04S;
	}

	public static String getCO04SF() {
		return Fase2ResultadoArchivoPlano.CO04SF;
	}

	public static String getCOLLECTION_TRD() {
		return Fase2ResultadoArchivoPlano.COLLECTION_TRD;
	}

	public static String getCT20S() {
		return Fase2ResultadoArchivoPlano.CT20S;
	}

	public static String getCT24S() {
		return Fase2ResultadoArchivoPlano.CT24S;
	}

	public static String getCT30S() {
		return Fase2ResultadoArchivoPlano.CT30S;
	}

	public static String getCT31S() {
		return Fase2ResultadoArchivoPlano.CT31S;
	}

	public static String getCT32S() {
		return Fase2ResultadoArchivoPlano.CT32S;
	}

	public static String getCV25() {
		return Fase2ResultadoArchivoPlano.CV25;
	}

	public static String getDM211S() {
		return Fase2ResultadoArchivoPlano.DM211S;
	}

	public static String getDM214S() {
		return Fase2ResultadoArchivoPlano.DM214S;
	}

	public static String getFI20S() {
		return Fase2ResultadoArchivoPlano.FI20S;
	}

	public static String getFI21S() {
		return Fase2ResultadoArchivoPlano.FI21S;
	}

	public static String getFI34S() {
		return Fase2ResultadoArchivoPlano.FI34S;
	}

	public static String getFMD21S() {
		return Fase2ResultadoArchivoPlano.FMD21S;
	}

	public static String getFR21S() {
		return Fase2ResultadoArchivoPlano.FR21S;
	}

	public static String getFR29S() {
		return Fase2ResultadoArchivoPlano.FR29S;
	}

	public static String getFR32S() {
		return Fase2ResultadoArchivoPlano.FR32S;
	}

	public static String getFR34S() {
		return Fase2ResultadoArchivoPlano.FR34S;
	}

	public static String getFS20S() {
		return Fase2ResultadoArchivoPlano.FS20S;
	}

	public static String getFU20S() {
		return Fase2ResultadoArchivoPlano.FU20S;
	}

	public static String getFU21S() {
		return Fase2ResultadoArchivoPlano.FU21S;
	}

	public static String getFU32S() {
		return Fase2ResultadoArchivoPlano.FU32S;
	}

	public static String getFU34S() {
		return Fase2ResultadoArchivoPlano.FU34S;
	}

	public static String getG103S() {
		return Fase2ResultadoArchivoPlano.G103S;
	}

	public static String getG209SF() {
		return Fase2ResultadoArchivoPlano.G209SF;
	}

	public static String getG211S() {
		return Fase2ResultadoArchivoPlano.G211S;
	}

	public static String getG212SF() {
		return Fase2ResultadoArchivoPlano.G212SF;
	}

	public static String getG218BF() {
		return Fase2ResultadoArchivoPlano.G218BF;
	}

	public static String getG220A() {
		return Fase2ResultadoArchivoPlano.G220A;
	}

	public static String getG221D() {
		return Fase2ResultadoArchivoPlano.G221D;
	}

	public static String getG306S() {
		return Fase2ResultadoArchivoPlano.G306S;
	}

	public static String getG410S() {
		return Fase2ResultadoArchivoPlano.G410S;
	}

	public static String getG417S() {
		return Fase2ResultadoArchivoPlano.G417S;
	}

	public static String getG500S() {
		return Fase2ResultadoArchivoPlano.G500S;
	}

	public static String getG540S() {
		return Fase2ResultadoArchivoPlano.G540S;
	}

	public static String getG547S() {
		return Fase2ResultadoArchivoPlano.G547S;
	}

	public static String getG960S() {
		return Fase2ResultadoArchivoPlano.G960S;
	}

	public static String getIN01S() {
		return Fase2ResultadoArchivoPlano.IN01S;
	}

	public static String getIN06S() {
		return Fase2ResultadoArchivoPlano.IN06S;
	}

	public static String getIN09S() {
		return Fase2ResultadoArchivoPlano.IN09S;
	}

	public static String getIN21S() {
		return Fase2ResultadoArchivoPlano.IN21S;
	}

	public static String getIN25S() {
		return Fase2ResultadoArchivoPlano.IN25S;
	}

	public static String getIN27S() {
		return Fase2ResultadoArchivoPlano.IN27S;
	}

	public static String getIN31S() {
		return Fase2ResultadoArchivoPlano.IN31S;
	}

	public static String getIN34S() {
		return Fase2ResultadoArchivoPlano.IN34S;
	}

	public static String getLL09S() {
		return Fase2ResultadoArchivoPlano.LL09S;
	}

	public static String getLL21S() {
		return Fase2ResultadoArchivoPlano.LL21S;
	}

	public static String getLL30S() {
		return Fase2ResultadoArchivoPlano.LL30S;
	}

	public static String getLL34S() {
		return Fase2ResultadoArchivoPlano.LL34S;
	}

	public static String getLMD21S() {
		return Fase2ResultadoArchivoPlano.LMD21S;
	}

	public static String getLMD30S() {
		return Fase2ResultadoArchivoPlano.LMD30S;
	}

	public static String getLMD32S() {
		return Fase2ResultadoArchivoPlano.LMD32S;
	}

	public static String getLMD34S() {
		return Fase2ResultadoArchivoPlano.LMD34S;
	}

	public static String getLS29S() {
		return Fase2ResultadoArchivoPlano.LS29S;
	}

	public static String getLS30S() {
		return Fase2ResultadoArchivoPlano.LS30S;
	}

	public static String getLS34S() {
		return Fase2ResultadoArchivoPlano.LS34S;
	}

	public static String getMF20S() {
		return Fase2ResultadoArchivoPlano.MF20S;
	}

	public static String getMF24S() {
		return Fase2ResultadoArchivoPlano.MF24S;
	}

	public static String getMF31S() {
		return Fase2ResultadoArchivoPlano.MF31S;
	}

	public static String getMF32S() {
		return Fase2ResultadoArchivoPlano.MF32S;
	}

	public static String getMT24S() {
		return Fase2ResultadoArchivoPlano.MT24S;
	}

	public static String getMT33S() {
		return Fase2ResultadoArchivoPlano.MT33S;
	}

	public static String getMT34B() {
		return Fase2ResultadoArchivoPlano.MT34B;
	}

	public static String getMT34S() {
		return Fase2ResultadoArchivoPlano.MT34S;
	}

	public static String getNON_FINANCIAL_TRD() {
		return Fase2ResultadoArchivoPlano.NON_FINANCIAL_TRD;
	}

	public static String getOD34S() {
		return Fase2ResultadoArchivoPlano.OD34S;
	}

	public static String getOF06S() {
		return Fase2ResultadoArchivoPlano.OF06S;
	}

	public static String getOF09S() {
		return Fase2ResultadoArchivoPlano.OF09S;
	}

	public static String getOF32S() {
		return Fase2ResultadoArchivoPlano.OF32S;
	}

	public static String getOF34S() {
		return Fase2ResultadoArchivoPlano.OF34S;
	}

	public static String getPAYMNT03() {
		return Fase2ResultadoArchivoPlano.PAYMNT03;
	}

	public static String getPAYMNT50() {
		return Fase2ResultadoArchivoPlano.PAYMNT50;
	}

	public static String getPAYMNT65() {
		return Fase2ResultadoArchivoPlano.PAYMNT65;
	}

	public static String getPER201() {
		return Fase2ResultadoArchivoPlano.PER201;
	}

	public static String getPER222() {
		return Fase2ResultadoArchivoPlano.PER222;
	}

	public static String getPER223() {
		return Fase2ResultadoArchivoPlano.PER223;
	}

	public static String getPER224() {
		return Fase2ResultadoArchivoPlano.PER224;
	}

	public static String getPER233() {
		return Fase2ResultadoArchivoPlano.PER233;
	}

	public static String getPT09S() {
		return Fase2ResultadoArchivoPlano.PT09S;
	}

	public static String getPT20S() {
		return Fase2ResultadoArchivoPlano.PT20S;
	}

	public static String getPT21S() {
		return Fase2ResultadoArchivoPlano.PT21S;
	}

	public static String getPT30S() {
		return Fase2ResultadoArchivoPlano.PT30S;
	}

	public static String getPT34S() {
		return Fase2ResultadoArchivoPlano.PT34S;
	}

	public static String getPUBLIC_SERVICE_TRD() {
		return Fase2ResultadoArchivoPlano.PUBLIC_SERVICE_TRD;
	}

	public static String getRE102S() {
		return Fase2ResultadoArchivoPlano.RE102S;
	}

	public static String getRE12S() {
		return Fase2ResultadoArchivoPlano.RE12S;
	}

	public static String getRE30S() {
		return Fase2ResultadoArchivoPlano.RE30S;
	}

	public static String getRE32S() {
		return Fase2ResultadoArchivoPlano.RE32S;
	}

	public static String getRET11() {
		return Fase2ResultadoArchivoPlano.RET11;
	}

	public static String getRET13() {
		return Fase2ResultadoArchivoPlano.RET13;
	}

	public static String getRET132() {
		return Fase2ResultadoArchivoPlano.RET132;
	}

	public static String getRET14() {
		return Fase2ResultadoArchivoPlano.RET14;
	}

	public static String getRET142() {
		return Fase2ResultadoArchivoPlano.RET142;
	}

	public static String getRET152() {
		return Fase2ResultadoArchivoPlano.RET152;
	}

	public static String getRET201() {
		return Fase2ResultadoArchivoPlano.RET201;
	}

	public static String getRET222() {
		return Fase2ResultadoArchivoPlano.RET222;
	}

	public static String getRET223() {
		return Fase2ResultadoArchivoPlano.RET223;
	}

	public static String getRET224() {
		return Fase2ResultadoArchivoPlano.RET224;
	}

	public static String getRET225() {
		return Fase2ResultadoArchivoPlano.RET225;
	}

	public static String getRET315() {
		return Fase2ResultadoArchivoPlano.RET315;
	}

	public static String getRET320() {
		return Fase2ResultadoArchivoPlano.RET320;
	}

	public static String getRET51() {
		return Fase2ResultadoArchivoPlano.RET51;
	}

	public static String getRET81() {
		return Fase2ResultadoArchivoPlano.RET81;
	}

	public static String getRET84() {
		return Fase2ResultadoArchivoPlano.RET84;
	}

	public static String getREV14() {
		return Fase2ResultadoArchivoPlano.REV14;
	}

	public static String getREV202() {
		return Fase2ResultadoArchivoPlano.REV202;
	}

	public static String getREV203() {
		return Fase2ResultadoArchivoPlano.REV203;
	}

	public static String getREV204() {
		return Fase2ResultadoArchivoPlano.REV204;
	}

	public static String getREV222() {
		return Fase2ResultadoArchivoPlano.REV222;
	}

	public static String getREV223() {
		return Fase2ResultadoArchivoPlano.REV223;
	}

	public static String getREV225() {
		return Fase2ResultadoArchivoPlano.REV225;
	}

	public static String getREV253() {
		return Fase2ResultadoArchivoPlano.REV253;
	}

	public static String getREV320() {
		return Fase2ResultadoArchivoPlano.REV320;
	}

	public static String getREVBAL01() {
		return Fase2ResultadoArchivoPlano.REVBAL01;
	}

	public static String getREVBAL02() {
		return Fase2ResultadoArchivoPlano.REVBAL02;
	}

	public static String getREVBAL03() {
		return Fase2ResultadoArchivoPlano.REVBAL03;
	}

	public static String getREVBAL04() {
		return Fase2ResultadoArchivoPlano.REVBAL04;
	}

	public static String getREVBAL05() {
		return Fase2ResultadoArchivoPlano.REVBAL05;
	}

	public static String getREVBAL06() {
		return Fase2ResultadoArchivoPlano.REVBAL06;
	}

	public static String getREVBAL07() {
		return Fase2ResultadoArchivoPlano.REVBAL07;
	}

	public static String getREVBAL08() {
		return Fase2ResultadoArchivoPlano.REVBAL08;
	}

	public static String getREVBAL09() {
		return Fase2ResultadoArchivoPlano.REVBAL09;
	}

	public static String getREVBAL10() {
		return Fase2ResultadoArchivoPlano.REVBAL10;
	}

	public static String getREVBAL11() {
		return Fase2ResultadoArchivoPlano.REVBAL11;
	}

	public static String getREVBAL12() {
		return Fase2ResultadoArchivoPlano.REVBAL12;
	}

	public static String getREVBAL13() {
		return Fase2ResultadoArchivoPlano.REVBAL13;
	}

	public static String getREVBAL14() {
		return Fase2ResultadoArchivoPlano.REVBAL14;
	}

	public static String getREVBAL15() {
		return Fase2ResultadoArchivoPlano.REVBAL15;
	}

	public static String getREVBAL16() {
		return Fase2ResultadoArchivoPlano.REVBAL16;
	}

	public static String getREVBAL17() {
		return Fase2ResultadoArchivoPlano.REVBAL17;
	}

	public static String getREVBAL18() {
		return Fase2ResultadoArchivoPlano.REVBAL18;
	}

	public static String getREVBAL19() {
		return Fase2ResultadoArchivoPlano.REVBAL19;
	}

	public static String getREVBAL20() {
		return Fase2ResultadoArchivoPlano.REVBAL20;
	}

	public static String getREVBAL21() {
		return Fase2ResultadoArchivoPlano.REVBAL21;
	}

	public static String getREVBAL22() {
		return Fase2ResultadoArchivoPlano.REVBAL22;
	}

	public static String getREVBAL23() {
		return Fase2ResultadoArchivoPlano.REVBAL23;
	}

	public static String getREVBAL24() {
		return Fase2ResultadoArchivoPlano.REVBAL24;
	}

	public static String getRI06S() {
		return Fase2ResultadoArchivoPlano.RI06S;
	}

	public static String getRI20S() {
		return Fase2ResultadoArchivoPlano.RI20S;
	}

	public static String getRI21S() {
		return Fase2ResultadoArchivoPlano.RI21S;
	}

	public static String getRI24S() {
		return Fase2ResultadoArchivoPlano.RI24S;
	}

	public static String getRI27S() {
		return Fase2ResultadoArchivoPlano.RI27S;
	}

	public static String getRI29S() {
		return Fase2ResultadoArchivoPlano.RI29S;
	}

	public static String getRI30S() {
		return Fase2ResultadoArchivoPlano.RI30S;
	}

	public static String getRI31S() {
		return Fase2ResultadoArchivoPlano.RI31S;
	}

	public static String getRI32S() {
		return Fase2ResultadoArchivoPlano.RI32S;
	}

	public static String getRLE904() {
		return Fase2ResultadoArchivoPlano.RLE904;
	}

	public static String getRLE905() {
		return Fase2ResultadoArchivoPlano.RLE905;
	}

	public static String getRLE907() {
		return Fase2ResultadoArchivoPlano.RLE907;
	}

	public static String getRR102S() {
		return Fase2ResultadoArchivoPlano.RR102S;
	}

	public static String getRR201S() {
		return Fase2ResultadoArchivoPlano.RR201S;
	}

	public static String getRR21S() {
		return Fase2ResultadoArchivoPlano.RR21S;
	}

	public static String getRR24S() {
		return Fase2ResultadoArchivoPlano.RR24S;
	}

	public static String getRR25S() {
		return Fase2ResultadoArchivoPlano.RR25S;
	}

	public static String getRT06S() {
		return Fase2ResultadoArchivoPlano.RT06S;
	}

	public static String getRT201S() {
		return Fase2ResultadoArchivoPlano.RT201S;
	}

	public static String getRT21S() {
		return Fase2ResultadoArchivoPlano.RT21S;
	}

	public static String getRT24S() {
		return Fase2ResultadoArchivoPlano.RT24S;
	}

	public static String getRT31S() {
		return Fase2ResultadoArchivoPlano.RT31S;
	}

	public static String getRVLR03() {
		return Fase2ResultadoArchivoPlano.RVLR03;
	}

	public static String getRVLR06() {
		return Fase2ResultadoArchivoPlano.RVLR06;
	}

	public static String getRVLR09() {
		return Fase2ResultadoArchivoPlano.RVLR09;
	}

	public static String getS064D() {
		return Fase2ResultadoArchivoPlano.S064D;
	}

	public static String getS209D() {
		return Fase2ResultadoArchivoPlano.S209D;
	}

	public static String getSE09S() {
		return Fase2ResultadoArchivoPlano.SE09S;
	}

	public static String getSE21S() {
		return Fase2ResultadoArchivoPlano.SE21S;
	}

	public static String getSE34S() {
		return Fase2ResultadoArchivoPlano.SE34S;
	}

	public static String getTEL09S() {
		return Fase2ResultadoArchivoPlano.TEL09S;
	}

	public static String getTEL21S() {
		return Fase2ResultadoArchivoPlano.TEL21S;
	}

	public static String getTEL30S() {
		return Fase2ResultadoArchivoPlano.TEL30S;
	}

	public static String getTEL31S() {
		return Fase2ResultadoArchivoPlano.TEL31S;
	}

	public static String getTEL32S() {
		return Fase2ResultadoArchivoPlano.TEL32S;
	}

	public static String getTRANBAL01() {
		return Fase2ResultadoArchivoPlano.TRANBAL01;
	}

	public static String getTRANBAL02() {
		return Fase2ResultadoArchivoPlano.TRANBAL02;
	}

	public static String getTRANBAL03() {
		return Fase2ResultadoArchivoPlano.TRANBAL03;
	}

	public static String getTRANBAL04() {
		return Fase2ResultadoArchivoPlano.TRANBAL04;
	}

	public static String getTRANBAL05() {
		return Fase2ResultadoArchivoPlano.TRANBAL05;
	}

	public static String getTRANBAL06() {
		return Fase2ResultadoArchivoPlano.TRANBAL06;
	}

	public static String getTRANBAL07() {
		return Fase2ResultadoArchivoPlano.TRANBAL07;
	}

	public static String getTRANBAL08() {
		return Fase2ResultadoArchivoPlano.TRANBAL08;
	}

	public static String getTRANBAL09() {
		return Fase2ResultadoArchivoPlano.TRANBAL09;
	}

	public static String getTRANBAL10() {
		return Fase2ResultadoArchivoPlano.TRANBAL10;
	}

	public static String getTRANBAL11() {
		return Fase2ResultadoArchivoPlano.TRANBAL11;
	}

	public static String getTRANBAL12() {
		return Fase2ResultadoArchivoPlano.TRANBAL12;
	}

	public static String getTRANBAL13() {
		return Fase2ResultadoArchivoPlano.TRANBAL13;
	}

	public static String getTRANBAL14() {
		return Fase2ResultadoArchivoPlano.TRANBAL14;
	}

	public static String getTRANBAL15() {
		return Fase2ResultadoArchivoPlano.TRANBAL15;
	}

	public static String getTRANBAL16() {
		return Fase2ResultadoArchivoPlano.TRANBAL16;
	}

	public static String getTRANBAL17() {
		return Fase2ResultadoArchivoPlano.TRANBAL17;
	}

	public static String getTRANBAL18() {
		return Fase2ResultadoArchivoPlano.TRANBAL18;
	}

	public static String getTRANBAL19() {
		return Fase2ResultadoArchivoPlano.TRANBAL19;
	}

	public static String getTRANBAL20() {
		return Fase2ResultadoArchivoPlano.TRANBAL20;
	}

	public static String getTRANBAL21() {
		return Fase2ResultadoArchivoPlano.TRANBAL21;
	}

	public static String getTRANBAL22() {
		return Fase2ResultadoArchivoPlano.TRANBAL22;
	}

	public static String getTRANBAL23() {
		return Fase2ResultadoArchivoPlano.TRANBAL23;
	}

	public static String getTRANBAL24() {
		return Fase2ResultadoArchivoPlano.TRANBAL24;
	}

	public static String getTRD() {
		return Fase2ResultadoArchivoPlano.TRD;
	}

	public static String getTRV03() {
		return Fase2ResultadoArchivoPlano.TRV03;
	}

	public static String getTRV05() {
		return Fase2ResultadoArchivoPlano.TRV05;
	}

	public static String getTRV12() {
		return Fase2ResultadoArchivoPlano.TRV12;
	}

	public static String getTRV14() {
		return Fase2ResultadoArchivoPlano.TRV14;
	}

	public static String getTRV17() {
		return Fase2ResultadoArchivoPlano.TRV17;
	}

	public static String getTRV18() {
		return Fase2ResultadoArchivoPlano.TRV18;
	}

	public static String getUL_TRD() {
		return Fase2ResultadoArchivoPlano.UL_TRD;
	}

	public static String getUL01S() {
		return Fase2ResultadoArchivoPlano.UL01S;
	}

	public static String getUL06S() {
		return Fase2ResultadoArchivoPlano.UL06S;
	}

	public static String getUL21S() {
		return Fase2ResultadoArchivoPlano.UL21S;
	}

	public static String getUL25S() {
		return Fase2ResultadoArchivoPlano.UL25S;
	}

	public static String getUL29S() {
		return Fase2ResultadoArchivoPlano.UL29S;
	}

	public static String getUL30S() {
		return Fase2ResultadoArchivoPlano.UL30S;
	}

	public static String getUL32S() {
		return Fase2ResultadoArchivoPlano.UL32S;
	}

	public static String getUL34S() {
		return Fase2ResultadoArchivoPlano.UL34S;
	}

	public static String getUS25S() {
		return Fase2ResultadoArchivoPlano.US25S;
	}

	public static String getWALSHR07() {
		return Fase2ResultadoArchivoPlano.WALSHR07;
	}

	public static String getWD21() {
		return Fase2ResultadoArchivoPlano.WD21;
	}

	public static String getWD31() {
		return Fase2ResultadoArchivoPlano.WD31;
	}

	public static String getWD51() {
		return Fase2ResultadoArchivoPlano.WD51;
	}

	public static String getWD61() {
		return Fase2ResultadoArchivoPlano.WD61;
	}

	public static String getWD71() {
		return Fase2ResultadoArchivoPlano.WD71;
	}

	public static String getWD81() {
		return Fase2ResultadoArchivoPlano.WD81;
	}

	public static String getCV_SCORE() {
		return Fase2ResultadoArchivoPlano.CV_SCORE;
	}

}


