package transUnion.Skyfall.models;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;







public class Fase3ResultadoBD {
	
	private static String SECUENCIA_TERCERO = "";
	private static String AGG_SCR_SF = "";
	private static String AGG_SCR_SR = "";
	private static String AGG2402 = "";
	private static String AGG2403 = "";
	private static String AGG2404 = "";
	private static String AGG2405 = "";
	private static String AGG2406 = "";
	private static String AGG2407 = "";
	private static String AGG2408 = "";
	private static String AGG2409 = "";
	private static String AGG2410 = "";
	private static String AGG2411 = "";
	private static String AGG2412 = "";
	private static String AGG2413 = "";
	private static String AGG2414 = "";
	private static String AGG2415 = "";
	private static String AGG2416 = "";
	private static String AGG2417 = "";
	private static String AGG2418 = "";
	private static String AGG2419 = "";
	private static String AGG2420 = "";
	private static String AGG2421 = "";
	private static String AGG2422 = "";
	private static String AGG2423 = "";
	private static String AGG2424 = "";
	private static String AGG301 = "";
	private static String AGG302 = "";
	private static String AGG303 = "";
	private static String AGG304 = "";
	private static String AGG305 = "";
	private static String AGG306 = "";
	private static String AGG307 = "";
	private static String AGG308 = "";
	private static String AGG309 = "";
	private static String AGG310 = "";
	private static String AGG311 = "";
	private static String AGG312 = "";
	private static String AGG313 = "";
	private static String AGG314 = "";
	private static String AGG315 = "";
	private static String AGG316 = "";
	private static String AGG317 = "";
	private static String AGG318 = "";
	private static String AGG319 = "";
	private static String AGG320 = "";
	private static String AGG321 = "";
	private static String AGG322 = "";
	private static String AGG323 = "";
	private static String AGG324 = "";
	private static String AGG905 = "";
	private static String AGG906 = "";
	private static String AT34A = "";
	private static String BI34S = "";
	private static String BKC112 = "";
	private static String BKC225 = "";
	private static String BR20S = "";
	private static String BR27S = "";
	private static String BR29S = "";
	private static String BR34S = "";
	private static String BU09S = "";
	private static String CA09S = "";
	private static String CA70S = "";
	private static String CO04SF = "";
	private static String CREDITVISION = "";
	private static String CREDITVISION_LINK = "";
	private static String CV_LINK_SERVICIOS_FIN = "";
	private static String CT24S = "";
	private static String CT30S = "";
	private static String CT31S = "";
	private static String DM211S = "";
	private static String DM214S = "";
	private static String FECHA_CORTE_INFO ="";
	private static String FECHA_CALIFICACION = "";

	private static String FR29S = "";
	private static String FR34S = "";
	private static String FS20S = "";
	private static String FU21S = "";
	private static String G212SF = "";
	private static String G218BF = "";
	private static String G220A = "";
	private static String G221D = "";
	private static String G306S = "";
	private static String G410S = "";
	private static String IN01S = "";
	private static String IN34S = "";
	private static String LL09S = "";
	private static String LL30S = "";
	private static String LMD30S = "";
	private static String LS29S = "";
	private static String LS30S = "";
	private static String LS34S = "";
	private static String MF31S = "";
	private static String OD34S = "";
	private static String OF06S = "";
	private static String OF09S = "";
	private static String PAYMNT50 = "";
	private static String PAYMNT65 = "";
	private static String PER201 = "";
	private static String PER223 = "";
	private static String PER233 = "";
	private static String POSITIVE_SF = "";
	private static String POSITIVE_SR = "";
	private static String PT09S = "";
	private static String PT30S = "";
	private static String RET13 = "";
	private static String RET152 = "";
	private static String RET201 = "";
	private static String RET225 = "";
	private static String RET81 = "";
	private static String REV14 = "";
	private static String REV253 = "";
	private static String RI06S = "";
	private static String RLE907 = "";
	private static String RR21S = "";
	private static String RR24S = "";
	private static String RR25S = "";
	private static String RT21S = "";
	private static String RT24S = "";
	private static String RVLR09 = "";
	private static String SE09S = "";
	private static String SEGMENT_SF = "";
	private static String SEGMENT_SR = "";
	private static String TEL09S = "";
	private static String TEL21S = "";
	private static String TEL30S = "";
	private static String TELCO_SF = "";
	private static String TRD = "";
	private static String TRV03 = "";
	private static String TRV12 = "";
	private static String TRV18 = "";
	private static String UL_TRD = "";
	private static String UL29S = "";
	private static String UL34S = "";
	private static String US25S = "";
	private static String WD21 = "";
	private static String WD31 = "";
	private static String WD51 = "";
	private static String WD61 = "";
	private static String WD81 = "";
	private static String WGT_SCR_SF = "";
	private static String WGT_SCR_SR = "";
	private static String NEGATIVE_SF="";
	private static String NEGATIVE_SR ="";

	




	public static void setDatosBD(List<String> list) throws ParseException {
		SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		Fase3ResultadoBD.SECUENCIA_TERCERO = list.get(0).trim();
		
		Fase3ResultadoBD.FECHA_CALIFICACION = list.get(1).trim().substring(0,10);
		Fase3ResultadoBD.FECHA_CORTE_INFO = list.get(2).trim().substring(0,10);


		Fase3ResultadoBD.AT34A = list.get(3).trim();
		Fase3ResultadoBD.BI34S = list.get(4).trim();
		Fase3ResultadoBD.BR27S = list.get(5).trim();
		Fase3ResultadoBD.BR29S = list.get(6).trim();
		Fase3ResultadoBD.BR34S = list.get(7).trim();
		Fase3ResultadoBD.BU09S = list.get(8).trim();
		Fase3ResultadoBD.CA09S = list.get(9).trim();
		Fase3ResultadoBD.CA70S = list.get(10).trim();
		Fase3ResultadoBD.CO04SF = list.get(11).trim();
		Fase3ResultadoBD.CT24S = list.get(12).trim();
		Fase3ResultadoBD.CT30S = list.get(13).trim();
		Fase3ResultadoBD.CT31S = list.get(14).trim();
		Fase3ResultadoBD.DM211S = list.get(15).trim();
		Fase3ResultadoBD.DM214S = list.get(16).trim();
		Fase3ResultadoBD.FR29S = list.get(17).trim();
		Fase3ResultadoBD.FR34S = list.get(18).trim();
		Fase3ResultadoBD.FS20S = list.get(19).trim();
		Fase3ResultadoBD.G212SF = list.get(20).trim();
		Fase3ResultadoBD.G218BF = list.get(21).trim();
		Fase3ResultadoBD.G220A = list.get(22).trim();
		Fase3ResultadoBD.G221D = list.get(23).trim();
		Fase3ResultadoBD.G306S = list.get(24).trim();
		Fase3ResultadoBD.G410S = list.get(25).trim();
		Fase3ResultadoBD.IN01S = list.get(26).trim();
		Fase3ResultadoBD.IN34S = list.get(27).trim();
		Fase3ResultadoBD.LL09S = list.get(28).trim();
		Fase3ResultadoBD.LL30S = list.get(29).trim();
		Fase3ResultadoBD.LMD30S = list.get(30).trim();
		Fase3ResultadoBD.LS29S = list.get(31).trim();
		Fase3ResultadoBD.LS30S = list.get(32).trim();
		Fase3ResultadoBD.LS34S = list.get(33).trim();
		Fase3ResultadoBD.OD34S = list.get(34).trim();
		Fase3ResultadoBD.OF06S = list.get(35).trim();
		Fase3ResultadoBD.OF09S = list.get(36).trim();
		Fase3ResultadoBD.PT09S = list.get(37).trim();
		Fase3ResultadoBD.PT30S = list.get(38).trim();
		Fase3ResultadoBD.RI06S = list.get(39).trim();
		Fase3ResultadoBD.RR21S = list.get(40).trim();
		Fase3ResultadoBD.RR24S = list.get(41).trim();
		Fase3ResultadoBD.RR25S = list.get(42).trim();
		Fase3ResultadoBD.RT21S = list.get(43).trim();
		Fase3ResultadoBD.RT24S = list.get(44).trim();
		Fase3ResultadoBD.SE09S = list.get(45).trim();
		Fase3ResultadoBD.TEL09S = list.get(46).trim();
		Fase3ResultadoBD.TEL21S = list.get(47).trim();
		Fase3ResultadoBD.TEL30S = list.get(48).trim();
		Fase3ResultadoBD.UL29S = list.get(49).trim();
		Fase3ResultadoBD.UL34S = list.get(50).trim();
		Fase3ResultadoBD.AGG2402 = list.get(51).trim();
		Fase3ResultadoBD.AGG2403 = list.get(52).trim();
		Fase3ResultadoBD.AGG2404 = list.get(53).trim();
		Fase3ResultadoBD.AGG2405 = list.get(54).trim();
		Fase3ResultadoBD.AGG2406 = list.get(55).trim();
		Fase3ResultadoBD.AGG2407 = list.get(56).trim();
		Fase3ResultadoBD.AGG2408 = list.get(57).trim();
		Fase3ResultadoBD.AGG2409 = list.get(58).trim();
		Fase3ResultadoBD.AGG2410 = list.get(59).trim();
		Fase3ResultadoBD.AGG2411 = list.get(60).trim();
		Fase3ResultadoBD.AGG2412 = list.get(61).trim();
		Fase3ResultadoBD.AGG2413 = list.get(62).trim();
		Fase3ResultadoBD.AGG2414 = list.get(63).trim();
		Fase3ResultadoBD.AGG2415 = list.get(64).trim();
		Fase3ResultadoBD.AGG2416 = list.get(65).trim();
		Fase3ResultadoBD.AGG2417 = list.get(66).trim();
		Fase3ResultadoBD.AGG2418 = list.get(67).trim();
		Fase3ResultadoBD.AGG2419 = list.get(68).trim();
		Fase3ResultadoBD.AGG2420 = list.get(69).trim();
		Fase3ResultadoBD.AGG2421 = list.get(70).trim();
		Fase3ResultadoBD.AGG2422 = list.get(71).trim();
		Fase3ResultadoBD.AGG2423 = list.get(72).trim();
		Fase3ResultadoBD.AGG2424 = list.get(73).trim();
		Fase3ResultadoBD.AGG301 = list.get(74).trim();
		Fase3ResultadoBD.AGG302 = list.get(75).trim();
		Fase3ResultadoBD.AGG303 = list.get(76).trim();
		Fase3ResultadoBD.AGG304 = list.get(77).trim();
		Fase3ResultadoBD.AGG305 = list.get(78).trim();
		Fase3ResultadoBD.AGG306 = list.get(79).trim();
		Fase3ResultadoBD.AGG307 = list.get(80).trim();
		Fase3ResultadoBD.AGG308 = list.get(81).trim();
		Fase3ResultadoBD.AGG309 = list.get(82).trim();
		Fase3ResultadoBD.AGG310 = list.get(83).trim();
		Fase3ResultadoBD.AGG311 = list.get(84).trim();
		Fase3ResultadoBD.AGG312 = list.get(85).trim();
		Fase3ResultadoBD.AGG313 = list.get(86).trim();
		Fase3ResultadoBD.AGG314 = list.get(87).trim();
		Fase3ResultadoBD.AGG315 = list.get(88).trim();
		Fase3ResultadoBD.AGG316 = list.get(89).trim();
		Fase3ResultadoBD.AGG317 = list.get(90).trim();
		Fase3ResultadoBD.AGG318 = list.get(91).trim();
		Fase3ResultadoBD.AGG319 = list.get(92).trim();
		Fase3ResultadoBD.AGG320 = list.get(93).trim();
		Fase3ResultadoBD.AGG321 = list.get(94).trim();
		Fase3ResultadoBD.AGG322 = list.get(95).trim();
		Fase3ResultadoBD.AGG323 = list.get(96).trim();
		Fase3ResultadoBD.AGG324 = list.get(97).trim();
		Fase3ResultadoBD.BKC112 = list.get(98).trim();
		Fase3ResultadoBD.AGG905 = list.get(99).trim();
		Fase3ResultadoBD.AGG906 = list.get(100).trim();
		Fase3ResultadoBD.BKC225 = list.get(101).trim();
		Fase3ResultadoBD.PAYMNT50 = list.get(102).trim();
		Fase3ResultadoBD.PAYMNT65 = list.get(103).trim();
		Fase3ResultadoBD.PER201 = list.get(104).trim();
		Fase3ResultadoBD.PER223 = list.get(105).trim();
		Fase3ResultadoBD.PER233 = list.get(106).trim();
		Fase3ResultadoBD.RET13 = list.get(107).trim();
		Fase3ResultadoBD.RET152 = list.get(108).trim();
		Fase3ResultadoBD.RET201 = list.get(109).trim();
		Fase3ResultadoBD.RET81 = list.get(110).trim();
		Fase3ResultadoBD.REV14 = list.get(111).trim();
		Fase3ResultadoBD.REV253 = list.get(112).trim();
		Fase3ResultadoBD.RLE907 = list.get(113).trim();
		Fase3ResultadoBD.RVLR09 = list.get(114).trim();
		Fase3ResultadoBD.TRD = list.get(115).trim();
		Fase3ResultadoBD.TRV03 = list.get(116).trim();
		Fase3ResultadoBD.TRV12 = list.get(117).trim();
		Fase3ResultadoBD.UL_TRD = list.get(118).trim();
		Fase3ResultadoBD.WD21 = list.get(119).trim();
		Fase3ResultadoBD.WD31 = list.get(120).trim();
		Fase3ResultadoBD.WD51 = list.get(121).trim();
		Fase3ResultadoBD.WD61 = list.get(122).trim();
		Fase3ResultadoBD.WD81 = list.get(123).trim();
		Fase3ResultadoBD.RET225 = list.get(124).trim();
		Fase3ResultadoBD.BR20S = list.get(125).trim();
		Fase3ResultadoBD.FU21S = list.get(126).trim();
		Fase3ResultadoBD.US25S = list.get(127).trim();
		Fase3ResultadoBD.MF31S = list.get(128).trim();
		Fase3ResultadoBD.TRV18 = list.get(129).trim();
		Fase3ResultadoBD.POSITIVE_SF = list.get(130).trim();
		Fase3ResultadoBD.NEGATIVE_SF = list.get(131).trim();
		Fase3ResultadoBD.SEGMENT_SF = list.get(132).trim();
		Fase3ResultadoBD.TELCO_SF = list.get(133).trim();
		Fase3ResultadoBD.WGT_SCR_SF = list.get(134).trim();
		Fase3ResultadoBD.AGG_SCR_SF = list.get(135).trim();
		Fase3ResultadoBD.POSITIVE_SR = list.get(136).trim();
		Fase3ResultadoBD.NEGATIVE_SR = list.get(137).trim();
		Fase3ResultadoBD.SEGMENT_SR = list.get(138).trim();
		Fase3ResultadoBD.WGT_SCR_SR = list.get(139).trim();
		Fase3ResultadoBD.AGG_SCR_SR = list.get(140).trim();
		Fase3ResultadoBD.CREDITVISION = list.get(141).trim();
		Fase3ResultadoBD.CV_LINK_SERVICIOS_FIN = list.get(142).trim();
		Fase3ResultadoBD.CREDITVISION_LINK = list.get(143).trim();

		


	}
	public static String getNEGATIVE_SF() {
		return NEGATIVE_SF;
	}



	public static String getNEGATIVE_SR() {
		return NEGATIVE_SR;
	}


	public static String getSECUENCIA_TERCERO() {
		return SECUENCIA_TERCERO;
	}



	public static String getAGG_SCR_SF() {
		return AGG_SCR_SF;
	}



	public static String getAGG_SCR_SR() {
		return AGG_SCR_SR;
	}



	public static String getAGG2402() {
		return AGG2402;
	}



	public static String getAGG2403() {
		return AGG2403;
	}



	public static String getAGG2404() {
		return AGG2404;
	}



	public static String getAGG2405() {
		return AGG2405;
	}



	public static String getAGG2406() {
		return AGG2406;
	}



	public static String getAGG2407() {
		return AGG2407;
	}



	public static String getAGG2408() {
		return AGG2408;
	}



	public static String getAGG2409() {
		return AGG2409;
	}



	public static String getAGG2410() {
		return AGG2410;
	}



	public static String getAGG2411() {
		return AGG2411;
	}



	public static String getAGG2412() {
		return AGG2412;
	}



	public static String getAGG2413() {
		return AGG2413;
	}



	public static String getAGG2414() {
		return AGG2414;
	}



	public static String getAGG2415() {
		return AGG2415;
	}



	public static String getAGG2416() {
		return AGG2416;
	}



	public static String getAGG2417() {
		return AGG2417;
	}



	public static String getAGG2418() {
		return AGG2418;
	}



	public static String getAGG2419() {
		return AGG2419;
	}



	public static String getAGG2420() {
		return AGG2420;
	}



	public static String getAGG2421() {
		return AGG2421;
	}



	public static String getAGG2422() {
		return AGG2422;
	}



	public static String getAGG2423() {
		return AGG2423;
	}



	public static String getAGG2424() {
		return AGG2424;
	}



	public static String getAGG301() {
		return AGG301;
	}



	public static String getAGG302() {
		return AGG302;
	}



	public static String getAGG303() {
		return AGG303;
	}



	public static String getAGG304() {
		return AGG304;
	}



	public static String getAGG305() {
		return AGG305;
	}



	public static String getAGG306() {
		return AGG306;
	}



	public static String getAGG307() {
		return AGG307;
	}



	public static String getAGG308() {
		return AGG308;
	}



	public static String getAGG309() {
		return AGG309;
	}



	public static String getAGG310() {
		return AGG310;
	}



	public static String getAGG311() {
		return AGG311;
	}



	public static String getAGG312() {
		return AGG312;
	}



	public static String getAGG313() {
		return AGG313;
	}



	public static String getAGG314() {
		return AGG314;
	}



	public static String getAGG315() {
		return AGG315;
	}



	public static String getAGG316() {
		return AGG316;
	}



	public static String getAGG317() {
		return AGG317;
	}



	public static String getAGG318() {
		return AGG318;
	}



	public static String getAGG319() {
		return AGG319;
	}



	public static String getAGG320() {
		return AGG320;
	}



	public static String getAGG321() {
		return AGG321;
	}



	public static String getAGG322() {
		return AGG322;
	}



	public static String getAGG323() {
		return AGG323;
	}



	public static String getAGG324() {
		return AGG324;
	}



	public static String getAGG905() {
		return AGG905;
	}



	public static String getAGG906() {
		return AGG906;
	}



	public static String getAT34A() {
		return AT34A;
	}



	public static String getBI34S() {
		return BI34S;
	}



	public static String getBKC112() {
		return BKC112;
	}



	public static String getBKC225() {
		return BKC225;
	}



	public static String getBR20S() {
		return BR20S;
	}



	public static String getBR27S() {
		return BR27S;
	}



	public static String getBR29S() {
		return BR29S;
	}



	public static String getBR34S() {
		return BR34S;
	}



	public static String getBU09S() {
		return BU09S;
	}



	public static String getCA09S() {
		return CA09S;
	}



	public static String getCA70S() {
		return CA70S;
	}



	public static String getCO04SF() {
		return CO04SF;
	}



	public static String getCREDITVISION() {
		return CREDITVISION;
	}



	public static String getCREDITVISION_LINK() {
		return CREDITVISION_LINK;
	}



	public static String getCV_LINK_SERVICIOS_FIN() {
		return CV_LINK_SERVICIOS_FIN;
	}



	public static String getCT24S() {
		return CT24S;
	}



	public static String getCT30S() {
		return CT30S;
	}



	public static String getCT31S() {
		return CT31S;
	}



	public static String getDM211S() {
		return DM211S;
	}



	public static String getDM214S() {
		return DM214S;
	}



	public static String getFECHA_CALIFICACION() {
		return FECHA_CALIFICACION;
	}



	public static String getFECHA_CORTE_INFO() {
		return FECHA_CORTE_INFO;
	}



	public static String getFR29S() {
		return FR29S;
	}



	public static String getFR34S() {
		return FR34S;
	}



	public static String getFS20S() {
		return FS20S;
	}



	public static String getFU21S() {
		return FU21S;
	}



	public static String getG212SF() {
		return G212SF;
	}



	public static String getG218BF() {
		return G218BF;
	}



	public static String getG220A() {
		return G220A;
	}



	public static String getG221D() {
		return G221D;
	}



	public static String getG306S() {
		return G306S;
	}



	public static String getG410S() {
		return G410S;
	}



	public static String getIN01S() {
		return IN01S;
	}



	public static String getIN34S() {
		return IN34S;
	}



	public static String getLL09S() {
		return LL09S;
	}



	public static String getLL30S() {
		return LL30S;
	}



	public static String getLMD30S() {
		return LMD30S;
	}



	public static String getLS29S() {
		return LS29S;
	}



	public static String getLS30S() {
		return LS30S;
	}



	public static String getLS34S() {
		return LS34S;
	}



	public static String getMF31S() {
		return MF31S;
	}



	public static String getOD34S() {
		return OD34S;
	}



	public static String getOF06S() {
		return OF06S;
	}



	public static String getOF09S() {
		return OF09S;
	}



	public static String getPAYMNT50() {
		return PAYMNT50;
	}



	public static String getPAYMNT65() {
		return PAYMNT65;
	}



	public static String getPER201() {
		return PER201;
	}



	public static String getPER223() {
		return PER223;
	}



	public static String getPER233() {
		return PER233;
	}



	public static String getPOSITIVE_SF() {
		return POSITIVE_SF;
	}



	public static String getPOSITIVE_SR() {
		return POSITIVE_SR;
	}



	public static String getPT09S() {
		return PT09S;
	}



	public static String getPT30S() {
		return PT30S;
	}



	public static String getRET13() {
		return RET13;
	}



	public static String getRET152() {
		return RET152;
	}



	public static String getRET201() {
		return RET201;
	}



	public static String getRET225() {
		return RET225;
	}



	public static String getRET81() {
		return RET81;
	}



	public static String getREV14() {
		return REV14;
	}



	public static String getREV253() {
		return REV253;
	}



	public static String getRI06S() {
		return RI06S;
	}



	public static String getRLE907() {
		return RLE907;
	}



	public static String getRR21S() {
		return RR21S;
	}



	public static String getRR24S() {
		return RR24S;
	}



	public static String getRR25S() {
		return RR25S;
	}



	public static String getRT21S() {
		return RT21S;
	}



	public static String getRT24S() {
		return RT24S;
	}



	public static String getRVLR09() {
		return RVLR09;
	}



	public static String getSE09S() {
		return SE09S;
	}



	public static String getSEGMENT_SF() {
		return SEGMENT_SF;
	}



	public static String getSEGMENT_SR() {
		return SEGMENT_SR;
	}



	public static String getTEL09S() {
		return TEL09S;
	}



	public static String getTEL21S() {
		return TEL21S;
	}



	public static String getTEL30S() {
		return TEL30S;
	}



	public static String getTELCO_SF() {
		return TELCO_SF;
	}



	public static String getTRD() {
		return TRD;
	}



	public static String getTRV03() {
		return TRV03;
	}



	public static String getTRV12() {
		return TRV12;
	}



	public static String getTRV18() {
		return TRV18;
	}



	public static String getUL_TRD() {
		return UL_TRD;
	}



	public static String getUL29S() {
		return UL29S;
	}



	public static String getUL34S() {
		return UL34S;
	}



	public static String getUS25S() {
		return US25S;
	}



	public static String getWD21() {
		return WD21;
	}



	public static String getWD31() {
		return WD31;
	}



	public static String getWD51() {
		return WD51;
	}



	public static String getWD61() {
		return WD61;
	}



	public static String getWD81() {
		return WD81;
	}



	public static String getWGT_SCR_SF() {
		return WGT_SCR_SF;
	}



	public static String getWGT_SCR_SR() {
		return WGT_SCR_SR;
	}





}
