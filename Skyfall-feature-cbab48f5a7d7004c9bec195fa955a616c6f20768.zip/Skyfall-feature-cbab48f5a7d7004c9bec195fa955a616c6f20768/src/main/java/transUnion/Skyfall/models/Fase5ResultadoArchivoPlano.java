package transUnion.Skyfall.models;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Fase5ResultadoArchivoPlano {

	//cambiar variables nuevas archivo plano
	
	private static String SECUENCIA_TERCERO= "";
	private static String AGG1101= "";
	private static String AGG1102= "";
	private static String AGG1103= "";
	private static String AGG1104= "";
	private static String AGG1105= "";
	private static String AGG1106= "";
	private static String AGG1107= "";
	private static String AGG1108= "";
	private static String AGG1109= "";
	private static String AGG1110= "";
	private static String AGG1111= "";
	private static String AGG1112= "";
	private static String AGG1113= "";
	private static String AGG1114= "";
	private static String AGG1115= "";
	private static String AGG1116= "";
	private static String AGG1117= "";
	private static String AGG1118= "";
	private static String AGG1119= "";
	private static String AGG1120= "";
	private static String AGG1121= "";
	private static String AGG1122= "";
	private static String AGG1123= "";
	private static String AGG1124= "";
	private static String AGG701= "";
	private static String AGG702= "";
	private static String AGG703= "";
	private static String AGG704= "";
	private static String AGG705= "";
	private static String AGG706= "";
	private static String AGG707= "";
	private static String AGG708= "";
	private static String AGG709= "";
	private static String AGG710= "";
	private static String AGG711= "";
	private static String AGG712= "";
	private static String AGG713= "";
	private static String AGG714= "";
	private static String AGG715= "";
	private static String AGG716= "";
	private static String AGG717= "";
	private static String AGG718= "";
	private static String AGG719= "";
	private static String AGG720= "";
	private static String AGG721= "";
	private static String AGG722= "";
	private static String AGG723= "";
	private static String AGG724= "";
	private static String AGG904= "";
	private static String AGG909= "";
	private static String AGG910= "";
	private static String AGG911= "";
	private static String AT27SF= "";
	private static String AT31S= "";
	private static String AU21S= "";
	private static String AU51A= "";
	private static String BC01S= "";
	private static String BC20S= "";
	private static String BC21S= "";
	private static String BI20S= "";
	private static String BI21S= "";
	private static String BI29S= "";
	private static String BI32S= "";
	private static String BKC231= "";
	private static String BKC232= "";
	private static String BKC233= "";
	private static String BKC235= "";
	private static String BKC252= "";
	private static String BKC253= "";
	private static String BKC254= "";
	private static String BKC255= "";
	private static String BR12S= "";
	private static String BR20S= "";
	private static String BU21S= "";
	private static String BU32S= "";
	private static String CO04S= "";
	private static String COLLECTION_TRD= "";
	private static String CT20S= "";
	private static String CT32S= "";
	private static String CV25= "";
	private static String FI20S= "";
	private static String FI21S= "";
	private static String FI34S= "";
	private static String FMD21S= "";
	private static String FR21S= "";
	private static String FR32S= "";
	private static String FU20S= "";
	private static String FU21S= "";
	private static String FU32S= "";
	private static String FU34S= "";
	private static String G103S= "";
	private static String G209SF= "";
	private static String G211S= "";
	private static String G218C= "";
	private static String G417S= "";
	private static String G500S= "";
	private static String G540S= "";
	private static String G547S= "";
	private static String G960S= "";
	private static String IN06S= "";
	private static String IN09S= "";
	private static String IN21S= "";
	private static String IN25S= "";
	private static String IN27S= "";
	private static String IN31S= "";
	private static String LL21S= "";
	private static String LL34S= "";
	private static String LMD21S= "";
	private static String LMD32S= "";
	private static String LMD34S= "";
	private static String MF20S= "";
	private static String MF24S= "";
	private static String MF31S= "";
	private static String MF32S= "";
	private static String MT24S= "";
	private static String MT33S= "";
	private static String MT34B= "";
	private static String MT34S= "";
	private static String NON_FINANCIAL_TRD= "";
	private static String OF32S= "";
	private static String OF34S= "";
	private static String PAYMNT03= "";
	private static String PER222= "";
	private static String PER224= "";
	private static String PT20S= "";
	private static String PT21S= "";
	private static String PT34S= "";
	private static String PUBLIC_SERVICE_TRD= "";
	private static String RE102S= "";
	private static String RE12S= "";
	private static String RE30S= "";
	private static String RE32S= "";
	private static String RET11= "";
	private static String RET132= "";
	private static String RET14= "";
	private static String RET142= "";
	private static String RET222= "";
	private static String RET223= "";
	private static String RET224= "";
	private static String RET225= "";
	private static String RET315= "";
	private static String RET320= "";
	private static String RET51= "";
	private static String RET84= "";
	private static String REV202= "";
	private static String REV203= "";
	private static String REV204= "";
	private static String REV222= "";
	private static String REV223= "";
	private static String REV225= "";
	private static String REV320= "";
	private static String REV92= "";
	private static String REVBAL01= "";
	private static String REVBAL02= "";
	private static String REVBAL03= "";
	private static String REVBAL04= "";
	private static String REVBAL05= "";
	private static String REVBAL06= "";
	private static String REVBAL07= "";
	private static String REVBAL08= "";
	private static String REVBAL09= "";
	private static String REVBAL10= "";
	private static String REVBAL11= "";
	private static String REVBAL12= "";
	private static String REVBAL13= "";
	private static String REVBAL14= "";
	private static String REVBAL15= "";
	private static String REVBAL16= "";
	private static String REVBAL17= "";
	private static String REVBAL18= "";
	private static String REVBAL19= "";
	private static String REVBAL20= "";
	private static String REVBAL21= "";
	private static String REVBAL22= "";
	private static String REVBAL23= "";
	private static String REVBAL24= "";
	private static String RI20S= "";
	private static String RI21S= "";
	private static String RI24S= "";
	private static String RI27S= "";
	private static String RI29S= "";
	private static String RI30S= "";
	private static String RI31S= "";
	private static String RI32S= "";
	private static String RLE904= "";
	private static String RLE905= "";
	private static String RR102S= "";
	private static String RR201S= "";
	private static String RT06S= "";
	private static String RT201S= "";
	private static String RT31S= "";
	private static String RVLR03= "";
	private static String RVLR06= "";
	private static String S043S= "";
	private static String S064D= "";
	private static String S209D= "";
	private static String SE21S= "";
	private static String SE34S= "";
	private static String TEL31S= "";
	private static String TEL32S= "";
	private static String TRANBAL01= "";
	private static String TRANBAL02= "";
	private static String TRANBAL03= "";
	private static String TRANBAL04= "";
	private static String TRANBAL05= "";
	private static String TRANBAL06= "";
	private static String TRANBAL07= "";
	private static String TRANBAL08= "";
	private static String TRANBAL09= "";
	private static String TRANBAL10= "";
	private static String TRANBAL11= "";
	private static String TRANBAL12= "";
	private static String TRANBAL13= "";
	private static String TRANBAL14= "";
	private static String TRANBAL15= "";
	private static String TRANBAL16= "";
	private static String TRANBAL17= "";
	private static String TRANBAL18= "";
	private static String TRANBAL19= "";
	private static String TRANBAL20= "";
	private static String TRANBAL21= "";
	private static String TRANBAL22= "";
	private static String TRANBAL23= "";
	private static String TRANBAL24= "";
	private static String TRV05= "";
	private static String TRV14= "";
	private static String TRV17= "";
	private static String TRV18= "";
	private static String UL01S= "";
	private static String UL06S= "";
	private static String UL21S= "";
	private static String UL25S= "";
	private static String UL30S= "";
	private static String UL32S= "";
	private static String US20S= "";
	private static String US25S= "";
	private static String WALSHR07= "";
	private static String WD71= "";

	
	public static void setDatosArchivoPlano(String dataDOS) throws ParseException {
		SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		Fase5ResultadoArchivoPlano.SECUENCIA_TERCERO=  dataDOS.split("\\|")[0].trim();
		Fase5ResultadoArchivoPlano.AGG1101=  dataDOS.split("\\|")[1].trim();
		Fase5ResultadoArchivoPlano.AGG1102=  dataDOS.split("\\|")[2].trim();
		Fase5ResultadoArchivoPlano.AGG1103=  dataDOS.split("\\|")[3].trim();
		Fase5ResultadoArchivoPlano.AGG1104=  dataDOS.split("\\|")[4].trim();
		Fase5ResultadoArchivoPlano.AGG1105=  dataDOS.split("\\|")[5].trim();
		Fase5ResultadoArchivoPlano.AGG1106=  dataDOS.split("\\|")[6].trim();
		Fase5ResultadoArchivoPlano.AGG1107=  dataDOS.split("\\|")[7].trim();
		Fase5ResultadoArchivoPlano.AGG1108=  dataDOS.split("\\|")[8].trim();
		Fase5ResultadoArchivoPlano.AGG1109=  dataDOS.split("\\|")[9].trim();
		Fase5ResultadoArchivoPlano.AGG1110=  dataDOS.split("\\|")[10].trim();
		Fase5ResultadoArchivoPlano.AGG1111=  dataDOS.split("\\|")[11].trim();
		Fase5ResultadoArchivoPlano.AGG1112=  dataDOS.split("\\|")[12].trim();
		Fase5ResultadoArchivoPlano.AGG1113=  dataDOS.split("\\|")[13].trim();
		Fase5ResultadoArchivoPlano.AGG1114=  dataDOS.split("\\|")[14].trim();
		Fase5ResultadoArchivoPlano.AGG1115=  dataDOS.split("\\|")[15].trim();
		Fase5ResultadoArchivoPlano.AGG1116=  dataDOS.split("\\|")[16].trim();
		Fase5ResultadoArchivoPlano.AGG1117=  dataDOS.split("\\|")[17].trim();
		Fase5ResultadoArchivoPlano.AGG1118=  dataDOS.split("\\|")[18].trim();
		Fase5ResultadoArchivoPlano.AGG1119=  dataDOS.split("\\|")[19].trim();
		Fase5ResultadoArchivoPlano.AGG1120=  dataDOS.split("\\|")[20].trim();
		Fase5ResultadoArchivoPlano.AGG1121=  dataDOS.split("\\|")[21].trim();
		Fase5ResultadoArchivoPlano.AGG1122=  dataDOS.split("\\|")[22].trim();
		Fase5ResultadoArchivoPlano.AGG1123=  dataDOS.split("\\|")[23].trim();
		Fase5ResultadoArchivoPlano.AGG1124=  dataDOS.split("\\|")[24].trim();
		Fase5ResultadoArchivoPlano.AGG701=  dataDOS.split("\\|")[25].trim();
		Fase5ResultadoArchivoPlano.AGG702=  dataDOS.split("\\|")[26].trim();
		Fase5ResultadoArchivoPlano.AGG703=  dataDOS.split("\\|")[27].trim();
		Fase5ResultadoArchivoPlano.AGG704=  dataDOS.split("\\|")[28].trim();
		Fase5ResultadoArchivoPlano.AGG705=  dataDOS.split("\\|")[29].trim();
		Fase5ResultadoArchivoPlano.AGG706=  dataDOS.split("\\|")[30].trim();
		Fase5ResultadoArchivoPlano.AGG707=  dataDOS.split("\\|")[31].trim();
		Fase5ResultadoArchivoPlano.AGG708=  dataDOS.split("\\|")[32].trim();
		Fase5ResultadoArchivoPlano.AGG709=  dataDOS.split("\\|")[33].trim();
		Fase5ResultadoArchivoPlano.AGG710=  dataDOS.split("\\|")[34].trim();
		Fase5ResultadoArchivoPlano.AGG711=  dataDOS.split("\\|")[35].trim();
		Fase5ResultadoArchivoPlano.AGG712=  dataDOS.split("\\|")[36].trim();
		Fase5ResultadoArchivoPlano.AGG713=  dataDOS.split("\\|")[37].trim();
		Fase5ResultadoArchivoPlano.AGG714=  dataDOS.split("\\|")[38].trim();
		Fase5ResultadoArchivoPlano.AGG715=  dataDOS.split("\\|")[39].trim();
		Fase5ResultadoArchivoPlano.AGG716=  dataDOS.split("\\|")[40].trim();
		Fase5ResultadoArchivoPlano.AGG717=  dataDOS.split("\\|")[41].trim();
		Fase5ResultadoArchivoPlano.AGG718=  dataDOS.split("\\|")[42].trim();
		Fase5ResultadoArchivoPlano.AGG719=  dataDOS.split("\\|")[43].trim();
		Fase5ResultadoArchivoPlano.AGG720=  dataDOS.split("\\|")[44].trim();
		Fase5ResultadoArchivoPlano.AGG721=  dataDOS.split("\\|")[45].trim();
		Fase5ResultadoArchivoPlano.AGG722=  dataDOS.split("\\|")[46].trim();
		Fase5ResultadoArchivoPlano.AGG723=  dataDOS.split("\\|")[47].trim();
		Fase5ResultadoArchivoPlano.AGG724=  dataDOS.split("\\|")[48].trim();
		Fase5ResultadoArchivoPlano.AGG904=  dataDOS.split("\\|")[49].trim();
		Fase5ResultadoArchivoPlano.AGG909=  dataDOS.split("\\|")[50].trim();
		Fase5ResultadoArchivoPlano.AGG910=  dataDOS.split("\\|")[51].trim();
		Fase5ResultadoArchivoPlano.AGG911=  dataDOS.split("\\|")[52].trim();
		Fase5ResultadoArchivoPlano.AT27SF=  dataDOS.split("\\|")[53].trim();
		Fase5ResultadoArchivoPlano.AT31S=  dataDOS.split("\\|")[54].trim();
		Fase5ResultadoArchivoPlano.AU21S=  dataDOS.split("\\|")[55].trim();
		Fase5ResultadoArchivoPlano.AU51A=  dataDOS.split("\\|")[56].trim();
		Fase5ResultadoArchivoPlano.BC01S=  dataDOS.split("\\|")[57].trim();
		Fase5ResultadoArchivoPlano.BC20S=  dataDOS.split("\\|")[58].trim();
		Fase5ResultadoArchivoPlano.BC21S=  dataDOS.split("\\|")[59].trim();
		Fase5ResultadoArchivoPlano.BI20S=  dataDOS.split("\\|")[60].trim();
		Fase5ResultadoArchivoPlano.BI21S=  dataDOS.split("\\|")[61].trim();
		Fase5ResultadoArchivoPlano.BI29S=  dataDOS.split("\\|")[62].trim();
		Fase5ResultadoArchivoPlano.BI32S=  dataDOS.split("\\|")[63].trim();
		Fase5ResultadoArchivoPlano.BKC231=  dataDOS.split("\\|")[64].trim();
		Fase5ResultadoArchivoPlano.BKC232=  dataDOS.split("\\|")[65].trim();
		Fase5ResultadoArchivoPlano.BKC233=  dataDOS.split("\\|")[66].trim();
		Fase5ResultadoArchivoPlano.BKC235=  dataDOS.split("\\|")[67].trim();
		Fase5ResultadoArchivoPlano.BKC252=  dataDOS.split("\\|")[68].trim();
		Fase5ResultadoArchivoPlano.BKC253=  dataDOS.split("\\|")[69].trim();
		Fase5ResultadoArchivoPlano.BKC254=  dataDOS.split("\\|")[70].trim();
		Fase5ResultadoArchivoPlano.BKC255=  dataDOS.split("\\|")[71].trim();
		Fase5ResultadoArchivoPlano.BR12S=  dataDOS.split("\\|")[72].trim();
		Fase5ResultadoArchivoPlano.BR20S=  dataDOS.split("\\|")[73].trim();
		Fase5ResultadoArchivoPlano.BU21S=  dataDOS.split("\\|")[74].trim();
		Fase5ResultadoArchivoPlano.BU32S=  dataDOS.split("\\|")[75].trim();
		Fase5ResultadoArchivoPlano.CO04S=  dataDOS.split("\\|")[76].trim();
		Fase5ResultadoArchivoPlano.COLLECTION_TRD=  dataDOS.split("\\|")[77].trim();
		Fase5ResultadoArchivoPlano.CT20S=  dataDOS.split("\\|")[78].trim();
		Fase5ResultadoArchivoPlano.CT32S=  dataDOS.split("\\|")[79].trim();
		Fase5ResultadoArchivoPlano.CV25=  dataDOS.split("\\|")[80].trim();
		Fase5ResultadoArchivoPlano.FI20S=  dataDOS.split("\\|")[81].trim();
		Fase5ResultadoArchivoPlano.FI21S=  dataDOS.split("\\|")[82].trim();
		Fase5ResultadoArchivoPlano.FI34S=  dataDOS.split("\\|")[83].trim();
		Fase5ResultadoArchivoPlano.FMD21S=  dataDOS.split("\\|")[84].trim();
		Fase5ResultadoArchivoPlano.FR21S=  dataDOS.split("\\|")[85].trim();
		Fase5ResultadoArchivoPlano.FR32S=  dataDOS.split("\\|")[86].trim();
		Fase5ResultadoArchivoPlano.FU20S=  dataDOS.split("\\|")[87].trim();
		Fase5ResultadoArchivoPlano.FU21S=  dataDOS.split("\\|")[88].trim();
		Fase5ResultadoArchivoPlano.FU32S=  dataDOS.split("\\|")[89].trim();
		Fase5ResultadoArchivoPlano.FU34S=  dataDOS.split("\\|")[90].trim();
		Fase5ResultadoArchivoPlano.G103S=  dataDOS.split("\\|")[91].trim();
		Fase5ResultadoArchivoPlano.G209SF=  dataDOS.split("\\|")[92].trim();
		Fase5ResultadoArchivoPlano.G211S=  dataDOS.split("\\|")[93].trim();
		Fase5ResultadoArchivoPlano.G218C=  dataDOS.split("\\|")[94].trim();
		Fase5ResultadoArchivoPlano.G417S=  dataDOS.split("\\|")[95].trim();
		Fase5ResultadoArchivoPlano.G500S=  dataDOS.split("\\|")[96].trim();
		Fase5ResultadoArchivoPlano.G540S=  dataDOS.split("\\|")[97].trim();
		Fase5ResultadoArchivoPlano.G547S=  dataDOS.split("\\|")[98].trim();
		Fase5ResultadoArchivoPlano.G960S=  dataDOS.split("\\|")[99].trim();
		Fase5ResultadoArchivoPlano.IN06S=  dataDOS.split("\\|")[100].trim();
		Fase5ResultadoArchivoPlano.IN09S=  dataDOS.split("\\|")[101].trim();
		Fase5ResultadoArchivoPlano.IN21S=  dataDOS.split("\\|")[102].trim();
		Fase5ResultadoArchivoPlano.IN25S=  dataDOS.split("\\|")[103].trim();
		Fase5ResultadoArchivoPlano.IN27S=  dataDOS.split("\\|")[104].trim();
		Fase5ResultadoArchivoPlano.IN31S=  dataDOS.split("\\|")[105].trim();
		Fase5ResultadoArchivoPlano.LL21S=  dataDOS.split("\\|")[106].trim();
		Fase5ResultadoArchivoPlano.LL34S=  dataDOS.split("\\|")[107].trim();
		Fase5ResultadoArchivoPlano.LMD21S=  dataDOS.split("\\|")[108].trim();
		Fase5ResultadoArchivoPlano.LMD32S=  dataDOS.split("\\|")[109].trim();
		Fase5ResultadoArchivoPlano.LMD34S=  dataDOS.split("\\|")[110].trim();
		Fase5ResultadoArchivoPlano.MF20S=  dataDOS.split("\\|")[111].trim();
		Fase5ResultadoArchivoPlano.MF24S=  dataDOS.split("\\|")[112].trim();
		Fase5ResultadoArchivoPlano.MF31S=  dataDOS.split("\\|")[113].trim();
		Fase5ResultadoArchivoPlano.MF32S=  dataDOS.split("\\|")[114].trim();
		Fase5ResultadoArchivoPlano.MT24S=  dataDOS.split("\\|")[115].trim();
		Fase5ResultadoArchivoPlano.MT33S=  dataDOS.split("\\|")[116].trim();
		Fase5ResultadoArchivoPlano.MT34B=  dataDOS.split("\\|")[117].trim();
		Fase5ResultadoArchivoPlano.MT34S=  dataDOS.split("\\|")[118].trim();
		Fase5ResultadoArchivoPlano.NON_FINANCIAL_TRD=  dataDOS.split("\\|")[119].trim();
		Fase5ResultadoArchivoPlano.OF32S=  dataDOS.split("\\|")[120].trim();
		Fase5ResultadoArchivoPlano.OF34S=  dataDOS.split("\\|")[121].trim();
		Fase5ResultadoArchivoPlano.PAYMNT03=  dataDOS.split("\\|")[122].trim();
		Fase5ResultadoArchivoPlano.PER222=  dataDOS.split("\\|")[123].trim();
		Fase5ResultadoArchivoPlano.PER224=  dataDOS.split("\\|")[124].trim();
		Fase5ResultadoArchivoPlano.PT20S=  dataDOS.split("\\|")[125].trim();
		Fase5ResultadoArchivoPlano.PT21S=  dataDOS.split("\\|")[126].trim();
		Fase5ResultadoArchivoPlano.PT34S=  dataDOS.split("\\|")[127].trim();
		Fase5ResultadoArchivoPlano.PUBLIC_SERVICE_TRD=  dataDOS.split("\\|")[128].trim();
		Fase5ResultadoArchivoPlano.RE102S=  dataDOS.split("\\|")[129].trim();
		Fase5ResultadoArchivoPlano.RE12S=  dataDOS.split("\\|")[130].trim();
		Fase5ResultadoArchivoPlano.RE30S=  dataDOS.split("\\|")[131].trim();
		Fase5ResultadoArchivoPlano.RE32S=  dataDOS.split("\\|")[132].trim();
		Fase5ResultadoArchivoPlano.RET11=  dataDOS.split("\\|")[133].trim();
		Fase5ResultadoArchivoPlano.RET132=  dataDOS.split("\\|")[134].trim();
		Fase5ResultadoArchivoPlano.RET14=  dataDOS.split("\\|")[135].trim();
		Fase5ResultadoArchivoPlano.RET142=  dataDOS.split("\\|")[136].trim();
		Fase5ResultadoArchivoPlano.RET222=  dataDOS.split("\\|")[137].trim();
		Fase5ResultadoArchivoPlano.RET223=  dataDOS.split("\\|")[138].trim();
		Fase5ResultadoArchivoPlano.RET224=  dataDOS.split("\\|")[139].trim();
		Fase5ResultadoArchivoPlano.RET225=  dataDOS.split("\\|")[140].trim();
		Fase5ResultadoArchivoPlano.RET315=  dataDOS.split("\\|")[141].trim();
		Fase5ResultadoArchivoPlano.RET320=  dataDOS.split("\\|")[142].trim();
		Fase5ResultadoArchivoPlano.RET51=  dataDOS.split("\\|")[143].trim();
		Fase5ResultadoArchivoPlano.RET84=  dataDOS.split("\\|")[144].trim();
		Fase5ResultadoArchivoPlano.REV202=  dataDOS.split("\\|")[145].trim();
		Fase5ResultadoArchivoPlano.REV203=  dataDOS.split("\\|")[146].trim();
		Fase5ResultadoArchivoPlano.REV204=  dataDOS.split("\\|")[147].trim();
		Fase5ResultadoArchivoPlano.REV222=  dataDOS.split("\\|")[148].trim();
		Fase5ResultadoArchivoPlano.REV223=  dataDOS.split("\\|")[149].trim();
		Fase5ResultadoArchivoPlano.REV225=  dataDOS.split("\\|")[150].trim();
		Fase5ResultadoArchivoPlano.REV320=  dataDOS.split("\\|")[151].trim();
		Fase5ResultadoArchivoPlano.REV92=  dataDOS.split("\\|")[152].trim();
		Fase5ResultadoArchivoPlano.REVBAL01=  dataDOS.split("\\|")[153].trim();
		Fase5ResultadoArchivoPlano.REVBAL02=  dataDOS.split("\\|")[154].trim();
		Fase5ResultadoArchivoPlano.REVBAL03=  dataDOS.split("\\|")[155].trim();
		Fase5ResultadoArchivoPlano.REVBAL04=  dataDOS.split("\\|")[156].trim();
		Fase5ResultadoArchivoPlano.REVBAL05=  dataDOS.split("\\|")[157].trim();
		Fase5ResultadoArchivoPlano.REVBAL06=  dataDOS.split("\\|")[158].trim();
		Fase5ResultadoArchivoPlano.REVBAL07=  dataDOS.split("\\|")[159].trim();
		Fase5ResultadoArchivoPlano.REVBAL08=  dataDOS.split("\\|")[160].trim();
		Fase5ResultadoArchivoPlano.REVBAL09=  dataDOS.split("\\|")[161].trim();
		Fase5ResultadoArchivoPlano.REVBAL10=  dataDOS.split("\\|")[162].trim();
		Fase5ResultadoArchivoPlano.REVBAL11=  dataDOS.split("\\|")[163].trim();
		Fase5ResultadoArchivoPlano.REVBAL12=  dataDOS.split("\\|")[164].trim();
		Fase5ResultadoArchivoPlano.REVBAL13=  dataDOS.split("\\|")[165].trim();
		Fase5ResultadoArchivoPlano.REVBAL14=  dataDOS.split("\\|")[166].trim();
		Fase5ResultadoArchivoPlano.REVBAL15=  dataDOS.split("\\|")[167].trim();
		Fase5ResultadoArchivoPlano.REVBAL16=  dataDOS.split("\\|")[168].trim();
		Fase5ResultadoArchivoPlano.REVBAL17=  dataDOS.split("\\|")[169].trim();
		Fase5ResultadoArchivoPlano.REVBAL18=  dataDOS.split("\\|")[170].trim();
		Fase5ResultadoArchivoPlano.REVBAL19=  dataDOS.split("\\|")[171].trim();
		Fase5ResultadoArchivoPlano.REVBAL20=  dataDOS.split("\\|")[172].trim();
		Fase5ResultadoArchivoPlano.REVBAL21=  dataDOS.split("\\|")[173].trim();
		Fase5ResultadoArchivoPlano.REVBAL22=  dataDOS.split("\\|")[174].trim();
		Fase5ResultadoArchivoPlano.REVBAL23=  dataDOS.split("\\|")[175].trim();
		Fase5ResultadoArchivoPlano.REVBAL24=  dataDOS.split("\\|")[176].trim();
		Fase5ResultadoArchivoPlano.RI20S=  dataDOS.split("\\|")[177].trim();
		Fase5ResultadoArchivoPlano.RI21S=  dataDOS.split("\\|")[178].trim();
		Fase5ResultadoArchivoPlano.RI24S=  dataDOS.split("\\|")[179].trim();
		Fase5ResultadoArchivoPlano.RI27S=  dataDOS.split("\\|")[180].trim();
		Fase5ResultadoArchivoPlano.RI29S=  dataDOS.split("\\|")[181].trim();
		Fase5ResultadoArchivoPlano.RI30S=  dataDOS.split("\\|")[182].trim();
		Fase5ResultadoArchivoPlano.RI31S=  dataDOS.split("\\|")[183].trim();
		Fase5ResultadoArchivoPlano.RI32S=  dataDOS.split("\\|")[184].trim();
		Fase5ResultadoArchivoPlano.RLE904=  dataDOS.split("\\|")[185].trim();
		Fase5ResultadoArchivoPlano.RLE905=  dataDOS.split("\\|")[186].trim();
		Fase5ResultadoArchivoPlano.RR102S=  dataDOS.split("\\|")[187].trim();
		Fase5ResultadoArchivoPlano.RR201S=  dataDOS.split("\\|")[188].trim();
		Fase5ResultadoArchivoPlano.RT06S=  dataDOS.split("\\|")[189].trim();
		Fase5ResultadoArchivoPlano.RT201S=  dataDOS.split("\\|")[190].trim();
		Fase5ResultadoArchivoPlano.RT31S=  dataDOS.split("\\|")[191].trim();
		Fase5ResultadoArchivoPlano.RVLR03=  dataDOS.split("\\|")[192].trim();
		Fase5ResultadoArchivoPlano.RVLR06=  dataDOS.split("\\|")[193].trim();
		Fase5ResultadoArchivoPlano.S043S=  dataDOS.split("\\|")[194].trim();
		Fase5ResultadoArchivoPlano.S064D=  dataDOS.split("\\|")[195].trim();
		Fase5ResultadoArchivoPlano.S209D=  dataDOS.split("\\|")[196].trim();
		Fase5ResultadoArchivoPlano.SE21S=  dataDOS.split("\\|")[197].trim();
		Fase5ResultadoArchivoPlano.SE34S=  dataDOS.split("\\|")[198].trim();
		Fase5ResultadoArchivoPlano.TEL31S=  dataDOS.split("\\|")[199].trim();
		Fase5ResultadoArchivoPlano.TEL32S=  dataDOS.split("\\|")[200].trim();
		Fase5ResultadoArchivoPlano.TRANBAL01=  dataDOS.split("\\|")[201].trim();
		Fase5ResultadoArchivoPlano.TRANBAL02=  dataDOS.split("\\|")[202].trim();
		Fase5ResultadoArchivoPlano.TRANBAL03=  dataDOS.split("\\|")[203].trim();
		Fase5ResultadoArchivoPlano.TRANBAL04=  dataDOS.split("\\|")[204].trim();
		Fase5ResultadoArchivoPlano.TRANBAL05=  dataDOS.split("\\|")[205].trim();
		Fase5ResultadoArchivoPlano.TRANBAL06=  dataDOS.split("\\|")[206].trim();
		Fase5ResultadoArchivoPlano.TRANBAL07=  dataDOS.split("\\|")[207].trim();
		Fase5ResultadoArchivoPlano.TRANBAL08=  dataDOS.split("\\|")[208].trim();
		Fase5ResultadoArchivoPlano.TRANBAL09=  dataDOS.split("\\|")[209].trim();
		Fase5ResultadoArchivoPlano.TRANBAL10=  dataDOS.split("\\|")[210].trim();
		Fase5ResultadoArchivoPlano.TRANBAL11=  dataDOS.split("\\|")[211].trim();
		Fase5ResultadoArchivoPlano.TRANBAL12=  dataDOS.split("\\|")[212].trim();
		Fase5ResultadoArchivoPlano.TRANBAL13=  dataDOS.split("\\|")[213].trim();
		Fase5ResultadoArchivoPlano.TRANBAL14=  dataDOS.split("\\|")[214].trim();
		Fase5ResultadoArchivoPlano.TRANBAL15=  dataDOS.split("\\|")[215].trim();
		Fase5ResultadoArchivoPlano.TRANBAL16=  dataDOS.split("\\|")[216].trim();
		Fase5ResultadoArchivoPlano.TRANBAL17=  dataDOS.split("\\|")[217].trim();
		Fase5ResultadoArchivoPlano.TRANBAL18=  dataDOS.split("\\|")[218].trim();
		Fase5ResultadoArchivoPlano.TRANBAL19=  dataDOS.split("\\|")[219].trim();
		Fase5ResultadoArchivoPlano.TRANBAL20=  dataDOS.split("\\|")[220].trim();
		Fase5ResultadoArchivoPlano.TRANBAL21=  dataDOS.split("\\|")[221].trim();
		Fase5ResultadoArchivoPlano.TRANBAL22=  dataDOS.split("\\|")[222].trim();
		Fase5ResultadoArchivoPlano.TRANBAL23=  dataDOS.split("\\|")[223].trim();
		Fase5ResultadoArchivoPlano.TRANBAL24=  dataDOS.split("\\|")[224].trim();
		Fase5ResultadoArchivoPlano.TRV05=  dataDOS.split("\\|")[225].trim();
		Fase5ResultadoArchivoPlano.TRV14=  dataDOS.split("\\|")[226].trim();
		Fase5ResultadoArchivoPlano.TRV17=  dataDOS.split("\\|")[227].trim();
		Fase5ResultadoArchivoPlano.TRV18=  dataDOS.split("\\|")[228].trim();
		Fase5ResultadoArchivoPlano.UL01S=  dataDOS.split("\\|")[229].trim();
		Fase5ResultadoArchivoPlano.UL06S=  dataDOS.split("\\|")[230].trim();
		Fase5ResultadoArchivoPlano.UL21S=  dataDOS.split("\\|")[231].trim();
		Fase5ResultadoArchivoPlano.UL25S=  dataDOS.split("\\|")[232].trim();
		Fase5ResultadoArchivoPlano.UL30S=  dataDOS.split("\\|")[233].trim();
		Fase5ResultadoArchivoPlano.UL32S=  dataDOS.split("\\|")[234].trim();
		Fase5ResultadoArchivoPlano.US20S=  dataDOS.split("\\|")[235].trim();
		Fase5ResultadoArchivoPlano.US25S=  dataDOS.split("\\|")[236].trim();
		Fase5ResultadoArchivoPlano.WALSHR07=  dataDOS.split("\\|")[237].trim();
		Fase5ResultadoArchivoPlano.WD71=  dataDOS.split("\\|")[238].trim();




	}


	public static String getSECUENCIA_TERCERO() {
		return SECUENCIA_TERCERO;
	}


	public static String getAGG1101() {
		return AGG1101;
	}


	public static String getAGG1102() {
		return AGG1102;
	}


	public static String getAGG1103() {
		return AGG1103;
	}


	public static String getAGG1104() {
		return AGG1104;
	}


	public static String getAGG1105() {
		return AGG1105;
	}


	public static String getAGG1106() {
		return AGG1106;
	}


	public static String getAGG1107() {
		return AGG1107;
	}


	public static String getAGG1108() {
		return AGG1108;
	}


	public static String getAGG1109() {
		return AGG1109;
	}


	public static String getAGG1110() {
		return AGG1110;
	}


	public static String getAGG1111() {
		return AGG1111;
	}


	public static String getAGG1112() {
		return AGG1112;
	}


	public static String getAGG1113() {
		return AGG1113;
	}


	public static String getAGG1114() {
		return AGG1114;
	}


	public static String getAGG1115() {
		return AGG1115;
	}


	public static String getAGG1116() {
		return AGG1116;
	}


	public static String getAGG1117() {
		return AGG1117;
	}


	public static String getAGG1118() {
		return AGG1118;
	}


	public static String getAGG1119() {
		return AGG1119;
	}


	public static String getAGG1120() {
		return AGG1120;
	}


	public static String getAGG1121() {
		return AGG1121;
	}


	public static String getAGG1122() {
		return AGG1122;
	}


	public static String getAGG1123() {
		return AGG1123;
	}


	public static String getAGG1124() {
		return AGG1124;
	}


	public static String getAGG701() {
		return AGG701;
	}


	public static String getAGG702() {
		return AGG702;
	}


	public static String getAGG703() {
		return AGG703;
	}


	public static String getAGG704() {
		return AGG704;
	}


	public static String getAGG705() {
		return AGG705;
	}


	public static String getAGG706() {
		return AGG706;
	}


	public static String getAGG707() {
		return AGG707;
	}


	public static String getAGG708() {
		return AGG708;
	}


	public static String getAGG709() {
		return AGG709;
	}


	public static String getAGG710() {
		return AGG710;
	}


	public static String getAGG711() {
		return AGG711;
	}


	public static String getAGG712() {
		return AGG712;
	}


	public static String getAGG713() {
		return AGG713;
	}


	public static String getAGG714() {
		return AGG714;
	}


	public static String getAGG715() {
		return AGG715;
	}


	public static String getAGG716() {
		return AGG716;
	}


	public static String getAGG717() {
		return AGG717;
	}


	public static String getAGG718() {
		return AGG718;
	}


	public static String getAGG719() {
		return AGG719;
	}


	public static String getAGG720() {
		return AGG720;
	}


	public static String getAGG721() {
		return AGG721;
	}


	public static String getAGG722() {
		return AGG722;
	}


	public static String getAGG723() {
		return AGG723;
	}


	public static String getAGG724() {
		return AGG724;
	}


	public static String getAGG904() {
		return AGG904;
	}


	public static String getAGG909() {
		return AGG909;
	}


	public static String getAGG910() {
		return AGG910;
	}


	public static String getAGG911() {
		return AGG911;
	}


	public static String getAT27SF() {
		return AT27SF;
	}


	public static String getAT31S() {
		return AT31S;
	}


	public static String getAU21S() {
		return AU21S;
	}


	public static String getAU51A() {
		return AU51A;
	}


	public static String getBC01S() {
		return BC01S;
	}


	public static String getBC20S() {
		return BC20S;
	}


	public static String getBC21S() {
		return BC21S;
	}


	public static String getBI20S() {
		return BI20S;
	}


	public static String getBI21S() {
		return BI21S;
	}


	public static String getBI29S() {
		return BI29S;
	}


	public static String getBI32S() {
		return BI32S;
	}


	public static String getBKC231() {
		return BKC231;
	}


	public static String getBKC232() {
		return BKC232;
	}


	public static String getBKC233() {
		return BKC233;
	}


	public static String getBKC235() {
		return BKC235;
	}


	public static String getBKC252() {
		return BKC252;
	}


	public static String getBKC253() {
		return BKC253;
	}


	public static String getBKC254() {
		return BKC254;
	}


	public static String getBKC255() {
		return BKC255;
	}


	public static String getBR12S() {
		return BR12S;
	}


	public static String getBR20S() {
		return BR20S;
	}


	public static String getBU21S() {
		return BU21S;
	}


	public static String getBU32S() {
		return BU32S;
	}


	public static String getCO04S() {
		return CO04S;
	}


	public static String getCOLLECTION_TRD() {
		return COLLECTION_TRD;
	}


	public static String getCT20S() {
		return CT20S;
	}


	public static String getCT32S() {
		return CT32S;
	}


	public static String getCV25() {
		return CV25;
	}


	public static String getFI20S() {
		return FI20S;
	}


	public static String getFI21S() {
		return FI21S;
	}


	public static String getFI34S() {
		return FI34S;
	}


	public static String getFMD21S() {
		return FMD21S;
	}


	public static String getFR21S() {
		return FR21S;
	}


	public static String getFR32S() {
		return FR32S;
	}


	public static String getFU20S() {
		return FU20S;
	}


	public static String getFU21S() {
		return FU21S;
	}


	public static String getFU32S() {
		return FU32S;
	}


	public static String getFU34S() {
		return FU34S;
	}


	public static String getG103S() {
		return G103S;
	}


	public static String getG209SF() {
		return G209SF;
	}


	public static String getG211S() {
		return G211S;
	}


	public static String getG218C() {
		return G218C;
	}


	public static String getG417S() {
		return G417S;
	}


	public static String getG500S() {
		return G500S;
	}


	public static String getG540S() {
		return G540S;
	}


	public static String getG547S() {
		return G547S;
	}


	public static String getG960S() {
		return G960S;
	}


	public static String getIN06S() {
		return IN06S;
	}


	public static String getIN09S() {
		return IN09S;
	}


	public static String getIN21S() {
		return IN21S;
	}


	public static String getIN25S() {
		return IN25S;
	}


	public static String getIN27S() {
		return IN27S;
	}


	public static String getIN31S() {
		return IN31S;
	}


	public static String getLL21S() {
		return LL21S;
	}


	public static String getLL34S() {
		return LL34S;
	}


	public static String getLMD21S() {
		return LMD21S;
	}


	public static String getLMD32S() {
		return LMD32S;
	}


	public static String getLMD34S() {
		return LMD34S;
	}


	public static String getMF20S() {
		return MF20S;
	}


	public static String getMF24S() {
		return MF24S;
	}


	public static String getMF31S() {
		return MF31S;
	}


	public static String getMF32S() {
		return MF32S;
	}


	public static String getMT24S() {
		return MT24S;
	}


	public static String getMT33S() {
		return MT33S;
	}


	public static String getMT34B() {
		return MT34B;
	}


	public static String getMT34S() {
		return MT34S;
	}


	public static String getNON_FINANCIAL_TRD() {
		return NON_FINANCIAL_TRD;
	}


	public static String getOF32S() {
		return OF32S;
	}


	public static String getOF34S() {
		return OF34S;
	}


	public static String getPAYMNT03() {
		return PAYMNT03;
	}


	public static String getPER222() {
		return PER222;
	}


	public static String getPER224() {
		return PER224;
	}


	public static String getPT20S() {
		return PT20S;
	}


	public static String getPT21S() {
		return PT21S;
	}


	public static String getPT34S() {
		return PT34S;
	}


	public static String getPUBLIC_SERVICE_TRD() {
		return PUBLIC_SERVICE_TRD;
	}


	public static String getRE102S() {
		return RE102S;
	}


	public static String getRE12S() {
		return RE12S;
	}


	public static String getRE30S() {
		return RE30S;
	}


	public static String getRE32S() {
		return RE32S;
	}


	public static String getRET11() {
		return RET11;
	}


	public static String getRET132() {
		return RET132;
	}


	public static String getRET14() {
		return RET14;
	}


	public static String getRET142() {
		return RET142;
	}


	public static String getRET222() {
		return RET222;
	}


	public static String getRET223() {
		return RET223;
	}


	public static String getRET224() {
		return RET224;
	}


	public static String getRET225() {
		return RET225;
	}


	public static String getRET315() {
		return RET315;
	}


	public static String getRET320() {
		return RET320;
	}


	public static String getRET51() {
		return RET51;
	}


	public static String getRET84() {
		return RET84;
	}


	public static String getREV202() {
		return REV202;
	}


	public static String getREV203() {
		return REV203;
	}


	public static String getREV204() {
		return REV204;
	}


	public static String getREV222() {
		return REV222;
	}


	public static String getREV223() {
		return REV223;
	}


	public static String getREV225() {
		return REV225;
	}


	public static String getREV320() {
		return REV320;
	}


	public static String getREV92() {
		return REV92;
	}


	public static String getREVBAL01() {
		return REVBAL01;
	}


	public static String getREVBAL02() {
		return REVBAL02;
	}


	public static String getREVBAL03() {
		return REVBAL03;
	}


	public static String getREVBAL04() {
		return REVBAL04;
	}


	public static String getREVBAL05() {
		return REVBAL05;
	}


	public static String getREVBAL06() {
		return REVBAL06;
	}


	public static String getREVBAL07() {
		return REVBAL07;
	}


	public static String getREVBAL08() {
		return REVBAL08;
	}


	public static String getREVBAL09() {
		return REVBAL09;
	}


	public static String getREVBAL10() {
		return REVBAL10;
	}


	public static String getREVBAL11() {
		return REVBAL11;
	}


	public static String getREVBAL12() {
		return REVBAL12;
	}


	public static String getREVBAL13() {
		return REVBAL13;
	}


	public static String getREVBAL14() {
		return REVBAL14;
	}


	public static String getREVBAL15() {
		return REVBAL15;
	}


	public static String getREVBAL16() {
		return REVBAL16;
	}


	public static String getREVBAL17() {
		return REVBAL17;
	}


	public static String getREVBAL18() {
		return REVBAL18;
	}


	public static String getREVBAL19() {
		return REVBAL19;
	}


	public static String getREVBAL20() {
		return REVBAL20;
	}


	public static String getREVBAL21() {
		return REVBAL21;
	}


	public static String getREVBAL22() {
		return REVBAL22;
	}


	public static String getREVBAL23() {
		return REVBAL23;
	}


	public static String getREVBAL24() {
		return REVBAL24;
	}


	public static String getRI20S() {
		return RI20S;
	}


	public static String getRI21S() {
		return RI21S;
	}


	public static String getRI24S() {
		return RI24S;
	}


	public static String getRI27S() {
		return RI27S;
	}


	public static String getRI29S() {
		return RI29S;
	}


	public static String getRI30S() {
		return RI30S;
	}


	public static String getRI31S() {
		return RI31S;
	}


	public static String getRI32S() {
		return RI32S;
	}


	public static String getRLE904() {
		return RLE904;
	}


	public static String getRLE905() {
		return RLE905;
	}


	public static String getRR102S() {
		return RR102S;
	}


	public static String getRR201S() {
		return RR201S;
	}


	public static String getRT06S() {
		return RT06S;
	}


	public static String getRT201S() {
		return RT201S;
	}


	public static String getRT31S() {
		return RT31S;
	}


	public static String getRVLR03() {
		return RVLR03;
	}


	public static String getRVLR06() {
		return RVLR06;
	}


	public static String getS043S() {
		return S043S;
	}


	public static String getS064D() {
		return S064D;
	}


	public static String getS209D() {
		return S209D;
	}


	public static String getSE21S() {
		return SE21S;
	}


	public static String getSE34S() {
		return SE34S;
	}


	public static String getTEL31S() {
		return TEL31S;
	}


	public static String getTEL32S() {
		return TEL32S;
	}


	public static String getTRANBAL01() {
		return TRANBAL01;
	}


	public static String getTRANBAL02() {
		return TRANBAL02;
	}


	public static String getTRANBAL03() {
		return TRANBAL03;
	}


	public static String getTRANBAL04() {
		return TRANBAL04;
	}


	public static String getTRANBAL05() {
		return TRANBAL05;
	}


	public static String getTRANBAL06() {
		return TRANBAL06;
	}


	public static String getTRANBAL07() {
		return TRANBAL07;
	}


	public static String getTRANBAL08() {
		return TRANBAL08;
	}


	public static String getTRANBAL09() {
		return TRANBAL09;
	}


	public static String getTRANBAL10() {
		return TRANBAL10;
	}


	public static String getTRANBAL11() {
		return TRANBAL11;
	}


	public static String getTRANBAL12() {
		return TRANBAL12;
	}


	public static String getTRANBAL13() {
		return TRANBAL13;
	}


	public static String getTRANBAL14() {
		return TRANBAL14;
	}


	public static String getTRANBAL15() {
		return TRANBAL15;
	}


	public static String getTRANBAL16() {
		return TRANBAL16;
	}


	public static String getTRANBAL17() {
		return TRANBAL17;
	}


	public static String getTRANBAL18() {
		return TRANBAL18;
	}


	public static String getTRANBAL19() {
		return TRANBAL19;
	}


	public static String getTRANBAL20() {
		return TRANBAL20;
	}


	public static String getTRANBAL21() {
		return TRANBAL21;
	}


	public static String getTRANBAL22() {
		return TRANBAL22;
	}


	public static String getTRANBAL23() {
		return TRANBAL23;
	}


	public static String getTRANBAL24() {
		return TRANBAL24;
	}


	public static String getTRV05() {
		return TRV05;
	}


	public static String getTRV14() {
		return TRV14;
	}


	public static String getTRV17() {
		return TRV17;
	}


	public static String getTRV18() {
		return TRV18;
	}


	public static String getUL01S() {
		return UL01S;
	}


	public static String getUL06S() {
		return UL06S;
	}


	public static String getUL21S() {
		return UL21S;
	}


	public static String getUL25S() {
		return UL25S;
	}


	public static String getUL30S() {
		return UL30S;
	}


	public static String getUL32S() {
		return UL32S;
	}


	public static String getUS20S() {
		return US20S;
	}


	public static String getUS25S() {
		return US25S;
	}


	public static String getWALSHR07() {
		return WALSHR07;
	}


	public static String getWD71() {
		return WD71;
	}




}


