package transUnion.Skyfall.models;

import java.text.ParseException;

public class Fase1ResultadoArchivoPlano {
	private static String Consecutivo = "";
	private static String G212SF = "";
	private static String G218BF = "";
	private static String G306S = "";
	private static String PER223 = "";
	private static String RVLR09 = "";
	private static String TRD = "";
	private static String WD21 = "";
	private static String WD51 = "";
	private static String BI34S = "";
	private static String CO04SF = "";
	private static String RR21S = "";
	private static String TEL21S = "";
	private static String UL29S = "";
	private static String AGG301 = "";
	private static String AGG302 = "";
	private static String AGG303 = "";
	private static String AGG304 = "";
	private static String AGG305 = "";
	private static String AGG306 = "";
	private static String AGG307 = "";
	private static String AGG308 = "";
	private static String AGG309 = "";
	private static String AGG310 = "";
	private static String AGG311 = "";
	private static String AGG312 = "";
	private static String AGG313 = "";
	private static String AGG314 = "";
	private static String AGG315 = "";
	private static String AGG316 = "";
	private static String AGG317 = "";
	private static String AGG318 = "";
	private static String AGG319 = "";
	private static String AGG320 = "";
	private static String AGG321 = "";
	private static String AGG322 = "";
	private static String AGG323 = "";
	private static String AGG324 = "";
	private static String TRV03 = "";
	private static String UL_TRD = "";
	private static String BR27S = "";
	private static String BR29S = "";
	private static String BR34S = "";
	private static String BU09S = "";
	private static String DM214S = "";
	private static String FR34S = "";
	private static String IN34S = "";
	private static String LL09S = "";
	private static String LL30S = "";
	private static String LMD30S = "";
	private static String LS34S = "";
	private static String OF09S = "";
	private static String PT09S = "";
	private static String PT30S = "";
	private static String RR25S = "";
	private static String RT21S = "";
	private static String TEL09S = "";
	private static String AGG2401 = "";
	private static String AGG2402 = "";
	private static String AGG2403 = "";
	private static String AGG2404 = "";
	private static String AGG2405 = "";
	private static String AGG2406 = "";
	private static String AGG2407 = "";
	private static String AGG2408 = "";
	private static String AGG2409 = "";
	private static String AGG2410 = "";
	private static String AGG2411 = "";
	private static String AGG2412 = "";
	private static String AGG2413 = "";
	private static String AGG2414 = "";
	private static String AGG2415 = "";
	private static String AGG2416 = "";
	private static String AGG2417 = "";
	private static String AGG2418 = "";
	private static String AGG2419 = "";
	private static String AGG2420 = "";
	private static String AGG2421 = "";
	private static String AGG2422 = "";
	private static String AGG2423 = "";
	private static String AGG2424 = "";
	private static String BKC112 = "";
	private static String BKC225 = "";
	private static String RET13 = "";
	private static String TRV12 = "";
	private static String WD31 = "";
	private static String WD61 = "";
	private static String WD81 = "";
	private static String CT24S = "";
	private static String G410S = "";
	private static String IN01S = "";
	private static String OF06S = "";
	private static String UL34S = "";
	private static String REV14 = "";
	private static String RLE907 = "";
	private static String AT34A = "";
	private static String CA09S = "";
	private static String CA70S = "";
	private static String CT30S = "";
	private static String CT31S = "";
	private static String DM211S = "";
	private static String G220A = "";
	private static String OD34S = "";
	private static String RI06S = "";
	private static String RR24S = "";
	private static String RT24S = "";
	private static String SE09S = "";
	private static String TEL30S = "";
	private static String AGG905 = "";
	private static String AGG906 = "";
	private static String PAYMNT50 = "";
	private static String PAYMNT65 = "";
	private static String PER233 = "";
	private static String RET152 = "";
	private static String RET201 = "";
	private static String RET81 = "";
	private static String REV253 = "";
	private static String FR29S = "";
	private static String FS20S = "";
	private static String G221D = "";
	private static String LS29S = "";
	private static String LS30S = "";
	private static String PER201 = "";
	private static String  CV_SCORE="";


	
	
	public static void setDatosArchivoPlano(String data) throws ParseException {

		
		Fase1ResultadoArchivoPlano.Consecutivo = data.split("\\|")[0].trim();
		Fase1ResultadoArchivoPlano.AGG2401 = data.split("\\|")[1].trim();
		Fase1ResultadoArchivoPlano.AGG2402 = data.split("\\|")[2].trim();
		Fase1ResultadoArchivoPlano.AGG2403 = data.split("\\|")[3].trim();
		Fase1ResultadoArchivoPlano.AGG2404 = data.split("\\|")[4].trim();
		Fase1ResultadoArchivoPlano.AGG2405 = data.split("\\|")[5].trim();
		Fase1ResultadoArchivoPlano.AGG2406 = data.split("\\|")[6].trim();
		Fase1ResultadoArchivoPlano.AGG2407 = data.split("\\|")[7].trim();
		Fase1ResultadoArchivoPlano.AGG2408 = data.split("\\|")[8].trim();
		Fase1ResultadoArchivoPlano.AGG2409 = data.split("\\|")[9].trim();
		Fase1ResultadoArchivoPlano.AGG2410 = data.split("\\|")[10].trim();
		Fase1ResultadoArchivoPlano.AGG2411 = data.split("\\|")[11].trim();
		Fase1ResultadoArchivoPlano.AGG2412 = data.split("\\|")[12].trim();
		Fase1ResultadoArchivoPlano.AGG2413 = data.split("\\|")[13].trim();
		Fase1ResultadoArchivoPlano.AGG2414 = data.split("\\|")[14].trim();
		Fase1ResultadoArchivoPlano.AGG2415 = data.split("\\|")[15].trim();
		Fase1ResultadoArchivoPlano.AGG2416 = data.split("\\|")[16].trim();
		Fase1ResultadoArchivoPlano.AGG2417 = data.split("\\|")[17].trim();
		Fase1ResultadoArchivoPlano.AGG2418 = data.split("\\|")[18].trim();
		Fase1ResultadoArchivoPlano.AGG2419 = data.split("\\|")[19].trim();
		Fase1ResultadoArchivoPlano.AGG2420 = data.split("\\|")[20].trim();
		Fase1ResultadoArchivoPlano.AGG2421 = data.split("\\|")[21].trim();
		Fase1ResultadoArchivoPlano.AGG2422 = data.split("\\|")[22].trim();
		Fase1ResultadoArchivoPlano.AGG2423 = data.split("\\|")[23].trim();
		Fase1ResultadoArchivoPlano.AGG2424 = data.split("\\|")[24].trim();
		Fase1ResultadoArchivoPlano.AGG301  = data.split("\\|")[25].trim();
		Fase1ResultadoArchivoPlano.AGG302  = data.split("\\|")[26].trim();
		Fase1ResultadoArchivoPlano.AGG303 = data.split("\\|")[27].trim();
		Fase1ResultadoArchivoPlano.AGG304 = data.split("\\|")[28].trim();
		Fase1ResultadoArchivoPlano.AGG305 = data.split("\\|")[29].trim();
		Fase1ResultadoArchivoPlano.AGG306 = data.split("\\|")[30].trim();
		Fase1ResultadoArchivoPlano.AGG307 = data.split("\\|")[31].trim();
		Fase1ResultadoArchivoPlano.AGG308 = data.split("\\|")[32].trim();
		Fase1ResultadoArchivoPlano.AGG309 = data.split("\\|")[33].trim();
		Fase1ResultadoArchivoPlano.AGG310 = data.split("\\|")[34].trim();
		Fase1ResultadoArchivoPlano.AGG311 = data.split("\\|")[35].trim();
		Fase1ResultadoArchivoPlano.AGG312 = data.split("\\|")[36].trim();
		Fase1ResultadoArchivoPlano.AGG313 = data.split("\\|")[37].trim();
		Fase1ResultadoArchivoPlano.AGG314 = data.split("\\|")[38].trim();
		Fase1ResultadoArchivoPlano.AGG315 = data.split("\\|")[39].trim();
		Fase1ResultadoArchivoPlano.AGG316 = data.split("\\|")[40].trim();
		Fase1ResultadoArchivoPlano.AGG317 = data.split("\\|")[41].trim();
		Fase1ResultadoArchivoPlano.AGG318 = data.split("\\|")[42].trim();
		Fase1ResultadoArchivoPlano.AGG319 = data.split("\\|")[43].trim();
		Fase1ResultadoArchivoPlano.AGG320 = data.split("\\|")[44].trim();
		Fase1ResultadoArchivoPlano.AGG321 = data.split("\\|")[45].trim();
		Fase1ResultadoArchivoPlano.AGG322 = data.split("\\|")[46].trim();
		Fase1ResultadoArchivoPlano.AGG323 = data.split("\\|")[47].trim();
		Fase1ResultadoArchivoPlano.AGG324 = data.split("\\|")[48].trim();
		Fase1ResultadoArchivoPlano.AGG905 = data.split("\\|")[49].trim();
		Fase1ResultadoArchivoPlano.AGG906 = data.split("\\|")[50].trim();
		Fase1ResultadoArchivoPlano.AT34A  = data.split("\\|")[51].trim();
		Fase1ResultadoArchivoPlano.BI34S  = data.split("\\|")[52].trim();
		Fase1ResultadoArchivoPlano.BKC112 = data.split("\\|")[53].trim();
		Fase1ResultadoArchivoPlano.BKC225 = data.split("\\|")[54].trim();
		Fase1ResultadoArchivoPlano.BR27S = data.split("\\|")[55].trim();
		Fase1ResultadoArchivoPlano.BR29S = data.split("\\|")[56].trim();
		Fase1ResultadoArchivoPlano.BR34S = data.split("\\|")[57].trim();
		Fase1ResultadoArchivoPlano.BU09S = data.split("\\|")[58].trim();
		Fase1ResultadoArchivoPlano.CA09S = data.split("\\|")[59].trim();
		Fase1ResultadoArchivoPlano.CA70S = data.split("\\|")[60].trim();
		Fase1ResultadoArchivoPlano.CO04SF = data.split("\\|")[61].trim();
		Fase1ResultadoArchivoPlano.CT24S = data.split("\\|")[62].trim();
		Fase1ResultadoArchivoPlano.CT30S = data.split("\\|")[63].trim();
		Fase1ResultadoArchivoPlano.CT31S = data.split("\\|")[64].trim();
		Fase1ResultadoArchivoPlano.DM211S = data.split("\\|")[65].trim();
		Fase1ResultadoArchivoPlano.DM214S = data.split("\\|")[66].trim();
		Fase1ResultadoArchivoPlano.FR29S = data.split("\\|")[67].trim();
		Fase1ResultadoArchivoPlano.FR34S = data.split("\\|")[68].trim();
		Fase1ResultadoArchivoPlano.FS20S = data.split("\\|")[69].trim();
		Fase1ResultadoArchivoPlano.G212SF = data.split("\\|")[70].trim();
		Fase1ResultadoArchivoPlano.G218BF = data.split("\\|")[71].trim();
		Fase1ResultadoArchivoPlano.G220A = data.split("\\|")[72].trim();
		Fase1ResultadoArchivoPlano.G221D = data.split("\\|")[73].trim();
		Fase1ResultadoArchivoPlano.G306S = data.split("\\|")[74].trim();
		Fase1ResultadoArchivoPlano.G410S = data.split("\\|")[75].trim();
		Fase1ResultadoArchivoPlano.IN01S = data.split("\\|")[76].trim();
		Fase1ResultadoArchivoPlano.IN34S = data.split("\\|")[77].trim();
		Fase1ResultadoArchivoPlano.LL09S = data.split("\\|")[78].trim();
		Fase1ResultadoArchivoPlano.LL30S = data.split("\\|")[79].trim();
		Fase1ResultadoArchivoPlano.LMD30S = data.split("\\|")[80].trim();
		Fase1ResultadoArchivoPlano.LS29S = data.split("\\|")[81].trim();
		Fase1ResultadoArchivoPlano.LS30S = data.split("\\|")[82].trim();
		Fase1ResultadoArchivoPlano.LS34S = data.split("\\|")[83].trim();
		Fase1ResultadoArchivoPlano.OD34S = data.split("\\|")[84].trim();
		Fase1ResultadoArchivoPlano.OF06S = data.split("\\|")[85].trim();
		Fase1ResultadoArchivoPlano.OF09S = data.split("\\|")[86].trim();
		Fase1ResultadoArchivoPlano.PAYMNT50 = data.split("\\|")[87].trim();
		Fase1ResultadoArchivoPlano.PAYMNT65 = data.split("\\|")[88].trim();
		Fase1ResultadoArchivoPlano.PER201 = data.split("\\|")[89].trim();
		Fase1ResultadoArchivoPlano.PER223 = data.split("\\|")[90].trim();
		Fase1ResultadoArchivoPlano.PER233 = data.split("\\|")[91].trim();
		Fase1ResultadoArchivoPlano.PT09S = data.split("\\|")[92].trim();
		Fase1ResultadoArchivoPlano.PT30S = data.split("\\|")[93].trim();
		Fase1ResultadoArchivoPlano.RET13 = data.split("\\|")[94].trim();
		Fase1ResultadoArchivoPlano.RET152 = data.split("\\|")[95].trim();
		Fase1ResultadoArchivoPlano.RET201 = data.split("\\|")[96].trim();
		Fase1ResultadoArchivoPlano.RET81 = data.split("\\|")[97].trim();
		Fase1ResultadoArchivoPlano.REV14 = data.split("\\|")[98].trim();
		Fase1ResultadoArchivoPlano.REV253 = data.split("\\|")[99].trim();
		Fase1ResultadoArchivoPlano.RI06S = data.split("\\|")[100].trim();
		Fase1ResultadoArchivoPlano.RLE907 = data.split("\\|")[101].trim();
		Fase1ResultadoArchivoPlano.RR21S = data.split("\\|")[102].trim();
		Fase1ResultadoArchivoPlano.RR24S = data.split("\\|")[103].trim();
		Fase1ResultadoArchivoPlano.RR25S = data.split("\\|")[104].trim();
		Fase1ResultadoArchivoPlano.RT21S = data.split("\\|")[105].trim();
		Fase1ResultadoArchivoPlano.RT24S = data.split("\\|")[106].trim();
		Fase1ResultadoArchivoPlano.RVLR09 = data.split("\\|")[107].trim();
		Fase1ResultadoArchivoPlano.SE09S = data.split("\\|")[108].trim();
		Fase1ResultadoArchivoPlano.TEL09S = data.split("\\|")[109].trim();
		Fase1ResultadoArchivoPlano.TEL21S = data.split("\\|")[110].trim();
		Fase1ResultadoArchivoPlano.TEL30S = data.split("\\|")[111].trim();
		Fase1ResultadoArchivoPlano.TRD = data.split("\\|")[112].trim();
		Fase1ResultadoArchivoPlano.TRV03 = data.split("\\|")[113].trim();
		Fase1ResultadoArchivoPlano.TRV12 = data.split("\\|")[114].trim();
		Fase1ResultadoArchivoPlano.UL_TRD = data.split("\\|")[115].trim();
		Fase1ResultadoArchivoPlano.UL29S = data.split("\\|")[116].trim();
		Fase1ResultadoArchivoPlano.UL34S = data.split("\\|")[117].trim();
		Fase1ResultadoArchivoPlano.WD21 = data.split("\\|")[118].trim();
		Fase1ResultadoArchivoPlano.WD31 = data.split("\\|")[119].trim();
		Fase1ResultadoArchivoPlano.WD51 = data.split("\\|")[120].trim();
		Fase1ResultadoArchivoPlano.WD61 = data.split("\\|")[121].trim();
		Fase1ResultadoArchivoPlano.WD81 = data.split("\\|")[122].trim();
		Fase1ResultadoArchivoPlano.CV_SCORE = data.split("\\|")[122].trim();
		

	

	}
	

	public static String getCV_Score() {
		return Fase1ResultadoArchivoPlano.CV_SCORE;
	}	

	public static String getConsecutivo() {
		return Fase1ResultadoArchivoPlano.Consecutivo;
	}


	public static String getG212SF() {
		return Fase1ResultadoArchivoPlano.G212SF;
	}




	public static String getG218BF() {
		return Fase1ResultadoArchivoPlano.G218BF;
	}




	public static String getG306S() {
		return Fase1ResultadoArchivoPlano.G306S;
	}




	public static String getPER223() {
		return Fase1ResultadoArchivoPlano.PER223;
	}




	public static String getRVLR09() {
		return Fase1ResultadoArchivoPlano.RVLR09;
	}




	public static String getTRD() {
		return Fase1ResultadoArchivoPlano.TRD;
	}




	public static String getWD21() {
		return Fase1ResultadoArchivoPlano.WD21;
	}




	public static String getWD51() {
		return Fase1ResultadoArchivoPlano.WD51;
	}




	public static String getBI34S() {
		return Fase1ResultadoArchivoPlano.BI34S;
	}




	public static String getCO04SF() {
		return Fase1ResultadoArchivoPlano.CO04SF;
	}




	public static String getRR21S() {
		return Fase1ResultadoArchivoPlano.RR21S;
	}




	public static String getTEL21S() {
		return Fase1ResultadoArchivoPlano.TEL21S;
	}




	public static String getUL29S() {
		return Fase1ResultadoArchivoPlano.UL29S;
	}




	public static String getAGG301() {
		return Fase1ResultadoArchivoPlano.AGG301;
	}




	public static String getAGG302() {
		return Fase1ResultadoArchivoPlano.AGG302;
	}




	public static String getAGG303() {
		return Fase1ResultadoArchivoPlano.AGG303;
	}




	public static String getAGG304() {
		return Fase1ResultadoArchivoPlano.AGG304;
	}




	public static String getAGG305() {
		return Fase1ResultadoArchivoPlano.AGG305;
	}




	public static String getAGG306() {
		return Fase1ResultadoArchivoPlano.AGG306;
	}




	public static String getAGG307() {
		return Fase1ResultadoArchivoPlano.AGG307;
	}




	public static String getAGG308() {
		return Fase1ResultadoArchivoPlano.AGG308;
	}




	public static String getAGG309() {
		return Fase1ResultadoArchivoPlano.AGG309;
	}




	public static String getAGG310() {
		return Fase1ResultadoArchivoPlano.AGG310;
	}




	public static String getAGG311() {
		return Fase1ResultadoArchivoPlano.AGG311;
	}




	public static String getAGG312() {
		return Fase1ResultadoArchivoPlano.AGG312;
	}




	public static String getAGG313() {
		return Fase1ResultadoArchivoPlano.AGG313;
	}




	public static String getAGG314() {
		return Fase1ResultadoArchivoPlano.AGG314;
	}




	public static String getAGG315() {
		return Fase1ResultadoArchivoPlano.AGG315;
	}




	public static String getAGG316() {
		return Fase1ResultadoArchivoPlano.AGG316;
	}




	public static String getAGG317() {
		return Fase1ResultadoArchivoPlano.AGG317;
	}




	public static String getAGG318() {
		return Fase1ResultadoArchivoPlano.AGG318;
	}




	public static String getAGG319() {
		return Fase1ResultadoArchivoPlano.AGG319;
	}




	public static String getAGG320() {
		return Fase1ResultadoArchivoPlano.AGG320;
	}




	public static String getAGG321() {
		return Fase1ResultadoArchivoPlano.AGG321;
	}




	public static String getAGG322() {
		return Fase1ResultadoArchivoPlano.AGG322;
	}




	public static String getAGG323() {
		return Fase1ResultadoArchivoPlano.AGG323;
	}




	public static String getAGG324() {
		return Fase1ResultadoArchivoPlano.AGG324;
	}




	public static String getTRV03() {
		return Fase1ResultadoArchivoPlano.TRV03;
	}




	public static String getUL_TRD() {
		return Fase1ResultadoArchivoPlano.UL_TRD;
	}




	public static String getBR27S() {
		return Fase1ResultadoArchivoPlano.BR27S;
	}




	public static String getBR29S() {
		return Fase1ResultadoArchivoPlano.BR29S;
	}




	public static String getBR34S() {
		return Fase1ResultadoArchivoPlano.BR34S;
	}




	public static String getBU09S() {
		return Fase1ResultadoArchivoPlano.BU09S;
	}




	public static String getDM214S() {
		return Fase1ResultadoArchivoPlano.DM214S;
	}




	public static String getFR34S() {
		return Fase1ResultadoArchivoPlano.FR34S;
	}




	public static String getIN34S() {
		return Fase1ResultadoArchivoPlano.IN34S;
	}




	public static String getLL09S() {
		return Fase1ResultadoArchivoPlano.LL09S;
	}




	public static String getLL30S() {
		return Fase1ResultadoArchivoPlano.LL30S;
	}




	public static String getLMD30S() {
		return Fase1ResultadoArchivoPlano.LMD30S;
	}




	public static String getLS34S() {
		return Fase1ResultadoArchivoPlano.LS34S;
	}




	public static String getOF09S() {
		return Fase1ResultadoArchivoPlano.OF09S;
	}




	public static String getPT09S() {
		return Fase1ResultadoArchivoPlano.PT09S;
	}




	public static String getPT30S() {
		return Fase1ResultadoArchivoPlano.PT30S;
	}




	public static String getRR25S() {
		return Fase1ResultadoArchivoPlano.RR25S;
	}




	public static String getRT21S() {
		return Fase1ResultadoArchivoPlano.RT21S;
	}




	public static String getTEL09S() {
		return Fase1ResultadoArchivoPlano.TEL09S;
	}




	public static String getAGG2401() {
		return Fase1ResultadoArchivoPlano.AGG2401;
	}




	public static String getAGG2402() {
		return Fase1ResultadoArchivoPlano.AGG2402;
	}




	public static String getAGG2403() {
		return Fase1ResultadoArchivoPlano.AGG2403;
	}




	public static String getAGG2404() {
		return Fase1ResultadoArchivoPlano.AGG2404;
	}




	public static String getAGG2405() {
		return Fase1ResultadoArchivoPlano.AGG2405;
	}




	public static String getAGG2406() {
		return Fase1ResultadoArchivoPlano.AGG2406;
	}




	public static String getAGG2407() {
		return Fase1ResultadoArchivoPlano.AGG2407;
	}




	public static String getAGG2408() {
		return Fase1ResultadoArchivoPlano.AGG2408;
	}




	public static String getAGG2409() {
		return Fase1ResultadoArchivoPlano.AGG2409;
	}




	public static String getAGG2410() {
		return Fase1ResultadoArchivoPlano.AGG2410;
	}




	public static String getAGG2411() {
		return Fase1ResultadoArchivoPlano.AGG2411;
	}




	public static String getAGG2412() {
		return Fase1ResultadoArchivoPlano.AGG2412;
	}




	public static String getAGG2413() {
		return Fase1ResultadoArchivoPlano.AGG2413;
	}




	public static String getAGG2414() {
		return Fase1ResultadoArchivoPlano.AGG2414;
	}




	public static String getAGG2415() {
		return Fase1ResultadoArchivoPlano.AGG2415;
	}




	public static String getAGG2416() {
		return Fase1ResultadoArchivoPlano.AGG2416;
	}




	public static String getAGG2417() {
		return Fase1ResultadoArchivoPlano.AGG2417;
	}




	public static String getAGG2418() {
		return Fase1ResultadoArchivoPlano.AGG2418;
	}




	public static String getAGG2419() {
		return Fase1ResultadoArchivoPlano.AGG2419;
	}




	public static String getAGG2420() {
		return Fase1ResultadoArchivoPlano.AGG2420;
	}




	public static String getAGG2421() {
		return Fase1ResultadoArchivoPlano.AGG2421;
	}




	public static String getAGG2422() {
		return Fase1ResultadoArchivoPlano.AGG2422;
	}




	public static String getAGG2423() {
		return Fase1ResultadoArchivoPlano.AGG2423;
	}




	public static String getAGG2424() {
		return Fase1ResultadoArchivoPlano.AGG2424;
	}




	public static String getBKC112() {
		return Fase1ResultadoArchivoPlano.BKC112;
	}




	public static String getBKC225() {
		return Fase1ResultadoArchivoPlano.BKC225;
	}




	public static String getRET13() {
		return Fase1ResultadoArchivoPlano.RET13;
	}




	public static String getTRV12() {
		return Fase1ResultadoArchivoPlano.TRV12;
	}




	public static String getWD31() {
		return Fase1ResultadoArchivoPlano.WD31;
	}




	public static String getWD61() {
		return Fase1ResultadoArchivoPlano.WD61;
	}




	public static String getWD81() {
		return Fase1ResultadoArchivoPlano.WD81;
	}




	public static String getCT24S() {
		return Fase1ResultadoArchivoPlano.CT24S;
	}




	public static String getG410S() {
		return Fase1ResultadoArchivoPlano.G410S;
	}




	public static String getIN01S() {
		return Fase1ResultadoArchivoPlano.IN01S;
	}




	public static String getOF06S() {
		return Fase1ResultadoArchivoPlano.OF06S;
	}




	public static String getUL34S() {
		return Fase1ResultadoArchivoPlano.UL34S;
	}




	public static String getREV14() {
		return Fase1ResultadoArchivoPlano.REV14;
	}




	public static String getRLE907() {
		return Fase1ResultadoArchivoPlano.RLE907;
	}




	public static String getAT34A() {
		return Fase1ResultadoArchivoPlano.AT34A;
	}




	public static String getCA09S() {
		return Fase1ResultadoArchivoPlano.CA09S;
	}




	public static String getCA70S() {
		return Fase1ResultadoArchivoPlano.CA70S;
	}




	public static String getCT30S() {
		return Fase1ResultadoArchivoPlano.CT30S;
	}




	public static String getCT31S() {
		return Fase1ResultadoArchivoPlano.CT31S;
	}




	public static String getDM211S() {
		return Fase1ResultadoArchivoPlano.DM211S;
	}




	public static String getG220A() {
		return Fase1ResultadoArchivoPlano.G220A;
	}




	public static String getOD34S() {
		return Fase1ResultadoArchivoPlano.OD34S;
	}




	public static String getRI06S() {
		return Fase1ResultadoArchivoPlano.RI06S;
	}




	public static String getRR24S() {
		return Fase1ResultadoArchivoPlano.RR24S;
	}




	public static String getRT24S() {
		return Fase1ResultadoArchivoPlano.RT24S;
	}




	public static String getSE09S() {
		return Fase1ResultadoArchivoPlano.SE09S;
	}




	public static String getTEL30S() {
		return Fase1ResultadoArchivoPlano.TEL30S;
	}




	public static String getAGG905() {
		return Fase1ResultadoArchivoPlano.AGG905;
	}




	public static String getAGG906() {
		return Fase1ResultadoArchivoPlano.AGG906;
	}




	public static String getPAYMNT50() {
		return Fase1ResultadoArchivoPlano.PAYMNT50;
	}




	public static String getPAYMNT65() {
		return Fase1ResultadoArchivoPlano.PAYMNT65;
	}




	public static String getPER233() {
		return Fase1ResultadoArchivoPlano.PER233;
	}




	public static String getRET152() {
		return Fase1ResultadoArchivoPlano.RET152;
	}




	public static String getRET201() {
		return Fase1ResultadoArchivoPlano.RET201;
	}




	public static String getRET81() {
		return Fase1ResultadoArchivoPlano.RET81;
	}




	public static String getREV253() {
		return Fase1ResultadoArchivoPlano.REV253;
	}




	public static String getFR29S() {
		return Fase1ResultadoArchivoPlano.FR29S;
	}




	public static String getFS20S() {
		return Fase1ResultadoArchivoPlano.FS20S;
	}




	public static String getG221D() {
		return Fase1ResultadoArchivoPlano.G221D;
	}




	public static String getLS29S() {
		return Fase1ResultadoArchivoPlano.LS29S;
	}




	public static String getLS30S() {
		return Fase1ResultadoArchivoPlano.LS30S;
	}




	public static String getPER201() {
		return Fase1ResultadoArchivoPlano.PER201;
	}
}


