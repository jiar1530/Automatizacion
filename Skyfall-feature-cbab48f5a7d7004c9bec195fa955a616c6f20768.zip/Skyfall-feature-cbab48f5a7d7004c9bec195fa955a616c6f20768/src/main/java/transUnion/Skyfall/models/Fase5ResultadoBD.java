package transUnion.Skyfall.models;

import java.text.ParseException;
import java.util.List;



public class Fase5ResultadoBD {
	private static String SECUENCIA_TERCERO= "";

	private static String AGG1101= "";
	private static String AGG1102= "";
	private static String AGG1103= "";
	private static String AGG1104= "";
	private static String AGG1105= "";
	private static String AGG1106= "";
	private static String AGG1107= "";
	private static String AGG1108= "";
	private static String AGG1109= "";
	private static String AGG1110= "";
	private static String AGG1111= "";
	private static String AGG1112= "";
	private static String AGG1113= "";
	private static String AGG1114= "";
	private static String AGG1115= "";
	private static String AGG1116= "";
	private static String AGG1117= "";
	private static String AGG1118= "";
	private static String AGG1119= "";
	private static String AGG1120= "";
	private static String AGG1121= "";
	private static String AGG1122= "";
	private static String AGG1123= "";
	private static String AGG1124= "";
	private static String AGG701= "";
	private static String AGG702= "";
	private static String AGG703= "";
	private static String AGG704= "";
	private static String AGG705= "";
	private static String AGG706= "";
	private static String AGG707= "";
	private static String AGG708= "";
	private static String AGG709= "";
	private static String AGG710= "";
	private static String AGG711= "";
	private static String AGG712= "";
	private static String AGG713= "";
	private static String AGG714= "";
	private static String AGG715= "";
	private static String AGG716= "";
	private static String AGG717= "";
	private static String AGG718= "";
	private static String AGG719= "";
	private static String AGG720= "";
	private static String AGG721= "";
	private static String AGG722= "";
	private static String AGG723= "";
	private static String AGG724= "";
	private static String AGG904= "";
	private static String AGG909= "";
	private static String AGG910= "";
	private static String AGG911= "";
	private static String AT27SF= "";
	private static String AT31S= "";
	private static String AU21S= "";
	private static String AU51A= "";
	private static String BC01S= "";
	private static String BC20S= "";
	private static String BC21S= "";
	private static String BI20S= "";
	private static String BI21S= "";
	private static String BI29S= "";
	private static String BI32S= "";
	private static String BKC231= "";
	private static String BKC232= "";
	private static String BKC233= "";
	private static String BKC235= "";
	private static String BKC252= "";
	private static String BKC253= "";
	private static String BKC254= "";
	private static String BKC255= "";
	private static String BR12S= "";
	private static String BR20S= "";
	private static String BU21S= "";
	private static String BU32S= "";
	private static String CO04S= "";
	private static String COLLECTION_TRD= "";
	private static String CT20S= "";
	private static String CT32S= "";
	private static String CV25= "";
	private static String FI20S= "";
	private static String FI21S= "";
	private static String FI34S= "";
	private static String FMD21S= "";
	private static String FR21S= "";
	private static String FR32S= "";
	private static String FU20S= "";
	private static String FU21S= "";
	private static String FU32S= "";
	private static String FU34S= "";
	private static String G103S= "";
	private static String G209SF= "";
	private static String G211S= "";
	private static String G218C= "";
	private static String G417S= "";
	private static String G500S= "";
	private static String G540S= "";
	private static String G547S= "";
	private static String G960S= "";
	private static String IN06S= "";
	private static String IN09S= "";
	private static String IN21S= "";
	private static String IN25S= "";
	private static String IN27S= "";
	private static String IN31S= "";
	private static String LL21S= "";
	private static String LL34S= "";
	private static String LMD21S= "";
	private static String LMD32S= "";
	private static String LMD34S= "";
	private static String MF20S= "";
	private static String MF24S= "";
	private static String MF31S= "";
	private static String MF32S= "";
	private static String MT24S= "";
	private static String MT33S= "";
	private static String MT34B= "";
	private static String MT34S= "";
	private static String NON_FINANCIAL_TRD= "";
	private static String OF32S= "";
	private static String OF34S= "";
	private static String PAYMNT03= "";
	private static String PER222= "";
	private static String PER224= "";
	private static String PT20S= "";
	private static String PT21S= "";
	private static String PT34S= "";
	private static String PUBLIC_SERVICE_TRD= "";
	private static String RE102S= "";
	private static String RE12S= "";
	private static String RE30S= "";
	private static String RE32S= "";
	private static String RET11= "";
	private static String RET132= "";
	private static String RET14= "";
	private static String RET142= "";
	private static String RET222= "";
	private static String RET223= "";
	private static String RET224= "";
	private static String RET225= "";
	private static String RET315= "";
	private static String RET320= "";
	private static String RET51= "";
	private static String RET84= "";
	private static String REV202= "";
	private static String REV203= "";
	private static String REV204= "";
	private static String REV222= "";
	private static String REV223= "";
	private static String REV225= "";
	private static String REV320= "";
	private static String REV92= "";
	private static String REVBAL01= "";
	private static String REVBAL02= "";
	private static String REVBAL03= "";
	private static String REVBAL04= "";
	private static String REVBAL05= "";
	private static String REVBAL06= "";
	private static String REVBAL07= "";
	private static String REVBAL08= "";
	private static String REVBAL09= "";
	private static String REVBAL10= "";
	private static String REVBAL11= "";
	private static String REVBAL12= "";
	private static String REVBAL13= "";
	private static String REVBAL14= "";
	private static String REVBAL15= "";
	private static String REVBAL16= "";
	private static String REVBAL17= "";
	private static String REVBAL18= "";
	private static String REVBAL19= "";
	private static String REVBAL20= "";
	private static String REVBAL21= "";
	private static String REVBAL22= "";
	private static String REVBAL23= "";
	private static String REVBAL24= "";
	private static String RI20S= "";
	private static String RI21S= "";
	private static String RI24S= "";
	private static String RI27S= "";
	private static String RI29S= "";
	private static String RI30S= "";
	private static String RI31S= "";
	private static String RI32S= "";
	private static String RLE904= "";
	private static String RLE905= "";
	private static String RR102S= "";
	private static String RR201S= "";
	private static String RT06S= "";
	private static String RT201S= "";
	private static String RT31S= "";
	private static String RVLR03= "";
	private static String RVLR06= "";
	private static String S043S= "";
	private static String S064D= "";
	private static String S209D= "";
	private static String SE21S= "";
	private static String SE34S= "";
	private static String TEL31S= "";
	private static String TEL32S= "";
	private static String TRANBAL01= "";
	private static String TRANBAL02= "";
	private static String TRANBAL03= "";
	private static String TRANBAL04= "";
	private static String TRANBAL05= "";
	private static String TRANBAL06= "";
	private static String TRANBAL07= "";
	private static String TRANBAL08= "";
	private static String TRANBAL09= "";
	private static String TRANBAL10= "";
	private static String TRANBAL11= "";
	private static String TRANBAL12= "";
	private static String TRANBAL13= "";
	private static String TRANBAL14= "";
	private static String TRANBAL15= "";
	private static String TRANBAL16= "";
	private static String TRANBAL17= "";
	private static String TRANBAL18= "";
	private static String TRANBAL19= "";
	private static String TRANBAL20= "";
	private static String TRANBAL21= "";
	private static String TRANBAL22= "";
	private static String TRANBAL23= "";
	private static String TRANBAL24= "";
	private static String TRV05= "";
	private static String TRV14= "";
	private static String TRV17= "";
	private static String TRV18= "";
	private static String UL01S= "";
	private static String UL06S= "";
	private static String UL21S= "";
	private static String UL25S= "";
	private static String UL30S= "";
	private static String UL32S= "";
	private static String US20S= "";
	private static String US25S= "";
	private static String WALSHR07= "";
	private static String WD71= "";
	
	
	public static void setDatosBD(List<String> list) throws ParseException {
		
		Fase5ResultadoBD.SECUENCIA_TERCERO= list.get(0).trim();
		Fase5ResultadoBD.AGG1101= list.get(1).trim();
		Fase5ResultadoBD.AGG1102= list.get(2).trim();
		Fase5ResultadoBD.AGG1103= list.get(3).trim();
		Fase5ResultadoBD.AGG1104= list.get(4).trim();
		Fase5ResultadoBD.AGG1105= list.get(5).trim();
		Fase5ResultadoBD.AGG1106= list.get(6).trim();
		Fase5ResultadoBD.AGG1107= list.get(7).trim();
		Fase5ResultadoBD.AGG1108= list.get(8).trim();
		Fase5ResultadoBD.AGG1109= list.get(9).trim();
		Fase5ResultadoBD.AGG1110= list.get(10).trim();
		Fase5ResultadoBD.AGG1111= list.get(11).trim();
		Fase5ResultadoBD.AGG1112= list.get(12).trim();
		Fase5ResultadoBD.AGG1113= list.get(13).trim();
		Fase5ResultadoBD.AGG1114= list.get(14).trim();
		Fase5ResultadoBD.AGG1115= list.get(15).trim();
		Fase5ResultadoBD.AGG1116= list.get(16).trim();
		Fase5ResultadoBD.AGG1117= list.get(17).trim();
		Fase5ResultadoBD.AGG1118= list.get(18).trim();
		Fase5ResultadoBD.AGG1119= list.get(19).trim();
		Fase5ResultadoBD.AGG1120= list.get(20).trim();
		Fase5ResultadoBD.AGG1121= list.get(21).trim();
		Fase5ResultadoBD.AGG1122= list.get(22).trim();
		Fase5ResultadoBD.AGG1123= list.get(23).trim();
		Fase5ResultadoBD.AGG1124= list.get(24).trim();
		Fase5ResultadoBD.AGG701= list.get(25).trim();
		Fase5ResultadoBD.AGG702= list.get(26).trim();
		Fase5ResultadoBD.AGG703= list.get(27).trim();
		Fase5ResultadoBD.AGG704= list.get(28).trim();
		Fase5ResultadoBD.AGG705= list.get(29).trim();
		Fase5ResultadoBD.AGG706= list.get(30).trim();
		Fase5ResultadoBD.AGG707= list.get(31).trim();
		Fase5ResultadoBD.AGG708= list.get(32).trim();
		Fase5ResultadoBD.AGG709= list.get(33).trim();
		Fase5ResultadoBD.AGG710= list.get(34).trim();
		Fase5ResultadoBD.AGG711= list.get(35).trim();
		Fase5ResultadoBD.AGG712= list.get(36).trim();
		Fase5ResultadoBD.AGG713= list.get(37).trim();
		Fase5ResultadoBD.AGG714= list.get(38).trim();
		Fase5ResultadoBD.AGG715= list.get(39).trim();
		Fase5ResultadoBD.AGG716= list.get(40).trim();
		Fase5ResultadoBD.AGG717= list.get(41).trim();
		Fase5ResultadoBD.AGG718= list.get(42).trim();
		Fase5ResultadoBD.AGG719= list.get(43).trim();
		Fase5ResultadoBD.AGG720= list.get(44).trim();
		Fase5ResultadoBD.AGG721= list.get(45).trim();
		Fase5ResultadoBD.AGG722= list.get(46).trim();
		Fase5ResultadoBD.AGG723= list.get(47).trim();
		Fase5ResultadoBD.AGG724= list.get(48).trim();
		Fase5ResultadoBD.AGG904= list.get(49).trim();
		Fase5ResultadoBD.AGG909= list.get(50).trim();
		Fase5ResultadoBD.AGG910= list.get(51).trim();
		Fase5ResultadoBD.AGG911= list.get(52).trim();
		Fase5ResultadoBD.AT27SF= list.get(53).trim();
		Fase5ResultadoBD.AT31S= list.get(54).trim();
		Fase5ResultadoBD.AU21S= list.get(55).trim();
		Fase5ResultadoBD.AU51A= list.get(56).trim();
		Fase5ResultadoBD.BC01S= list.get(57).trim();
		Fase5ResultadoBD.BC20S= list.get(58).trim();
		Fase5ResultadoBD.BC21S= list.get(59).trim();
		Fase5ResultadoBD.BI20S= list.get(60).trim();
		Fase5ResultadoBD.BI21S= list.get(61).trim();
		Fase5ResultadoBD.BI29S= list.get(62).trim();
		Fase5ResultadoBD.BI32S= list.get(63).trim();
		Fase5ResultadoBD.BKC231= list.get(64).trim();
		Fase5ResultadoBD.BKC232= list.get(65).trim();
		Fase5ResultadoBD.BKC233= list.get(66).trim();
		Fase5ResultadoBD.BKC235= list.get(67).trim();
		Fase5ResultadoBD.BKC252= list.get(68).trim();
		Fase5ResultadoBD.BKC253= list.get(69).trim();
		Fase5ResultadoBD.BKC254= list.get(70).trim();
		Fase5ResultadoBD.BKC255= list.get(71).trim();
		Fase5ResultadoBD.BR12S= list.get(72).trim();
		Fase5ResultadoBD.BR20S= list.get(73).trim();
		Fase5ResultadoBD.BU21S= list.get(74).trim();
		Fase5ResultadoBD.BU32S= list.get(75).trim();
		Fase5ResultadoBD.CO04S= list.get(76).trim();
		Fase5ResultadoBD.COLLECTION_TRD= list.get(77).trim();
		Fase5ResultadoBD.CT20S= list.get(78).trim();
		Fase5ResultadoBD.CT32S= list.get(79).trim();
		Fase5ResultadoBD.CV25= list.get(80).trim();
		Fase5ResultadoBD.FI20S= list.get(81).trim();
		Fase5ResultadoBD.FI21S= list.get(82).trim();
		Fase5ResultadoBD.FI34S= list.get(83).trim();
		Fase5ResultadoBD.FMD21S= list.get(84).trim();
		Fase5ResultadoBD.FR21S= list.get(85).trim();
		Fase5ResultadoBD.FR32S= list.get(86).trim();
		Fase5ResultadoBD.FU20S= list.get(87).trim();
		Fase5ResultadoBD.FU21S= list.get(88).trim();
		Fase5ResultadoBD.FU32S= list.get(89).trim();
		Fase5ResultadoBD.FU34S= list.get(90).trim();
		Fase5ResultadoBD.G103S= list.get(91).trim();
		Fase5ResultadoBD.G209SF= list.get(92).trim();
		Fase5ResultadoBD.G211S= list.get(93).trim();
		Fase5ResultadoBD.G218C= list.get(94).trim();
		Fase5ResultadoBD.G417S= list.get(95).trim();
		Fase5ResultadoBD.G500S= list.get(96).trim();
		Fase5ResultadoBD.G540S= list.get(97).trim();
		Fase5ResultadoBD.G547S= list.get(98).trim();
		Fase5ResultadoBD.G960S= list.get(99).trim();
		Fase5ResultadoBD.IN06S= list.get(100).trim();
		Fase5ResultadoBD.IN09S= list.get(101).trim();
		Fase5ResultadoBD.IN21S= list.get(102).trim();
		Fase5ResultadoBD.IN25S= list.get(103).trim();
		Fase5ResultadoBD.IN27S= list.get(104).trim();
		Fase5ResultadoBD.IN31S= list.get(105).trim();
		Fase5ResultadoBD.LL21S= list.get(106).trim();
		Fase5ResultadoBD.LL34S= list.get(107).trim();
		Fase5ResultadoBD.LMD21S= list.get(108).trim();
		Fase5ResultadoBD.LMD32S= list.get(109).trim();
		Fase5ResultadoBD.LMD34S= list.get(110).trim();
		Fase5ResultadoBD.MF20S= list.get(111).trim();
		Fase5ResultadoBD.MF24S= list.get(112).trim();
		Fase5ResultadoBD.MF31S= list.get(113).trim();
		Fase5ResultadoBD.MF32S= list.get(114).trim();
		Fase5ResultadoBD.MT24S= list.get(115).trim();
		Fase5ResultadoBD.MT33S= list.get(116).trim();
		Fase5ResultadoBD.MT34B= list.get(117).trim();
		Fase5ResultadoBD.MT34S= list.get(118).trim();
		Fase5ResultadoBD.NON_FINANCIAL_TRD= list.get(119).trim();
		Fase5ResultadoBD.OF32S= list.get(120).trim();
		Fase5ResultadoBD.OF34S= list.get(121).trim();
		Fase5ResultadoBD.PAYMNT03= list.get(122).trim();
		Fase5ResultadoBD.PER222= list.get(123).trim();
		Fase5ResultadoBD.PER224= list.get(124).trim();
		Fase5ResultadoBD.PT20S= list.get(125).trim();
		Fase5ResultadoBD.PT21S= list.get(126).trim();
		Fase5ResultadoBD.PT34S= list.get(127).trim();
		Fase5ResultadoBD.PUBLIC_SERVICE_TRD= list.get(128).trim();
		Fase5ResultadoBD.RE102S= list.get(129).trim();
		Fase5ResultadoBD.RE12S= list.get(130).trim();
		Fase5ResultadoBD.RE30S= list.get(131).trim();
		Fase5ResultadoBD.RE32S= list.get(132).trim();
		Fase5ResultadoBD.RET11= list.get(133).trim();
		Fase5ResultadoBD.RET132= list.get(134).trim();
		Fase5ResultadoBD.RET14= list.get(135).trim();
		Fase5ResultadoBD.RET142= list.get(136).trim();
		Fase5ResultadoBD.RET222= list.get(137).trim();
		Fase5ResultadoBD.RET223= list.get(138).trim();
		Fase5ResultadoBD.RET224= list.get(139).trim();
		Fase5ResultadoBD.RET225= list.get(140).trim();
		Fase5ResultadoBD.RET315= list.get(141).trim();
		Fase5ResultadoBD.RET320= list.get(142).trim();
		Fase5ResultadoBD.RET51= list.get(143).trim();
		Fase5ResultadoBD.RET84= list.get(144).trim();
		Fase5ResultadoBD.REV202= list.get(145).trim();
		Fase5ResultadoBD.REV203= list.get(146).trim();
		Fase5ResultadoBD.REV204= list.get(147).trim();
		Fase5ResultadoBD.REV222= list.get(148).trim();
		Fase5ResultadoBD.REV223= list.get(149).trim();
		Fase5ResultadoBD.REV225= list.get(150).trim();
		Fase5ResultadoBD.REV320= list.get(151).trim();
		Fase5ResultadoBD.REV92= list.get(152).trim();
		Fase5ResultadoBD.REVBAL01= list.get(153).trim();
		Fase5ResultadoBD.REVBAL02= list.get(154).trim();
		Fase5ResultadoBD.REVBAL03= list.get(155).trim();
		Fase5ResultadoBD.REVBAL04= list.get(156).trim();
		Fase5ResultadoBD.REVBAL05= list.get(157).trim();
		Fase5ResultadoBD.REVBAL06= list.get(158).trim();
		Fase5ResultadoBD.REVBAL07= list.get(159).trim();
		Fase5ResultadoBD.REVBAL08= list.get(160).trim();
		Fase5ResultadoBD.REVBAL09= list.get(161).trim();
		Fase5ResultadoBD.REVBAL10= list.get(162).trim();
		Fase5ResultadoBD.REVBAL11= list.get(163).trim();
		Fase5ResultadoBD.REVBAL12= list.get(164).trim();
		Fase5ResultadoBD.REVBAL13= list.get(165).trim();
		Fase5ResultadoBD.REVBAL14= list.get(166).trim();
		Fase5ResultadoBD.REVBAL15= list.get(167).trim();
		Fase5ResultadoBD.REVBAL16= list.get(168).trim();
		Fase5ResultadoBD.REVBAL17= list.get(169).trim();
		Fase5ResultadoBD.REVBAL18= list.get(170).trim();
		Fase5ResultadoBD.REVBAL19= list.get(171).trim();
		Fase5ResultadoBD.REVBAL20= list.get(172).trim();
		Fase5ResultadoBD.REVBAL21= list.get(173).trim();
		Fase5ResultadoBD.REVBAL22= list.get(174).trim();
		Fase5ResultadoBD.REVBAL23= list.get(175).trim();
		Fase5ResultadoBD.REVBAL24= list.get(176).trim();
		Fase5ResultadoBD.RI20S= list.get(177).trim();
		Fase5ResultadoBD.RI21S= list.get(178).trim();
		Fase5ResultadoBD.RI24S= list.get(179).trim();
		Fase5ResultadoBD.RI27S= list.get(180).trim();
		Fase5ResultadoBD.RI29S= list.get(181).trim();
		Fase5ResultadoBD.RI30S= list.get(182).trim();
		Fase5ResultadoBD.RI31S= list.get(183).trim();
		Fase5ResultadoBD.RI32S= list.get(184).trim();
		Fase5ResultadoBD.RLE904= list.get(185).trim();
		Fase5ResultadoBD.RLE905= list.get(186).trim();
		Fase5ResultadoBD.RR102S= list.get(187).trim();
		Fase5ResultadoBD.RR201S= list.get(188).trim();
		Fase5ResultadoBD.RT06S= list.get(189).trim();
		Fase5ResultadoBD.RT201S= list.get(190).trim();
		Fase5ResultadoBD.RT31S= list.get(191).trim();
		Fase5ResultadoBD.RVLR03= list.get(192).trim();
		Fase5ResultadoBD.RVLR06= list.get(193).trim();
		Fase5ResultadoBD.S043S= list.get(194).trim();
		Fase5ResultadoBD.S064D= list.get(195).trim();
		Fase5ResultadoBD.S209D= list.get(196).trim();
		Fase5ResultadoBD.SE21S= list.get(197).trim();
		Fase5ResultadoBD.SE34S= list.get(198).trim();
		Fase5ResultadoBD.TEL31S= list.get(199).trim();
		Fase5ResultadoBD.TEL32S= list.get(200).trim();
		Fase5ResultadoBD.TRANBAL01= list.get(201).trim();
		Fase5ResultadoBD.TRANBAL02= list.get(202).trim();
		Fase5ResultadoBD.TRANBAL03= list.get(203).trim();
		Fase5ResultadoBD.TRANBAL04= list.get(204).trim();
		Fase5ResultadoBD.TRANBAL05= list.get(205).trim();
		Fase5ResultadoBD.TRANBAL06= list.get(206).trim();
		Fase5ResultadoBD.TRANBAL07= list.get(207).trim();
		Fase5ResultadoBD.TRANBAL08= list.get(208).trim();
		Fase5ResultadoBD.TRANBAL09= list.get(209).trim();
		Fase5ResultadoBD.TRANBAL10= list.get(210).trim();
		Fase5ResultadoBD.TRANBAL11= list.get(211).trim();
		Fase5ResultadoBD.TRANBAL12= list.get(212).trim();
		Fase5ResultadoBD.TRANBAL13= list.get(213).trim();
		Fase5ResultadoBD.TRANBAL14= list.get(214).trim();
		Fase5ResultadoBD.TRANBAL15= list.get(215).trim();
		Fase5ResultadoBD.TRANBAL16= list.get(216).trim();
		Fase5ResultadoBD.TRANBAL17= list.get(217).trim();
		Fase5ResultadoBD.TRANBAL18= list.get(218).trim();
		Fase5ResultadoBD.TRANBAL19= list.get(219).trim();
		Fase5ResultadoBD.TRANBAL20= list.get(220).trim();
		Fase5ResultadoBD.TRANBAL21= list.get(221).trim();
		Fase5ResultadoBD.TRANBAL22= list.get(222).trim();
		Fase5ResultadoBD.TRANBAL23= list.get(223).trim();
		Fase5ResultadoBD.TRANBAL24= list.get(224).trim();
		Fase5ResultadoBD.TRV05= list.get(225).trim();
		Fase5ResultadoBD.TRV14= list.get(226).trim();
		Fase5ResultadoBD.TRV17= list.get(227).trim();
		Fase5ResultadoBD.TRV18= list.get(228).trim();
		Fase5ResultadoBD.UL01S= list.get(229).trim();
		Fase5ResultadoBD.UL06S= list.get(230).trim();
		Fase5ResultadoBD.UL21S= list.get(231).trim();
		Fase5ResultadoBD.UL25S= list.get(232).trim();
		Fase5ResultadoBD.UL30S= list.get(233).trim();
		Fase5ResultadoBD.UL32S= list.get(234).trim();
		Fase5ResultadoBD.US20S= list.get(235).trim();
		Fase5ResultadoBD.US25S= list.get(236).trim();
		Fase5ResultadoBD.WALSHR07= list.get(237).trim();
		Fase5ResultadoBD.WD71= list.get(238).trim();


	}


	public static String getSECUENCIA_TERCERO() {
		return SECUENCIA_TERCERO;
	}




	public static String getAGG1101() {
		return AGG1101;
	}


	public static String getAGG1102() {
		return AGG1102;
	}


	public static String getAGG1103() {
		return AGG1103;
	}


	public static String getAGG1104() {
		return AGG1104;
	}


	public static String getAGG1105() {
		return AGG1105;
	}


	public static String getAGG1106() {
		return AGG1106;
	}


	public static String getAGG1107() {
		return AGG1107;
	}


	public static String getAGG1108() {
		return AGG1108;
	}


	public static String getAGG1109() {
		return AGG1109;
	}


	public static String getAGG1110() {
		return AGG1110;
	}


	public static String getAGG1111() {
		return AGG1111;
	}


	public static String getAGG1112() {
		return AGG1112;
	}


	public static String getAGG1113() {
		return AGG1113;
	}


	public static String getAGG1114() {
		return AGG1114;
	}


	public static String getAGG1115() {
		return AGG1115;
	}


	public static String getAGG1116() {
		return AGG1116;
	}


	public static String getAGG1117() {
		return AGG1117;
	}


	public static String getAGG1118() {
		return AGG1118;
	}


	public static String getAGG1119() {
		return AGG1119;
	}


	public static String getAGG1120() {
		return AGG1120;
	}


	public static String getAGG1121() {
		return AGG1121;
	}


	public static String getAGG1122() {
		return AGG1122;
	}


	public static String getAGG1123() {
		return AGG1123;
	}


	public static String getAGG1124() {
		return AGG1124;
	}


	public static String getAGG701() {
		return AGG701;
	}


	public static String getAGG702() {
		return AGG702;
	}


	public static String getAGG703() {
		return AGG703;
	}


	public static String getAGG704() {
		return AGG704;
	}


	public static String getAGG705() {
		return AGG705;
	}


	public static String getAGG706() {
		return AGG706;
	}


	public static String getAGG707() {
		return AGG707;
	}


	public static String getAGG708() {
		return AGG708;
	}


	public static String getAGG709() {
		return AGG709;
	}


	public static String getAGG710() {
		return AGG710;
	}


	public static String getAGG711() {
		return AGG711;
	}


	public static String getAGG712() {
		return AGG712;
	}


	public static String getAGG713() {
		return AGG713;
	}


	public static String getAGG714() {
		return AGG714;
	}


	public static String getAGG715() {
		return AGG715;
	}


	public static String getAGG716() {
		return AGG716;
	}


	public static String getAGG717() {
		return AGG717;
	}


	public static String getAGG718() {
		return AGG718;
	}


	public static String getAGG719() {
		return AGG719;
	}


	public static String getAGG720() {
		return AGG720;
	}


	public static String getAGG721() {
		return AGG721;
	}


	public static String getAGG722() {
		return AGG722;
	}


	public static String getAGG723() {
		return AGG723;
	}


	public static String getAGG724() {
		return AGG724;
	}


	public static String getAGG904() {
		return AGG904;
	}


	public static String getAGG909() {
		return AGG909;
	}


	public static String getAGG910() {
		return AGG910;
	}


	public static String getAGG911() {
		return AGG911;
	}


	public static String getAT27SF() {
		return AT27SF;
	}


	public static String getAT31S() {
		return AT31S;
	}


	public static String getAU21S() {
		return AU21S;
	}


	public static String getAU51A() {
		return AU51A;
	}


	public static String getBC01S() {
		return BC01S;
	}


	public static String getBC20S() {
		return BC20S;
	}


	public static String getBC21S() {
		return BC21S;
	}


	public static String getBI20S() {
		return BI20S;
	}


	public static String getBI21S() {
		return BI21S;
	}


	public static String getBI29S() {
		return BI29S;
	}


	public static String getBI32S() {
		return BI32S;
	}


	public static String getBKC231() {
		return BKC231;
	}


	public static String getBKC232() {
		return BKC232;
	}


	public static String getBKC233() {
		return BKC233;
	}


	public static String getBKC235() {
		return BKC235;
	}


	public static String getBKC252() {
		return BKC252;
	}


	public static String getBKC253() {
		return BKC253;
	}


	public static String getBKC254() {
		return BKC254;
	}


	public static String getBKC255() {
		return BKC255;
	}


	public static String getBR12S() {
		return BR12S;
	}


	public static String getBR20S() {
		return BR20S;
	}


	public static String getBU21S() {
		return BU21S;
	}


	public static String getBU32S() {
		return BU32S;
	}


	public static String getCO04S() {
		return CO04S;
	}


	public static String getCOLLECTION_TRD() {
		return COLLECTION_TRD;
	}


	public static String getCT20S() {
		return CT20S;
	}


	public static String getCT32S() {
		return CT32S;
	}


	public static String getCV25() {
		return CV25;
	}


	public static String getFI20S() {
		return FI20S;
	}


	public static String getFI21S() {
		return FI21S;
	}


	public static String getFI34S() {
		return FI34S;
	}


	public static String getFMD21S() {
		return FMD21S;
	}


	public static String getFR21S() {
		return FR21S;
	}


	public static String getFR32S() {
		return FR32S;
	}


	public static String getFU20S() {
		return FU20S;
	}


	public static String getFU21S() {
		return FU21S;
	}


	public static String getFU32S() {
		return FU32S;
	}


	public static String getFU34S() {
		return FU34S;
	}


	public static String getG103S() {
		return G103S;
	}


	public static String getG209SF() {
		return G209SF;
	}


	public static String getG211S() {
		return G211S;
	}


	public static String getG218C() {
		return G218C;
	}


	public static String getG417S() {
		return G417S;
	}


	public static String getG500S() {
		return G500S;
	}


	public static String getG540S() {
		return G540S;
	}


	public static String getG547S() {
		return G547S;
	}


	public static String getG960S() {
		return G960S;
	}


	public static String getIN06S() {
		return IN06S;
	}


	public static String getIN09S() {
		return IN09S;
	}


	public static String getIN21S() {
		return IN21S;
	}


	public static String getIN25S() {
		return IN25S;
	}


	public static String getIN27S() {
		return IN27S;
	}


	public static String getIN31S() {
		return IN31S;
	}


	public static String getLL21S() {
		return LL21S;
	}


	public static String getLL34S() {
		return LL34S;
	}


	public static String getLMD21S() {
		return LMD21S;
	}


	public static String getLMD32S() {
		return LMD32S;
	}


	public static String getLMD34S() {
		return LMD34S;
	}


	public static String getMF20S() {
		return MF20S;
	}


	public static String getMF24S() {
		return MF24S;
	}


	public static String getMF31S() {
		return MF31S;
	}


	public static String getMF32S() {
		return MF32S;
	}


	public static String getMT24S() {
		return MT24S;
	}


	public static String getMT33S() {
		return MT33S;
	}


	public static String getMT34B() {
		return MT34B;
	}


	public static String getMT34S() {
		return MT34S;
	}


	public static String getNON_FINANCIAL_TRD() {
		return NON_FINANCIAL_TRD;
	}


	public static String getOF32S() {
		return OF32S;
	}


	public static String getOF34S() {
		return OF34S;
	}


	public static String getPAYMNT03() {
		return PAYMNT03;
	}


	public static String getPER222() {
		return PER222;
	}


	public static String getPER224() {
		return PER224;
	}


	public static String getPT20S() {
		return PT20S;
	}


	public static String getPT21S() {
		return PT21S;
	}


	public static String getPT34S() {
		return PT34S;
	}


	public static String getPUBLIC_SERVICE_TRD() {
		return PUBLIC_SERVICE_TRD;
	}


	public static String getRE102S() {
		return RE102S;
	}


	public static String getRE12S() {
		return RE12S;
	}


	public static String getRE30S() {
		return RE30S;
	}


	public static String getRE32S() {
		return RE32S;
	}


	public static String getRET11() {
		return RET11;
	}


	public static String getRET132() {
		return RET132;
	}


	public static String getRET14() {
		return RET14;
	}


	public static String getRET142() {
		return RET142;
	}


	public static String getRET222() {
		return RET222;
	}


	public static String getRET223() {
		return RET223;
	}


	public static String getRET224() {
		return RET224;
	}


	public static String getRET225() {
		return RET225;
	}


	public static String getRET315() {
		return RET315;
	}


	public static String getRET320() {
		return RET320;
	}


	public static String getRET51() {
		return RET51;
	}


	public static String getRET84() {
		return RET84;
	}


	public static String getREV202() {
		return REV202;
	}


	public static String getREV203() {
		return REV203;
	}


	public static String getREV204() {
		return REV204;
	}


	public static String getREV222() {
		return REV222;
	}


	public static String getREV223() {
		return REV223;
	}


	public static String getREV225() {
		return REV225;
	}


	public static String getREV320() {
		return REV320;
	}


	public static String getREV92() {
		return REV92;
	}


	public static String getREVBAL01() {
		return REVBAL01;
	}


	public static String getREVBAL02() {
		return REVBAL02;
	}


	public static String getREVBAL03() {
		return REVBAL03;
	}


	public static String getREVBAL04() {
		return REVBAL04;
	}


	public static String getREVBAL05() {
		return REVBAL05;
	}


	public static String getREVBAL06() {
		return REVBAL06;
	}


	public static String getREVBAL07() {
		return REVBAL07;
	}


	public static String getREVBAL08() {
		return REVBAL08;
	}


	public static String getREVBAL09() {
		return REVBAL09;
	}


	public static String getREVBAL10() {
		return REVBAL10;
	}


	public static String getREVBAL11() {
		return REVBAL11;
	}


	public static String getREVBAL12() {
		return REVBAL12;
	}


	public static String getREVBAL13() {
		return REVBAL13;
	}


	public static String getREVBAL14() {
		return REVBAL14;
	}


	public static String getREVBAL15() {
		return REVBAL15;
	}


	public static String getREVBAL16() {
		return REVBAL16;
	}


	public static String getREVBAL17() {
		return REVBAL17;
	}


	public static String getREVBAL18() {
		return REVBAL18;
	}


	public static String getREVBAL19() {
		return REVBAL19;
	}


	public static String getREVBAL20() {
		return REVBAL20;
	}


	public static String getREVBAL21() {
		return REVBAL21;
	}


	public static String getREVBAL22() {
		return REVBAL22;
	}


	public static String getREVBAL23() {
		return REVBAL23;
	}


	public static String getREVBAL24() {
		return REVBAL24;
	}


	public static String getRI20S() {
		return RI20S;
	}


	public static String getRI21S() {
		return RI21S;
	}


	public static String getRI24S() {
		return RI24S;
	}


	public static String getRI27S() {
		return RI27S;
	}


	public static String getRI29S() {
		return RI29S;
	}


	public static String getRI30S() {
		return RI30S;
	}


	public static String getRI31S() {
		return RI31S;
	}


	public static String getRI32S() {
		return RI32S;
	}


	public static String getRLE904() {
		return RLE904;
	}


	public static String getRLE905() {
		return RLE905;
	}


	public static String getRR102S() {
		return RR102S;
	}


	public static String getRR201S() {
		return RR201S;
	}


	public static String getRT06S() {
		return RT06S;
	}


	public static String getRT201S() {
		return RT201S;
	}


	public static String getRT31S() {
		return RT31S;
	}


	public static String getRVLR03() {
		return RVLR03;
	}


	public static String getRVLR06() {
		return RVLR06;
	}


	public static String getS043S() {
		return S043S;
	}


	public static String getS064D() {
		return S064D;
	}


	public static String getS209D() {
		return S209D;
	}


	public static String getSE21S() {
		return SE21S;
	}


	public static String getSE34S() {
		return SE34S;
	}


	public static String getTEL31S() {
		return TEL31S;
	}


	public static String getTEL32S() {
		return TEL32S;
	}


	public static String getTRANBAL01() {
		return TRANBAL01;
	}


	public static String getTRANBAL02() {
		return TRANBAL02;
	}


	public static String getTRANBAL03() {
		return TRANBAL03;
	}


	public static String getTRANBAL04() {
		return TRANBAL04;
	}


	public static String getTRANBAL05() {
		return TRANBAL05;
	}


	public static String getTRANBAL06() {
		return TRANBAL06;
	}


	public static String getTRANBAL07() {
		return TRANBAL07;
	}


	public static String getTRANBAL08() {
		return TRANBAL08;
	}


	public static String getTRANBAL09() {
		return TRANBAL09;
	}


	public static String getTRANBAL10() {
		return TRANBAL10;
	}


	public static String getTRANBAL11() {
		return TRANBAL11;
	}


	public static String getTRANBAL12() {
		return TRANBAL12;
	}


	public static String getTRANBAL13() {
		return TRANBAL13;
	}


	public static String getTRANBAL14() {
		return TRANBAL14;
	}


	public static String getTRANBAL15() {
		return TRANBAL15;
	}


	public static String getTRANBAL16() {
		return TRANBAL16;
	}


	public static String getTRANBAL17() {
		return TRANBAL17;
	}


	public static String getTRANBAL18() {
		return TRANBAL18;
	}


	public static String getTRANBAL19() {
		return TRANBAL19;
	}


	public static String getTRANBAL20() {
		return TRANBAL20;
	}


	public static String getTRANBAL21() {
		return TRANBAL21;
	}


	public static String getTRANBAL22() {
		return TRANBAL22;
	}


	public static String getTRANBAL23() {
		return TRANBAL23;
	}


	public static String getTRANBAL24() {
		return TRANBAL24;
	}


	public static String getTRV05() {
		return TRV05;
	}


	public static String getTRV14() {
		return TRV14;
	}


	public static String getTRV17() {
		return TRV17;
	}


	public static String getTRV18() {
		return TRV18;
	}


	public static String getUL01S() {
		return UL01S;
	}


	public static String getUL06S() {
		return UL06S;
	}


	public static String getUL21S() {
		return UL21S;
	}


	public static String getUL25S() {
		return UL25S;
	}


	public static String getUL30S() {
		return UL30S;
	}


	public static String getUL32S() {
		return UL32S;
	}


	public static String getUS20S() {
		return US20S;
	}


	public static String getUS25S() {
		return US25S;
	}


	public static String getWALSHR07() {
		return WALSHR07;
	}


	public static String getWD71() {
		return WD71;
	}





}
