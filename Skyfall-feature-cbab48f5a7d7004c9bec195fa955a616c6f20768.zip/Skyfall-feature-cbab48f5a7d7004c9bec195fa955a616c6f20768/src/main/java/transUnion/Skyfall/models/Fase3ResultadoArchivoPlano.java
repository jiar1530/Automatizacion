package transUnion.Skyfall.models;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Fase3ResultadoArchivoPlano {
	//cambiar variables nuevas archivo plano
	
	private static String SECUENCIA_TERCERO = "";
	private static String AGG_SCR_SF = "";
	private static String AGG_SCR_SR = "";
	private static String AGG2402 = "";
	private static String AGG2403 = "";
	private static String AGG2404 = "";
	private static String AGG2405 = "";
	private static String AGG2406 = "";
	private static String AGG2407 = "";
	private static String AGG2408 = "";
	private static String AGG2409 = "";
	private static String AGG2410 = "";
	private static String AGG2411 = "";
	private static String AGG2412 = "";
	private static String AGG2413 = "";
	private static String AGG2414 = "";
	private static String AGG2415 = "";
	private static String AGG2416 = "";
	private static String AGG2417 = "";
	private static String AGG2418 = "";
	private static String AGG2419 = "";
	private static String AGG2420 = "";
	private static String AGG2421 = "";
	private static String AGG2422 = "";
	private static String AGG2423 = "";
	private static String AGG2424 = "";
	private static String AGG301 = "";
	private static String AGG302 = "";
	private static String AGG303 = "";
	private static String AGG304 = "";
	private static String AGG305 = "";
	private static String AGG306 = "";
	private static String AGG307 = "";
	private static String AGG308 = "";
	private static String AGG309 = "";
	private static String AGG310 = "";
	private static String AGG311 = "";
	private static String AGG312 = "";
	private static String AGG313 = "";
	private static String AGG314 = "";
	private static String AGG315 = "";
	private static String AGG316 = "";
	private static String AGG317 = "";
	private static String AGG318 = "";
	private static String AGG319 = "";
	private static String AGG320 = "";
	private static String AGG321 = "";
	private static String AGG322 = "";
	private static String AGG323 = "";
	private static String AGG324 = "";
	private static String AGG905 = "";
	private static String AGG906 = "";
	private static String AT34A = "";
	private static String BI34S = "";
	private static String BKC112 = "";
	private static String BKC225 = "";
	private static String BR20S = "";
	private static String BR27S = "";
	private static String BR29S = "";
	private static String BR34S = "";
	private static String BU09S = "";
	private static String CA09S = "";
	private static String CA70S = "";
	private static String CO04SF = "";
	private static String CREDITVISION = "";
	private static String CREDITVISION_LINK = "";
	private static String CREDITVISION_LINK_SERVICIOS_FIN = "";
	private static String CT24S = "";
	private static String CT30S = "";
	private static String CT31S = "";
	private static String DM211S = "";
	private static String DM214S = "";
	private static String FECHA_CALIFICACION = "";
	private static String FECHA_CORTE_INFO ="";
	
	private static String FR29S = "";
	private static String FR34S = "";
	private static String FS20S = "";
	private static String FU21S = "";
	private static String G212SF = "";
	private static String G218BF = "";
	private static String G220A = "";
	private static String G221D = "";
	private static String G306S = "";
	private static String G410S = "";
	private static String IN01S = "";
	private static String IN34S = "";
	private static String LL09S = "";
	private static String LL30S = "";
	private static String LMD30S = "";
	private static String LS29S = "";
	private static String LS30S = "";
	private static String LS34S = "";
	private static String MF31S = "";
	private static String OD34S = "";
	private static String OF06S = "";
	private static String OF09S = "";
	private static String PAYMNT50 = "";
	private static String PAYMNT65 = "";
	private static String PER201 = "";
	private static String PER223 = "";
	private static String PER233 = "";
	private static String POSITIVE_SF = "";
	private static String POSITIVE_SR = "";
	private static String PT09S = "";
	private static String PT30S = "";
	private static String RET13 = "";
	private static String RET152 = "";
	private static String RET201 = "";
	private static String RET225 = "";
	private static String RET81 = "";
	private static String REV14 = "";
	private static String REV253 = "";
	private static String RI06S = "";
	private static String RLE907 = "";
	private static String RR21S = "";
	private static String RR24S = "";
	private static String RR25S = "";
	private static String RT21S = "";
	private static String RT24S = "";
	private static String RVLR09 = "";
	private static String SE09S = "";
	private static String SEGMENT_SF = "";
	private static String SEGMENT_SR = "";
	private static String TEL09S = "";
	private static String TEL21S = "";
	private static String TEL30S = "";
	private static String TELCO_SF = "";
	private static String TRD = "";
	private static String TRV03 = "";
	private static String TRV12 = "";
	private static String TRV18 = "";
	private static String UL_TRD = "";
	private static String UL29S = "";
	private static String UL34S = "";
	private static String US25S = "";
	private static String WD21 = "";
	private static String WD31 = "";
	private static String WD51 = "";
	private static String WD61 = "";
	private static String WD81 = "";
	private static String WGT_SCR_SF = "";
	private static String WGT_SCR_SR = "";
	private static String NEGATIVE_SF="";
	private static String NEGATIVE_SR ="";

	
	public static void setDatosArchivoPlano(String data) throws ParseException {
		SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		Fase3ResultadoArchivoPlano.SECUENCIA_TERCERO=  data.split("\\|")[0].trim();
		Fase3ResultadoArchivoPlano.FECHA_CALIFICACION=  data.split("\\|")[1].trim().substring(0,10);
		Fase3ResultadoArchivoPlano.FECHA_CORTE_INFO=  data.split("\\|")[2].trim().substring(0,10);
		Fase3ResultadoArchivoPlano.AT34A=  data.split("\\|")[3].trim();
		Fase3ResultadoArchivoPlano.BI34S=  data.split("\\|")[4].trim();
		Fase3ResultadoArchivoPlano.BR27S=  data.split("\\|")[5].trim();
		Fase3ResultadoArchivoPlano.BR29S=  data.split("\\|")[6].trim();
		Fase3ResultadoArchivoPlano.BR34S=  data.split("\\|")[7].trim();
		Fase3ResultadoArchivoPlano.BU09S=  data.split("\\|")[8].trim();
		Fase3ResultadoArchivoPlano.CA09S=  data.split("\\|")[9].trim();
		Fase3ResultadoArchivoPlano.CA70S=  data.split("\\|")[10].trim();
		Fase3ResultadoArchivoPlano.CO04SF=  data.split("\\|")[11].trim();
		Fase3ResultadoArchivoPlano.CT24S=  data.split("\\|")[12].trim();
		Fase3ResultadoArchivoPlano.CT30S=  data.split("\\|")[13].trim();
		Fase3ResultadoArchivoPlano.CT31S=  data.split("\\|")[14].trim();
		Fase3ResultadoArchivoPlano.DM211S=  data.split("\\|")[15].trim();
		Fase3ResultadoArchivoPlano.DM214S=  data.split("\\|")[16].trim();
		Fase3ResultadoArchivoPlano.FR29S=  data.split("\\|")[17].trim();
		Fase3ResultadoArchivoPlano.FR34S=  data.split("\\|")[18].trim();
		Fase3ResultadoArchivoPlano.FS20S=  data.split("\\|")[19].trim();
		Fase3ResultadoArchivoPlano.G212SF=  data.split("\\|")[20].trim();
		Fase3ResultadoArchivoPlano.G218BF=  data.split("\\|")[21].trim();
		Fase3ResultadoArchivoPlano.G220A=  data.split("\\|")[22].trim();
		Fase3ResultadoArchivoPlano.G221D=  data.split("\\|")[23].trim();
		Fase3ResultadoArchivoPlano.G306S=  data.split("\\|")[24].trim();
		Fase3ResultadoArchivoPlano.G410S=  data.split("\\|")[25].trim();
		Fase3ResultadoArchivoPlano.IN01S=  data.split("\\|")[26].trim();
		Fase3ResultadoArchivoPlano.IN34S=  data.split("\\|")[27].trim();
		Fase3ResultadoArchivoPlano.LL09S=  data.split("\\|")[28].trim();
		Fase3ResultadoArchivoPlano.LL30S=  data.split("\\|")[29].trim();
		Fase3ResultadoArchivoPlano.LMD30S=  data.split("\\|")[30].trim();
		Fase3ResultadoArchivoPlano.LS29S=  data.split("\\|")[31].trim();
		Fase3ResultadoArchivoPlano.LS30S=  data.split("\\|")[32].trim();
		Fase3ResultadoArchivoPlano.LS34S=  data.split("\\|")[33].trim();
		Fase3ResultadoArchivoPlano.OD34S=  data.split("\\|")[34].trim();
		Fase3ResultadoArchivoPlano.OF06S=  data.split("\\|")[35].trim();
		Fase3ResultadoArchivoPlano.OF09S=  data.split("\\|")[36].trim();
		Fase3ResultadoArchivoPlano.PT09S=  data.split("\\|")[37].trim();
		Fase3ResultadoArchivoPlano.PT30S=  data.split("\\|")[38].trim();
		Fase3ResultadoArchivoPlano.RI06S=  data.split("\\|")[39].trim();
		Fase3ResultadoArchivoPlano.RR21S=  data.split("\\|")[40].trim();
		Fase3ResultadoArchivoPlano.RR24S=  data.split("\\|")[41].trim();
		Fase3ResultadoArchivoPlano.RR25S=  data.split("\\|")[42].trim();
		Fase3ResultadoArchivoPlano.RT21S=  data.split("\\|")[43].trim();
		Fase3ResultadoArchivoPlano.RT24S=  data.split("\\|")[44].trim();
		Fase3ResultadoArchivoPlano.SE09S=  data.split("\\|")[45].trim();
		Fase3ResultadoArchivoPlano.TEL09S=  data.split("\\|")[46].trim();
		Fase3ResultadoArchivoPlano.TEL21S=  data.split("\\|")[47].trim();
		Fase3ResultadoArchivoPlano.TEL30S=  data.split("\\|")[48].trim();
		Fase3ResultadoArchivoPlano.UL29S=  data.split("\\|")[49].trim();
		Fase3ResultadoArchivoPlano.UL34S=  data.split("\\|")[50].trim();
		Fase3ResultadoArchivoPlano.AGG2402=  data.split("\\|")[51].trim();
		Fase3ResultadoArchivoPlano.AGG2403=  data.split("\\|")[52].trim();
		Fase3ResultadoArchivoPlano.AGG2404=  data.split("\\|")[53].trim();
		Fase3ResultadoArchivoPlano.AGG2405=  data.split("\\|")[54].trim();
		Fase3ResultadoArchivoPlano.AGG2406=  data.split("\\|")[55].trim();
		Fase3ResultadoArchivoPlano.AGG2407=  data.split("\\|")[56].trim();
		Fase3ResultadoArchivoPlano.AGG2408=  data.split("\\|")[57].trim();
		Fase3ResultadoArchivoPlano.AGG2409=  data.split("\\|")[58].trim();
		Fase3ResultadoArchivoPlano.AGG2410=  data.split("\\|")[59].trim();
		Fase3ResultadoArchivoPlano.AGG2411=  data.split("\\|")[60].trim();
		Fase3ResultadoArchivoPlano.AGG2412=  data.split("\\|")[61].trim();
		Fase3ResultadoArchivoPlano.AGG2413=  data.split("\\|")[62].trim();
		Fase3ResultadoArchivoPlano.AGG2414=  data.split("\\|")[63].trim();
		Fase3ResultadoArchivoPlano.AGG2415=  data.split("\\|")[64].trim();
		Fase3ResultadoArchivoPlano.AGG2416=  data.split("\\|")[65].trim();
		Fase3ResultadoArchivoPlano.AGG2417=  data.split("\\|")[66].trim();
		Fase3ResultadoArchivoPlano.AGG2418=  data.split("\\|")[67].trim();
		Fase3ResultadoArchivoPlano.AGG2419=  data.split("\\|")[68].trim();
		Fase3ResultadoArchivoPlano.AGG2420=  data.split("\\|")[69].trim();
		Fase3ResultadoArchivoPlano.AGG2421=  data.split("\\|")[70].trim();
		Fase3ResultadoArchivoPlano.AGG2422=  data.split("\\|")[71].trim();
		Fase3ResultadoArchivoPlano.AGG2423=  data.split("\\|")[72].trim();
		Fase3ResultadoArchivoPlano.AGG2424=  data.split("\\|")[73].trim();
		Fase3ResultadoArchivoPlano.AGG301=  data.split("\\|")[74].trim();
		Fase3ResultadoArchivoPlano.AGG302=  data.split("\\|")[75].trim();
		Fase3ResultadoArchivoPlano.AGG303=  data.split("\\|")[76].trim();
		Fase3ResultadoArchivoPlano.AGG304=  data.split("\\|")[77].trim();
		Fase3ResultadoArchivoPlano.AGG305=  data.split("\\|")[78].trim();
		Fase3ResultadoArchivoPlano.AGG306=  data.split("\\|")[79].trim();
		Fase3ResultadoArchivoPlano.AGG307=  data.split("\\|")[80].trim();
		Fase3ResultadoArchivoPlano.AGG308=  data.split("\\|")[81].trim();
		Fase3ResultadoArchivoPlano.AGG309=  data.split("\\|")[82].trim();
		Fase3ResultadoArchivoPlano.AGG310=  data.split("\\|")[83].trim();
		Fase3ResultadoArchivoPlano.AGG311=  data.split("\\|")[84].trim();
		Fase3ResultadoArchivoPlano.AGG312=  data.split("\\|")[85].trim();
		Fase3ResultadoArchivoPlano.AGG313=  data.split("\\|")[86].trim();
		Fase3ResultadoArchivoPlano.AGG314=  data.split("\\|")[87].trim();
		Fase3ResultadoArchivoPlano.AGG315=  data.split("\\|")[88].trim();
		Fase3ResultadoArchivoPlano.AGG316=  data.split("\\|")[89].trim();
		Fase3ResultadoArchivoPlano.AGG317=  data.split("\\|")[90].trim();
		Fase3ResultadoArchivoPlano.AGG318=  data.split("\\|")[91].trim();
		Fase3ResultadoArchivoPlano.AGG319=  data.split("\\|")[92].trim();
		Fase3ResultadoArchivoPlano.AGG320=  data.split("\\|")[93].trim();
		Fase3ResultadoArchivoPlano.AGG321=  data.split("\\|")[94].trim();
		Fase3ResultadoArchivoPlano.AGG322=  data.split("\\|")[95].trim();
		Fase3ResultadoArchivoPlano.AGG323=  data.split("\\|")[96].trim();
		Fase3ResultadoArchivoPlano.AGG324=  data.split("\\|")[97].trim();
		Fase3ResultadoArchivoPlano.BKC112=  data.split("\\|")[98].trim();
		Fase3ResultadoArchivoPlano.AGG905=  data.split("\\|")[99].trim();
		Fase3ResultadoArchivoPlano.AGG906=  data.split("\\|")[100].trim();
		Fase3ResultadoArchivoPlano.BKC225=  data.split("\\|")[101].trim();
		Fase3ResultadoArchivoPlano.PAYMNT50=  data.split("\\|")[102].trim();
		Fase3ResultadoArchivoPlano.PAYMNT65=  data.split("\\|")[103].trim();
		Fase3ResultadoArchivoPlano.PER201=  data.split("\\|")[104].trim();
		Fase3ResultadoArchivoPlano.PER223=  data.split("\\|")[105].trim();
		Fase3ResultadoArchivoPlano.PER233=  data.split("\\|")[106].trim();
		Fase3ResultadoArchivoPlano.RET13=  data.split("\\|")[107].trim();
		Fase3ResultadoArchivoPlano.RET152=  data.split("\\|")[108].trim();
		Fase3ResultadoArchivoPlano.RET201=  data.split("\\|")[109].trim();
		Fase3ResultadoArchivoPlano.RET81=  data.split("\\|")[110].trim();
		Fase3ResultadoArchivoPlano.REV14=  data.split("\\|")[111].trim();
		Fase3ResultadoArchivoPlano.REV253=  data.split("\\|")[112].trim();
		Fase3ResultadoArchivoPlano.RLE907=  data.split("\\|")[113].trim();
		Fase3ResultadoArchivoPlano.RVLR09=  data.split("\\|")[114].trim();
		Fase3ResultadoArchivoPlano.TRD=  data.split("\\|")[115].trim();
		Fase3ResultadoArchivoPlano.TRV03=  data.split("\\|")[116].trim();
		Fase3ResultadoArchivoPlano.TRV12=  data.split("\\|")[117].trim();
		Fase3ResultadoArchivoPlano.UL_TRD=  data.split("\\|")[118].trim();
		Fase3ResultadoArchivoPlano.WD21=  data.split("\\|")[119].trim();
		Fase3ResultadoArchivoPlano.WD31=  data.split("\\|")[120].trim();
		Fase3ResultadoArchivoPlano.WD51=  data.split("\\|")[121].trim();
		Fase3ResultadoArchivoPlano.WD61=  data.split("\\|")[122].trim();
		Fase3ResultadoArchivoPlano.WD81=  data.split("\\|")[123].trim();
		Fase3ResultadoArchivoPlano.RET225=  data.split("\\|")[124].trim();
		Fase3ResultadoArchivoPlano.BR20S=  data.split("\\|")[125].trim();
		Fase3ResultadoArchivoPlano.FU21S=  data.split("\\|")[126].trim();
		Fase3ResultadoArchivoPlano.US25S=  data.split("\\|")[127].trim();
		Fase3ResultadoArchivoPlano.MF31S=  data.split("\\|")[128].trim();
		Fase3ResultadoArchivoPlano.TRV18=  data.split("\\|")[129].trim();
		Fase3ResultadoArchivoPlano.POSITIVE_SF=  data.split("\\|")[130].trim();
		Fase3ResultadoArchivoPlano.NEGATIVE_SF=  data.split("\\|")[131].trim();
		Fase3ResultadoArchivoPlano.SEGMENT_SF=  data.split("\\|")[132].trim();
		Fase3ResultadoArchivoPlano.TELCO_SF=  data.split("\\|")[133].trim();
		Fase3ResultadoArchivoPlano.WGT_SCR_SF=  data.split("\\|")[134].trim();
		Fase3ResultadoArchivoPlano.AGG_SCR_SF=  data.split("\\|")[135].trim();
		Fase3ResultadoArchivoPlano.POSITIVE_SR=  data.split("\\|")[136].trim();
		Fase3ResultadoArchivoPlano.NEGATIVE_SR=  data.split("\\|")[137].trim();
		Fase3ResultadoArchivoPlano.SEGMENT_SR=  data.split("\\|")[138].trim();
		Fase3ResultadoArchivoPlano.WGT_SCR_SR=  data.split("\\|")[139].trim();
		Fase3ResultadoArchivoPlano.AGG_SCR_SR=  data.split("\\|")[140].trim();
		Fase3ResultadoArchivoPlano.CREDITVISION=  data.split("\\|")[141].trim();
		Fase3ResultadoArchivoPlano.CREDITVISION_LINK_SERVICIOS_FIN=  data.split("\\|")[142].trim();
		Fase3ResultadoArchivoPlano.CREDITVISION_LINK=  data.split("\\|")[143].trim();



	}


	public static String getNEGATIVE_SF() {
		return NEGATIVE_SF;
	}


	public static String getNEGATIVE_SR() {
		return NEGATIVE_SR;
	}


	public static String getSECUENCIA_TERCERO() {
		return SECUENCIA_TERCERO;
	}


	public static String getAGG_SCR_SF() {
		return AGG_SCR_SF;
	}


	public static String getAGG_SCR_SR() {
		return AGG_SCR_SR;
	}


	public static String getAGG2402() {
		return AGG2402;
	}


	public static String getAGG2403() {
		return AGG2403;
	}


	public static String getAGG2404() {
		return AGG2404;
	}


	public static String getAGG2405() {
		return AGG2405;
	}


	public static String getAGG2406() {
		return AGG2406;
	}


	public static String getAGG2407() {
		return AGG2407;
	}


	public static String getAGG2408() {
		return AGG2408;
	}


	public static String getAGG2409() {
		return AGG2409;
	}


	public static String getAGG2410() {
		return AGG2410;
	}


	public static String getAGG2411() {
		return AGG2411;
	}


	public static String getAGG2412() {
		return AGG2412;
	}


	public static String getAGG2413() {
		return AGG2413;
	}


	public static String getAGG2414() {
		return AGG2414;
	}


	public static String getAGG2415() {
		return AGG2415;
	}


	public static String getAGG2416() {
		return AGG2416;
	}


	public static String getAGG2417() {
		return AGG2417;
	}


	public static String getAGG2418() {
		return AGG2418;
	}


	public static String getAGG2419() {
		return AGG2419;
	}


	public static String getAGG2420() {
		return AGG2420;
	}


	public static String getAGG2421() {
		return AGG2421;
	}


	public static String getAGG2422() {
		return AGG2422;
	}


	public static String getAGG2423() {
		return AGG2423;
	}


	public static String getAGG2424() {
		return AGG2424;
	}


	public static String getAGG301() {
		return AGG301;
	}


	public static String getAGG302() {
		return AGG302;
	}


	public static String getAGG303() {
		return AGG303;
	}


	public static String getAGG304() {
		return AGG304;
	}


	public static String getAGG305() {
		return AGG305;
	}


	public static String getAGG306() {
		return AGG306;
	}


	public static String getAGG307() {
		return AGG307;
	}


	public static String getAGG308() {
		return AGG308;
	}


	public static String getAGG309() {
		return AGG309;
	}


	public static String getAGG310() {
		return AGG310;
	}


	public static String getAGG311() {
		return AGG311;
	}


	public static String getAGG312() {
		return AGG312;
	}


	public static String getAGG313() {
		return AGG313;
	}


	public static String getAGG314() {
		return AGG314;
	}


	public static String getAGG315() {
		return AGG315;
	}


	public static String getAGG316() {
		return AGG316;
	}


	public static String getAGG317() {
		return AGG317;
	}


	public static String getAGG318() {
		return AGG318;
	}


	public static String getAGG319() {
		return AGG319;
	}


	public static String getAGG320() {
		return AGG320;
	}


	public static String getAGG321() {
		return AGG321;
	}


	public static String getAGG322() {
		return AGG322;
	}


	public static String getAGG323() {
		return AGG323;
	}


	public static String getAGG324() {
		return AGG324;
	}


	public static String getAGG905() {
		return AGG905;
	}


	public static String getAGG906() {
		return AGG906;
	}


	public static String getAT34A() {
		return AT34A;
	}


	public static String getBI34S() {
		return BI34S;
	}


	public static String getBKC112() {
		return BKC112;
	}


	public static String getBKC225() {
		return BKC225;
	}


	public static String getBR20S() {
		return BR20S;
	}


	public static String getBR27S() {
		return BR27S;
	}


	public static String getBR29S() {
		return BR29S;
	}


	public static String getBR34S() {
		return BR34S;
	}


	public static String getBU09S() {
		return BU09S;
	}


	public static String getCA09S() {
		return CA09S;
	}


	public static String getCA70S() {
		return CA70S;
	}


	public static String getCO04SF() {
		return CO04SF;
	}


	public static String getCREDITVISION() {
		return CREDITVISION;
	}


	public static String getCREDITVISION_LINK() {
		return CREDITVISION_LINK;
	}


	public static String getCREDITVISION_LINK_SERVICIOS_FIN() {
		return CREDITVISION_LINK_SERVICIOS_FIN;
	}


	public static String getCT24S() {
		return CT24S;
	}


	public static String getCT30S() {
		return CT30S;
	}


	public static String getCT31S() {
		return CT31S;
	}


	public static String getDM211S() {
		return DM211S;
	}


	public static String getDM214S() {
		return DM214S;
	}


	public static String getFECHA_CALIFICACION() {
		return FECHA_CALIFICACION;
	}


	public static String getFECHA_CORTE_INFO() {
		return FECHA_CORTE_INFO;
	}


	public static String getFR29S() {
		return FR29S;
	}


	public static String getFR34S() {
		return FR34S;
	}


	public static String getFS20S() {
		return FS20S;
	}


	public static String getFU21S() {
		return FU21S;
	}


	public static String getG212SF() {
		return G212SF;
	}


	public static String getG218BF() {
		return G218BF;
	}


	public static String getG220A() {
		return G220A;
	}


	public static String getG221D() {
		return G221D;
	}


	public static String getG306S() {
		return G306S;
	}


	public static String getG410S() {
		return G410S;
	}


	public static String getIN01S() {
		return IN01S;
	}


	public static String getIN34S() {
		return IN34S;
	}


	public static String getLL09S() {
		return LL09S;
	}


	public static String getLL30S() {
		return LL30S;
	}


	public static String getLMD30S() {
		return LMD30S;
	}


	public static String getLS29S() {
		return LS29S;
	}


	public static String getLS30S() {
		return LS30S;
	}


	public static String getLS34S() {
		return LS34S;
	}


	public static String getMF31S() {
		return MF31S;
	}


	public static String getOD34S() {
		return OD34S;
	}


	public static String getOF06S() {
		return OF06S;
	}


	public static String getOF09S() {
		return OF09S;
	}


	public static String getPAYMNT50() {
		return PAYMNT50;
	}


	public static String getPAYMNT65() {
		return PAYMNT65;
	}


	public static String getPER201() {
		return PER201;
	}


	public static String getPER223() {
		return PER223;
	}


	public static String getPER233() {
		return PER233;
	}


	public static String getPOSITIVE_SF() {
		return POSITIVE_SF;
	}


	public static String getPOSITIVE_SR() {
		return POSITIVE_SR;
	}


	public static String getPT09S() {
		return PT09S;
	}


	public static String getPT30S() {
		return PT30S;
	}


	public static String getRET13() {
		return RET13;
	}


	public static String getRET152() {
		return RET152;
	}


	public static String getRET201() {
		return RET201;
	}


	public static String getRET225() {
		return RET225;
	}


	public static String getRET81() {
		return RET81;
	}


	public static String getREV14() {
		return REV14;
	}


	public static String getREV253() {
		return REV253;
	}


	public static String getRI06S() {
		return RI06S;
	}


	public static String getRLE907() {
		return RLE907;
	}


	public static String getRR21S() {
		return RR21S;
	}


	public static String getRR24S() {
		return RR24S;
	}


	public static String getRR25S() {
		return RR25S;
	}


	public static String getRT21S() {
		return RT21S;
	}


	public static String getRT24S() {
		return RT24S;
	}


	public static String getRVLR09() {
		return RVLR09;
	}


	public static String getSE09S() {
		return SE09S;
	}


	public static String getSEGMENT_SF() {
		return SEGMENT_SF;
	}


	public static String getSEGMENT_SR() {
		return SEGMENT_SR;
	}


	public static String getTEL09S() {
		return TEL09S;
	}


	public static String getTEL21S() {
		return TEL21S;
	}


	public static String getTEL30S() {
		return TEL30S;
	}


	public static String getTELCO_SF() {
		return TELCO_SF;
	}


	public static String getTRD() {
		return TRD;
	}


	public static String getTRV03() {
		return TRV03;
	}


	public static String getTRV12() {
		return TRV12;
	}


	public static String getTRV18() {
		return TRV18;
	}


	public static String getUL_TRD() {
		return UL_TRD;
	}


	public static String getUL29S() {
		return UL29S;
	}


	public static String getUL34S() {
		return UL34S;
	}


	public static String getUS25S() {
		return US25S;
	}


	public static String getWD21() {
		return WD21;
	}


	public static String getWD31() {
		return WD31;
	}


	public static String getWD51() {
		return WD51;
	}


	public static String getWD61() {
		return WD61;
	}


	public static String getWD81() {
		return WD81;
	}


	public static String getWGT_SCR_SF() {
		return WGT_SCR_SF;
	}


	public static String getWGT_SCR_SR() {
		return WGT_SCR_SR;
	}
	
	

}


