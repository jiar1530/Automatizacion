package transUnion.Skyfall.models;

import java.text.ParseException;
import java.util.List;



public class Fase2ResultadoBD {
	private static String SECUENCIA ="";
	private static String CV_SCORE ="";
	private static String AT31S ="";
	private static String AT34A ="";
	private static String AU21S ="";
	private static String BC01S ="";
	private static String BC20S ="";
	private static String BC21S ="";
	private static String BI20S ="";
	private static String BI21S ="";
	private static String BI29S ="";
	private static String BI32S ="";
	private static String BI34S ="";
	private static String BR12S ="";
	private static String BR20S ="";
	private static String BR27S ="";
	private static String BR29S ="";
	private static String BR34S ="";
	private static String BU09S ="";
	private static String BU21S ="";
	private static String BU32S ="";
	private static String CA09S ="";
	private static String CA70S ="";
	private static String CO04S ="";
	private static String CO04SF ="";
	private static String CT20S ="";
	private static String CT24S ="";
	private static String CT30S ="";
	private static String CT31S ="";
	private static String CT32S ="";
	private static String DM211S ="";
	private static String DM214S ="";
	private static String FI20S ="";
	private static String FI21S ="";
	private static String FI34S ="";
	private static String FMD21S ="";
	private static String FR21S ="";
	private static String FR29S ="";
	private static String FR32S ="";
	private static String FR34S ="";
	private static String FS20S ="";
	private static String FU20S ="";
	private static String FU21S ="";
	private static String FU32S ="";
	private static String FU34S ="";
	private static String G103S ="";
	private static String G209SF ="";
	private static String G211S ="";
	private static String G212SF ="";
	private static String G218BF ="";
	private static String G220A ="";
	private static String G221D ="";
	private static String G417S ="";
	private static String G500S ="";
	private static String G540S ="";
	private static String G547S ="";
	private static String G960S ="";
	private static String IN01S ="";
	private static String IN06S ="";
	private static String IN09S ="";
	private static String IN21S ="";
	private static String IN25S ="";
	private static String IN27S ="";
	private static String IN31S ="";
	private static String IN34S ="";
	private static String LL09S ="";
	private static String LL21S ="";
	private static String LL30S ="";
	private static String LL34S ="";
	private static String LMD21S ="";
	private static String LMD30S ="";
	private static String LMD32S ="";
	private static String LMD34S ="";
	private static String LS29S ="";
	private static String LS30S ="";
	private static String LS34S ="";
	private static String MF20S ="";
	private static String MF24S ="";
	private static String MF31S ="";
	private static String MF32S ="";
	private static String MT24S ="";
	private static String MT33S ="";
	private static String MT34B ="";
	private static String MT34S ="";
	private static String OD34S ="";
	private static String OF06S ="";
	private static String OF09S ="";
	private static String OF32S ="";
	private static String OF34S ="";
	private static String PT09S ="";
	private static String PT20S ="";
	private static String PT21S ="";
	private static String PT30S ="";
	private static String PT34S ="";
	private static String RE102S ="";
	private static String RE12S ="";
	private static String RE30S ="";
	private static String RE32S ="";
	private static String RI06S ="";
	private static String RI20S ="";
	private static String RI21S ="";
	private static String RI24S ="";
	private static String RI27S ="";
	private static String RI29S ="";
	private static String RI30S ="";
	private static String RI31S ="";
	private static String RI32S ="";
	private static String RR102S ="";
	private static String RR201S ="";
	private static String RR21S ="";
	private static String RR24S ="";
	private static String RR25S ="";
	private static String RT06S ="";
	private static String RT201S ="";
	private static String RT21S ="";
	private static String RT24S ="";
	private static String RT31S ="";
	private static String S064D ="";
	private static String S209D ="";
	private static String SE09S ="";
	private static String SE21S ="";
	private static String SE34S ="";
	private static String TEL09S ="";
	private static String TEL21S ="";
	private static String TEL30S ="";
	private static String TEL31S ="";
	private static String TEL32S ="";
	private static String UL01S ="";
	private static String UL06S ="";
	private static String UL21S ="";
	private static String UL25S ="";
	private static String UL29S ="";
	private static String UL30S ="";
	private static String UL32S ="";
	private static String UL34S ="";
	private static String US25S ="";
	private static String AGG1101 ="";
	private static String AGG1102 ="";
	private static String AGG1103 ="";
	private static String AGG1104 ="";
	private static String AGG1105 ="";
	private static String AGG1106 ="";
	private static String AGG1107 ="";
	private static String AGG1108 ="";
	private static String AGG1109 ="";
	private static String AGG1110 ="";
	private static String AGG1111 ="";
	private static String AGG1112 ="";
	private static String AGG1113 ="";
	private static String AGG1114 ="";
	private static String AGG1115 ="";
	private static String AGG1116 ="";
	private static String AGG1117 ="";
	private static String AGG1118 ="";
	private static String AGG1119 ="";
	private static String AGG1120 ="";
	private static String AGG1121 ="";
	private static String AGG1122 ="";
	private static String AGG1123 ="";
	private static String AGG1124 ="";
	private static String AGG2401 ="";
	private static String AGG2402 ="";
	private static String AGG2403 ="";
	private static String AGG2404 ="";
	private static String AGG2405 ="";
	private static String AGG2406 ="";
	private static String AGG2407 ="";
	private static String AGG2408 ="";
	private static String AGG2409 ="";
	private static String AGG2410 ="";
	private static String AGG2411 ="";
	private static String AGG2412 ="";
	private static String AGG2413 ="";
	private static String AGG2414 ="";
	private static String AGG2415 ="";
	private static String AGG2416 ="";
	private static String AGG2417 ="";
	private static String AGG2418 ="";
	private static String AGG2419 ="";
	private static String AGG2420 ="";
	private static String AGG2421 ="";
	private static String AGG2422 ="";
	private static String AGG2423 ="";
	private static String AGG2424 ="";
	private static String AGG301 ="";
	private static String AGG302 ="";
	private static String AGG303 ="";
	private static String AGG304 ="";
	private static String AGG305 ="";
	private static String AGG306 ="";
	private static String AGG307 ="";
	private static String AGG308 ="";
	private static String AGG309 ="";
	private static String AGG310 ="";
	private static String AGG311 ="";
	private static String AGG312 ="";
	private static String AGG313 ="";
	private static String AGG314 ="";
	private static String AGG315 ="";
	private static String AGG316 ="";
	private static String AGG317 ="";
	private static String AGG318 ="";
	private static String AGG319 ="";
	private static String AGG320 ="";
	private static String AGG321 ="";
	private static String AGG322 ="";
	private static String AGG323 ="";
	private static String AGG324 ="";
	private static String AGG701 ="";
	private static String AGG702 ="";
	private static String AGG703 ="";
	private static String AGG704 ="";
	private static String AGG705 ="";
	private static String AGG706 ="";
	private static String AGG707 ="";
	private static String AGG708 ="";
	private static String AGG709 ="";
	private static String AGG710 ="";
	private static String AGG711 ="";
	private static String AGG712 ="";
	private static String AGG713 ="";
	private static String AGG714 ="";
	private static String AGG715 ="";
	private static String AGG716 ="";
	private static String AGG717 ="";
	private static String AGG718 ="";
	private static String AGG719 ="";
	private static String AGG720 ="";
	private static String AGG721 ="";
	private static String AGG722 ="";
	private static String AGG723 ="";
	private static String AGG724 ="";
	private static String AGG904 ="";
	private static String AGG905 ="";
	private static String AGG906 ="";
	private static String AGG909 ="";
	private static String AGG910 ="";
	private static String AGG911 ="";
	private static String BKC112 ="";
	private static String BKC225 ="";
	private static String BKC231 ="";
	private static String BKC232 ="";
	private static String BKC233 ="";
	private static String BKC235 ="";
	private static String BKC252 ="";
	private static String BKC253 ="";
	private static String BKC254 ="";
	private static String BKC255 ="";
	private static String COLLECTION_TRD ="";
	private static String CV25 ="";
	private static String G306S ="";
	private static String G410S ="";
	private static String NON_FINANCIAL_TRD ="";
	private static String PAYMNT03 ="";
	private static String PAYMNT50 ="";
	private static String PAYMNT65 ="";
	private static String PER201 ="";
	private static String PER222 ="";
	private static String PER223 ="";
	private static String PER224 ="";
	private static String PER233 ="";
	private static String PUBLIC_SERVICE_TRD ="";
	private static String RET11 ="";
	private static String RET13 ="";
	private static String RET132 ="";
	private static String RET14 ="";
	private static String RET142 ="";
	private static String RET152 ="";
	private static String RET201 ="";
	private static String RET222 ="";
	private static String RET223 ="";
	private static String RET224 ="";
	private static String RET225 ="";
	private static String RET315 ="";
	private static String RET320 ="";
	private static String RET51 ="";
	private static String RET81 ="";
	private static String RET84 ="";
	private static String REV14 ="";
	private static String REV202 ="";
	private static String REV203 ="";
	private static String REV204 ="";
	private static String REV222 ="";
	private static String REV223 ="";
	private static String REV225 ="";
	private static String REV253 ="";
	private static String REV320 ="";
	private static String REVBAL01 ="";
	private static String REVBAL02 ="";
	private static String REVBAL03 ="";
	private static String REVBAL04 ="";
	private static String REVBAL05 ="";
	private static String REVBAL06 ="";
	private static String REVBAL07 ="";
	private static String REVBAL08 ="";
	private static String REVBAL09 ="";
	private static String REVBAL10 ="";
	private static String REVBAL11 ="";
	private static String REVBAL12 ="";
	private static String REVBAL13 ="";
	private static String REVBAL14 ="";
	private static String REVBAL15 ="";
	private static String REVBAL16 ="";
	private static String REVBAL17 ="";
	private static String REVBAL18 ="";
	private static String REVBAL19 ="";
	private static String REVBAL20 ="";
	private static String REVBAL21 ="";
	private static String REVBAL22 ="";
	private static String REVBAL23 ="";
	private static String REVBAL24 ="";
	private static String RLE904 ="";
	private static String RLE905 ="";
	private static String RLE907 ="";
	private static String RVLR03 ="";
	private static String RVLR06 ="";
	private static String RVLR09 ="";
	private static String TRANBAL01 ="";
	private static String TRANBAL02 ="";
	private static String TRANBAL03 ="";
	private static String TRANBAL04 ="";
	private static String TRANBAL05 ="";
	private static String TRANBAL06 ="";
	private static String TRANBAL07 ="";
	private static String TRANBAL08 ="";
	private static String TRANBAL09 ="";
	private static String TRANBAL10 ="";
	private static String TRANBAL11 ="";
	private static String TRANBAL12 ="";
	private static String TRANBAL13 ="";
	private static String TRANBAL14 ="";
	private static String TRANBAL15 ="";
	private static String TRANBAL16 ="";
	private static String TRANBAL17 ="";
	private static String TRANBAL18 ="";
	private static String TRANBAL19 ="";
	private static String TRANBAL20 ="";
	private static String TRANBAL21 ="";
	private static String TRANBAL22 ="";
	private static String TRANBAL23 ="";
	private static String TRANBAL24 ="";
	private static String TRD ="";
	private static String TRV03 ="";
	private static String TRV05 ="";
	private static String TRV12 ="";
	private static String TRV14 ="";
	private static String TRV17 ="";
	private static String TRV18 ="";
	private static String UL_TRD ="";
	private static String WALSHR07 ="";
	private static String WD21 ="";
	private static String WD31 ="";
	private static String WD51 ="";
	private static String WD61 ="";
	private static String WD71 ="";
	private static String WD81 ="";

	
	
	public static void setDatosBD(List<String> list) throws ParseException {
		

		Fase2ResultadoBD.SECUENCIA	=	list.get(0).trim();
		Fase2ResultadoBD.AGG1101	=	list.get(1).trim();
		Fase2ResultadoBD.AGG1102	=	list.get(2).trim();
		Fase2ResultadoBD.AGG1103	=	list.get(3).trim();
		Fase2ResultadoBD.AGG1104	=	list.get(4).trim();
		Fase2ResultadoBD.AGG1105	=	list.get(5).trim();
		Fase2ResultadoBD.AGG1106	=	list.get(6).trim();
		Fase2ResultadoBD.AGG1107	=	list.get(7).trim();
		Fase2ResultadoBD.AGG1108	=	list.get(8).trim();
		Fase2ResultadoBD.AGG1109	=	list.get(9).trim();
		Fase2ResultadoBD.AGG1110	=	list.get(10).trim();
		Fase2ResultadoBD.AGG1111	=	list.get(11).trim();
		Fase2ResultadoBD.AGG1112	=	list.get(12).trim();
		Fase2ResultadoBD.AGG1113	=	list.get(13).trim();
		Fase2ResultadoBD.AGG1114	=	list.get(14).trim();
		Fase2ResultadoBD.AGG1115	=	list.get(15).trim();
		Fase2ResultadoBD.AGG1116	=	list.get(16).trim();
		Fase2ResultadoBD.AGG1117	=	list.get(17).trim();
		Fase2ResultadoBD.AGG1118	=	list.get(18).trim();
		Fase2ResultadoBD.AGG1119	=	list.get(19).trim();
		Fase2ResultadoBD.AGG1120	=	list.get(20).trim();
		Fase2ResultadoBD.AGG1121	=	list.get(21).trim();
		Fase2ResultadoBD.AGG1122	=	list.get(22).trim();
		Fase2ResultadoBD.AGG1123	=	list.get(23).trim();
		Fase2ResultadoBD.AGG1124	=	list.get(24).trim();
		Fase2ResultadoBD.AGG2401	=	list.get(25).trim();
		Fase2ResultadoBD.AGG2402	=	list.get(26).trim();
		Fase2ResultadoBD.AGG2403	=	list.get(27).trim();
		Fase2ResultadoBD.AGG2404	=	list.get(28).trim();
		Fase2ResultadoBD.AGG2405	=	list.get(29).trim();
		Fase2ResultadoBD.AGG2406	=	list.get(30).trim();
		Fase2ResultadoBD.AGG2407	=	list.get(31).trim();
		Fase2ResultadoBD.AGG2408	=	list.get(32).trim();
		Fase2ResultadoBD.AGG2409	=	list.get(33).trim();
		Fase2ResultadoBD.AGG2410	=	list.get(34).trim();
		Fase2ResultadoBD.AGG2411	=	list.get(35).trim();
		Fase2ResultadoBD.AGG2412	=	list.get(36).trim();
		Fase2ResultadoBD.AGG2413	=	list.get(37).trim();
		Fase2ResultadoBD.AGG2414	=	list.get(38).trim();
		Fase2ResultadoBD.AGG2415	=	list.get(39).trim();
		Fase2ResultadoBD.AGG2416	=	list.get(40).trim();
		Fase2ResultadoBD.AGG2417	=	list.get(41).trim();
		Fase2ResultadoBD.AGG2418	=	list.get(42).trim();
		Fase2ResultadoBD.AGG2419	=	list.get(43).trim();
		Fase2ResultadoBD.AGG2420	=	list.get(44).trim();
		Fase2ResultadoBD.AGG2421	=	list.get(45).trim();
		Fase2ResultadoBD.AGG2422	=	list.get(46).trim();
		Fase2ResultadoBD.AGG2423	=	list.get(47).trim();
		Fase2ResultadoBD.AGG2424	=	list.get(48).trim();
		Fase2ResultadoBD.AGG301	=	list.get(49).trim();
		Fase2ResultadoBD.AGG302	=	list.get(50).trim();
		Fase2ResultadoBD.AGG303	=	list.get(51).trim();
		Fase2ResultadoBD.AGG304	=	list.get(52).trim();
		Fase2ResultadoBD.AGG305	=	list.get(53).trim();
		Fase2ResultadoBD.AGG306	=	list.get(54).trim();
		Fase2ResultadoBD.AGG307	=	list.get(55).trim();
		Fase2ResultadoBD.AGG308	=	list.get(56).trim();
		Fase2ResultadoBD.AGG309	=	list.get(57).trim();
		Fase2ResultadoBD.AGG310	=	list.get(58).trim();
		Fase2ResultadoBD.AGG311	=	list.get(59).trim();
		Fase2ResultadoBD.AGG312	=	list.get(60).trim();
		Fase2ResultadoBD.AGG313	=	list.get(61).trim();
		Fase2ResultadoBD.AGG314	=	list.get(62).trim();
		Fase2ResultadoBD.AGG315	=	list.get(63).trim();
		Fase2ResultadoBD.AGG316	=	list.get(64).trim();
		Fase2ResultadoBD.AGG317	=	list.get(65).trim();
		Fase2ResultadoBD.AGG318	=	list.get(66).trim();
		Fase2ResultadoBD.AGG319	=	list.get(67).trim();
		Fase2ResultadoBD.AGG320	=	list.get(68).trim();
		Fase2ResultadoBD.AGG321	=	list.get(69).trim();
		Fase2ResultadoBD.AGG322	=	list.get(70).trim();
		Fase2ResultadoBD.AGG323	=	list.get(71).trim();
		Fase2ResultadoBD.AGG324	=	list.get(72).trim();
		Fase2ResultadoBD.AGG701	=	list.get(73).trim();
		Fase2ResultadoBD.AGG702	=	list.get(74).trim();
		Fase2ResultadoBD.AGG703	=	list.get(75).trim();
		Fase2ResultadoBD.AGG704	=	list.get(76).trim();
		Fase2ResultadoBD.AGG705	=	list.get(77).trim();
		Fase2ResultadoBD.AGG706	=	list.get(78).trim();
		Fase2ResultadoBD.AGG707	=	list.get(79).trim();
		Fase2ResultadoBD.AGG708	=	list.get(80).trim();
		Fase2ResultadoBD.AGG709	=	list.get(81).trim();
		Fase2ResultadoBD.AGG710	=	list.get(82).trim();
		Fase2ResultadoBD.AGG711	=	list.get(83).trim();
		Fase2ResultadoBD.AGG712	=	list.get(84).trim();
		Fase2ResultadoBD.AGG713	=	list.get(85).trim();
		Fase2ResultadoBD.AGG714	=	list.get(86).trim();
		Fase2ResultadoBD.AGG715	=	list.get(87).trim();
		Fase2ResultadoBD.AGG716	=	list.get(88).trim();
		Fase2ResultadoBD.AGG717	=	list.get(89).trim();
		Fase2ResultadoBD.AGG718	=	list.get(90).trim();
		Fase2ResultadoBD.AGG719	=	list.get(91).trim();
		Fase2ResultadoBD.AGG720	=	list.get(92).trim();
		Fase2ResultadoBD.AGG721	=	list.get(93).trim();
		Fase2ResultadoBD.AGG722	=	list.get(94).trim();
		Fase2ResultadoBD.AGG723	=	list.get(95).trim();
		Fase2ResultadoBD.AGG724	=	list.get(96).trim();
		Fase2ResultadoBD.AGG904	=	list.get(97).trim();
		Fase2ResultadoBD.AGG905	=	list.get(98).trim();
		Fase2ResultadoBD.AGG906	=	list.get(99).trim();
		Fase2ResultadoBD.AGG909	=	list.get(100).trim();
		Fase2ResultadoBD.AGG910	=	list.get(101).trim();
		Fase2ResultadoBD.AGG911	=	list.get(102).trim();
		Fase2ResultadoBD.AT31S	=	list.get(103).trim();
		Fase2ResultadoBD.AT34A	=	list.get(104).trim();
		Fase2ResultadoBD.AU21S	=	list.get(105).trim();
		Fase2ResultadoBD.BC01S	=	list.get(106).trim();
		Fase2ResultadoBD.BC20S	=	list.get(107).trim();
		Fase2ResultadoBD.BC21S	=	list.get(108).trim();
		Fase2ResultadoBD.BI20S	=	list.get(109).trim();
		Fase2ResultadoBD.BI21S	=	list.get(110).trim();
		Fase2ResultadoBD.BI29S	=	list.get(111).trim();
		Fase2ResultadoBD.BI32S	=	list.get(112).trim();
		Fase2ResultadoBD.BI34S	=	list.get(113).trim();
		Fase2ResultadoBD.BKC112	=	list.get(114).trim();
		Fase2ResultadoBD.BKC225	=	list.get(115).trim();
		Fase2ResultadoBD.BKC231	=	list.get(116).trim();
		Fase2ResultadoBD.BKC232	=	list.get(117).trim();
		Fase2ResultadoBD.BKC233	=	list.get(118).trim();
		Fase2ResultadoBD.BKC235	=	list.get(119).trim();
		Fase2ResultadoBD.BKC252	=	list.get(120).trim();
		Fase2ResultadoBD.BKC253	=	list.get(121).trim();
		Fase2ResultadoBD.BKC254	=	list.get(122).trim();
		Fase2ResultadoBD.BKC255	=	list.get(123).trim();
		Fase2ResultadoBD.BR12S	=	list.get(124).trim();
		Fase2ResultadoBD.BR20S	=	list.get(125).trim();
		Fase2ResultadoBD.BR27S	=	list.get(126).trim();
		Fase2ResultadoBD.BR29S	=	list.get(127).trim();
		Fase2ResultadoBD.BR34S	=	list.get(128).trim();
		Fase2ResultadoBD.BU09S	=	list.get(129).trim();
		Fase2ResultadoBD.BU21S	=	list.get(130).trim();
		Fase2ResultadoBD.BU32S	=	list.get(131).trim();
		Fase2ResultadoBD.CA09S	=	list.get(132).trim();
		Fase2ResultadoBD.CA70S	=	list.get(133).trim();
		Fase2ResultadoBD.CO04S	=	list.get(134).trim();
		Fase2ResultadoBD.CO04SF	=	list.get(135).trim();
		Fase2ResultadoBD.COLLECTION_TRD	=	list.get(136).trim();
		Fase2ResultadoBD.CT20S	=	list.get(137).trim();
		Fase2ResultadoBD.CT24S	=	list.get(138).trim();
		Fase2ResultadoBD.CT30S	=	list.get(139).trim();
		Fase2ResultadoBD.CT31S	=	list.get(140).trim();
		Fase2ResultadoBD.CT32S	=	list.get(141).trim();
		Fase2ResultadoBD.CV25	=	list.get(142).trim();
		Fase2ResultadoBD.DM211S	=	list.get(143).trim();
		Fase2ResultadoBD.DM214S	=	list.get(144).trim();
		Fase2ResultadoBD.FI20S	=	list.get(145).trim();
		Fase2ResultadoBD.FI21S	=	list.get(146).trim();
		Fase2ResultadoBD.FI34S	=	list.get(147).trim();
		Fase2ResultadoBD.FMD21S	=	list.get(148).trim();
		Fase2ResultadoBD.FR21S	=	list.get(149).trim();
		Fase2ResultadoBD.FR29S	=	list.get(150).trim();
		Fase2ResultadoBD.FR32S	=	list.get(151).trim();
		Fase2ResultadoBD.FR34S	=	list.get(152).trim();
		Fase2ResultadoBD.FS20S	=	list.get(153).trim();
		Fase2ResultadoBD.FU20S	=	list.get(154).trim();
		Fase2ResultadoBD.FU21S	=	list.get(155).trim();
		Fase2ResultadoBD.FU32S	=	list.get(156).trim();
		Fase2ResultadoBD.FU34S	=	list.get(157).trim();
		Fase2ResultadoBD.G103S	=	list.get(158).trim();
		Fase2ResultadoBD.G209SF	=	list.get(159).trim();
		Fase2ResultadoBD.G211S	=	list.get(160).trim();
		Fase2ResultadoBD.G212SF	=	list.get(161).trim();
		Fase2ResultadoBD.G218BF	=	list.get(162).trim();
		Fase2ResultadoBD.G220A	=	list.get(163).trim();
		Fase2ResultadoBD.G221D	=	list.get(164).trim();
		Fase2ResultadoBD.G306S	=	list.get(165).trim();
		Fase2ResultadoBD.G410S	=	list.get(166).trim();
		Fase2ResultadoBD.G417S	=	list.get(167).trim();
		Fase2ResultadoBD.G500S	=	list.get(168).trim();
		Fase2ResultadoBD.G540S	=	list.get(169).trim();
		Fase2ResultadoBD.G547S	=	list.get(170).trim();
		Fase2ResultadoBD.G960S	=	list.get(171).trim();
		Fase2ResultadoBD.IN01S	=	list.get(172).trim();
		Fase2ResultadoBD.IN06S	=	list.get(173).trim();
		Fase2ResultadoBD.IN09S	=	list.get(174).trim();
		Fase2ResultadoBD.IN21S	=	list.get(175).trim();
		Fase2ResultadoBD.IN25S	=	list.get(176).trim();
		Fase2ResultadoBD.IN27S	=	list.get(177).trim();
		Fase2ResultadoBD.IN31S	=	list.get(178).trim();
		Fase2ResultadoBD.IN34S	=	list.get(179).trim();
		Fase2ResultadoBD.LL09S	=	list.get(180).trim();
		Fase2ResultadoBD.LL21S	=	list.get(181).trim();
		Fase2ResultadoBD.LL30S	=	list.get(182).trim();
		Fase2ResultadoBD.LL34S	=	list.get(183).trim();
		Fase2ResultadoBD.LMD21S	=	list.get(184).trim();
		Fase2ResultadoBD.LMD30S	=	list.get(185).trim();
		Fase2ResultadoBD.LMD32S	=	list.get(186).trim();
		Fase2ResultadoBD.LMD34S	=	list.get(187).trim();
		Fase2ResultadoBD.LS29S	=	list.get(188).trim();
		Fase2ResultadoBD.LS30S	=	list.get(189).trim();
		Fase2ResultadoBD.LS34S	=	list.get(190).trim();
		Fase2ResultadoBD.MF20S	=	list.get(191).trim();
		Fase2ResultadoBD.MF24S	=	list.get(192).trim();
		Fase2ResultadoBD.MF31S	=	list.get(193).trim();
		Fase2ResultadoBD.MF32S	=	list.get(194).trim();
		Fase2ResultadoBD.MT24S	=	list.get(195).trim();
		Fase2ResultadoBD.MT33S	=	list.get(196).trim();
		Fase2ResultadoBD.MT34B	=	list.get(197).trim();
		Fase2ResultadoBD.MT34S	=	list.get(198).trim();
		Fase2ResultadoBD.NON_FINANCIAL_TRD	=	list.get(199).trim();
		Fase2ResultadoBD.OD34S	=	list.get(200).trim();
		Fase2ResultadoBD.OF06S	=	list.get(201).trim();
		Fase2ResultadoBD.OF09S	=	list.get(202).trim();
		Fase2ResultadoBD.OF32S	=	list.get(203).trim();
		Fase2ResultadoBD.OF34S	=	list.get(204).trim();
		Fase2ResultadoBD.PAYMNT03	=	list.get(205).trim();
		Fase2ResultadoBD.PAYMNT50	=	list.get(206).trim();
		Fase2ResultadoBD.PAYMNT65	=	list.get(207).trim();
		Fase2ResultadoBD.PER201	=	list.get(208).trim();
		Fase2ResultadoBD.PER222	=	list.get(209).trim();
		Fase2ResultadoBD.PER223	=	list.get(210).trim();
		Fase2ResultadoBD.PER224	=	list.get(211).trim();
		Fase2ResultadoBD.PER233	=	list.get(212).trim();
		Fase2ResultadoBD.PT09S	=	list.get(213).trim();
		Fase2ResultadoBD.PT20S	=	list.get(214).trim();
		Fase2ResultadoBD.PT21S	=	list.get(215).trim();
		Fase2ResultadoBD.PT30S	=	list.get(216).trim();
		Fase2ResultadoBD.PT34S	=	list.get(217).trim();
		Fase2ResultadoBD.PUBLIC_SERVICE_TRD	=	list.get(218).trim();
		Fase2ResultadoBD.RE102S	=	list.get(219).trim();
		Fase2ResultadoBD.RE12S	=	list.get(220).trim();
		Fase2ResultadoBD.RE30S	=	list.get(221).trim();
		Fase2ResultadoBD.RE32S	=	list.get(222).trim();
		Fase2ResultadoBD.RET11	=	list.get(223).trim();
		Fase2ResultadoBD.RET13	=	list.get(224).trim();
		Fase2ResultadoBD.RET132	=	list.get(225).trim();
		Fase2ResultadoBD.RET14	=	list.get(226).trim();
		Fase2ResultadoBD.RET142	=	list.get(227).trim();
		Fase2ResultadoBD.RET152	=	list.get(228).trim();
		Fase2ResultadoBD.RET201	=	list.get(229).trim();
		Fase2ResultadoBD.RET222	=	list.get(230).trim();
		Fase2ResultadoBD.RET223	=	list.get(231).trim();
		Fase2ResultadoBD.RET224	=	list.get(232).trim();
		Fase2ResultadoBD.RET225	=	list.get(233).trim();
		Fase2ResultadoBD.RET315	=	list.get(234).trim();
		Fase2ResultadoBD.RET320	=	list.get(235).trim();
		Fase2ResultadoBD.RET51	=	list.get(236).trim();
		Fase2ResultadoBD.RET81	=	list.get(237).trim();
		Fase2ResultadoBD.RET84	=	list.get(238).trim();
		Fase2ResultadoBD.REV14	=	list.get(239).trim();
		Fase2ResultadoBD.REV202	=	list.get(240).trim();
		Fase2ResultadoBD.REV203	=	list.get(241).trim();
		Fase2ResultadoBD.REV204	=	list.get(242).trim();
		Fase2ResultadoBD.REV222	=	list.get(243).trim();
		Fase2ResultadoBD.REV223	=	list.get(244).trim();
		Fase2ResultadoBD.REV225	=	list.get(245).trim();
		Fase2ResultadoBD.REV253	=	list.get(246).trim();
		Fase2ResultadoBD.REV320	=	list.get(247).trim();
		Fase2ResultadoBD.REVBAL01	=	list.get(248).trim();
		Fase2ResultadoBD.REVBAL02	=	list.get(249).trim();
		Fase2ResultadoBD.REVBAL03	=	list.get(250).trim();
		Fase2ResultadoBD.REVBAL04	=	list.get(251).trim();
		Fase2ResultadoBD.REVBAL05	=	list.get(252).trim();
		Fase2ResultadoBD.REVBAL06	=	list.get(253).trim();
		Fase2ResultadoBD.REVBAL07	=	list.get(254).trim();
		Fase2ResultadoBD.REVBAL08	=	list.get(255).trim();
		Fase2ResultadoBD.REVBAL09	=	list.get(256).trim();
		Fase2ResultadoBD.REVBAL10	=	list.get(257).trim();
		Fase2ResultadoBD.REVBAL11	=	list.get(258).trim();
		Fase2ResultadoBD.REVBAL12	=	list.get(259).trim();
		Fase2ResultadoBD.REVBAL13	=	list.get(260).trim();
		Fase2ResultadoBD.REVBAL14	=	list.get(261).trim();
		Fase2ResultadoBD.REVBAL15	=	list.get(262).trim();
		Fase2ResultadoBD.REVBAL16	=	list.get(263).trim();
		Fase2ResultadoBD.REVBAL17	=	list.get(264).trim();
		Fase2ResultadoBD.REVBAL18	=	list.get(265).trim();
		Fase2ResultadoBD.REVBAL19	=	list.get(266).trim();
		Fase2ResultadoBD.REVBAL20	=	list.get(267).trim();
		Fase2ResultadoBD.REVBAL21	=	list.get(268).trim();
		Fase2ResultadoBD.REVBAL22	=	list.get(269).trim();
		Fase2ResultadoBD.REVBAL23	=	list.get(270).trim();
		Fase2ResultadoBD.REVBAL24	=	list.get(271).trim();
		Fase2ResultadoBD.RI06S	=	list.get(272).trim();
		Fase2ResultadoBD.RI20S	=	list.get(273).trim();
		Fase2ResultadoBD.RI21S	=	list.get(274).trim();
		Fase2ResultadoBD.RI24S	=	list.get(275).trim();
		Fase2ResultadoBD.RI27S	=	list.get(276).trim();
		Fase2ResultadoBD.RI29S	=	list.get(277).trim();
		Fase2ResultadoBD.RI30S	=	list.get(278).trim();
		Fase2ResultadoBD.RI31S	=	list.get(279).trim();
		Fase2ResultadoBD.RI32S	=	list.get(280).trim();
		Fase2ResultadoBD.RLE904	=	list.get(281).trim();
		Fase2ResultadoBD.RLE905	=	list.get(282).trim();
		Fase2ResultadoBD.RLE907	=	list.get(283).trim();
		Fase2ResultadoBD.RR102S	=	list.get(284).trim();
		Fase2ResultadoBD.RR201S	=	list.get(285).trim();
		Fase2ResultadoBD.RR21S	=	list.get(286).trim();
		Fase2ResultadoBD.RR24S	=	list.get(287).trim();
		Fase2ResultadoBD.RR25S	=	list.get(288).trim();
		Fase2ResultadoBD.RT06S	=	list.get(289).trim();
		Fase2ResultadoBD.RT201S	=	list.get(290).trim();
		Fase2ResultadoBD.RT21S	=	list.get(291).trim();
		Fase2ResultadoBD.RT24S	=	list.get(292).trim();
		Fase2ResultadoBD.RT31S	=	list.get(293).trim();
		Fase2ResultadoBD.RVLR03	=	list.get(294).trim();
		Fase2ResultadoBD.RVLR06	=	list.get(295).trim();
		Fase2ResultadoBD.RVLR09	=	list.get(296).trim();
		Fase2ResultadoBD.S064D	=	list.get(297).trim();
		Fase2ResultadoBD.S209D	=	list.get(298).trim();
		Fase2ResultadoBD.SE09S	=	list.get(299).trim();
		Fase2ResultadoBD.SE21S	=	list.get(300).trim();
		Fase2ResultadoBD.SE34S	=	list.get(301).trim();
		Fase2ResultadoBD.TEL09S	=	list.get(302).trim();
		Fase2ResultadoBD.TEL21S	=	list.get(303).trim();
		Fase2ResultadoBD.TEL30S	=	list.get(304).trim();
		Fase2ResultadoBD.TEL31S	=	list.get(305).trim();
		Fase2ResultadoBD.TEL32S	=	list.get(306).trim();
		Fase2ResultadoBD.TRANBAL01	=	list.get(307).trim();
		Fase2ResultadoBD.TRANBAL02	=	list.get(308).trim();
		Fase2ResultadoBD.TRANBAL03	=	list.get(309).trim();
		Fase2ResultadoBD.TRANBAL04	=	list.get(310).trim();
		Fase2ResultadoBD.TRANBAL05	=	list.get(311).trim();
		Fase2ResultadoBD.TRANBAL06	=	list.get(312).trim();
		Fase2ResultadoBD.TRANBAL07	=	list.get(313).trim();
		Fase2ResultadoBD.TRANBAL08	=	list.get(314).trim();
		Fase2ResultadoBD.TRANBAL09	=	list.get(315).trim();
		Fase2ResultadoBD.TRANBAL10	=	list.get(316).trim();
		Fase2ResultadoBD.TRANBAL11	=	list.get(317).trim();
		Fase2ResultadoBD.TRANBAL12	=	list.get(318).trim();
		Fase2ResultadoBD.TRANBAL13	=	list.get(319).trim();
		Fase2ResultadoBD.TRANBAL14	=	list.get(320).trim();
		Fase2ResultadoBD.TRANBAL15	=	list.get(321).trim();
		Fase2ResultadoBD.TRANBAL16	=	list.get(322).trim();
		Fase2ResultadoBD.TRANBAL17	=	list.get(323).trim();
		Fase2ResultadoBD.TRANBAL18	=	list.get(324).trim();
		Fase2ResultadoBD.TRANBAL19	=	list.get(325).trim();
		Fase2ResultadoBD.TRANBAL20	=	list.get(326).trim();
		Fase2ResultadoBD.TRANBAL21	=	list.get(327).trim();
		Fase2ResultadoBD.TRANBAL22	=	list.get(328).trim();
		Fase2ResultadoBD.TRANBAL23	=	list.get(329).trim();
		Fase2ResultadoBD.TRANBAL24	=	list.get(330).trim();
		Fase2ResultadoBD.TRD	=	list.get(331).trim();
		Fase2ResultadoBD.TRV03	=	list.get(332).trim();
		Fase2ResultadoBD.TRV05	=	list.get(333).trim();
		Fase2ResultadoBD.TRV12	=	list.get(334).trim();
		Fase2ResultadoBD.TRV14	=	list.get(335).trim();
		Fase2ResultadoBD.TRV17	=	list.get(336).trim();
		Fase2ResultadoBD.TRV18	=	list.get(337).trim();
		Fase2ResultadoBD.UL_TRD	=	list.get(338).trim();
		Fase2ResultadoBD.UL01S	=	list.get(339).trim();
		Fase2ResultadoBD.UL06S	=	list.get(340).trim();
		Fase2ResultadoBD.UL21S	=	list.get(341).trim();
		Fase2ResultadoBD.UL25S	=	list.get(342).trim();
		Fase2ResultadoBD.UL29S	=	list.get(343).trim();
		Fase2ResultadoBD.UL30S	=	list.get(344).trim();
		Fase2ResultadoBD.UL32S	=	list.get(345).trim();
		Fase2ResultadoBD.UL34S	=	list.get(346).trim();
		Fase2ResultadoBD.US25S	=	list.get(347).trim();
		Fase2ResultadoBD.WALSHR07	=	list.get(348).trim();
		Fase2ResultadoBD.WD21	=	list.get(349).trim();
		Fase2ResultadoBD.WD31	=	list.get(350).trim();
		Fase2ResultadoBD.WD51	=	list.get(351).trim();
		Fase2ResultadoBD.WD61	=	list.get(352).trim();
		Fase2ResultadoBD.WD71	=	list.get(353).trim();
		Fase2ResultadoBD.WD81	=	list.get(354).trim();
		Fase2ResultadoBD.CV_SCORE	=	list.get(355).trim();
		


	}



	public static String getSECUENCIA() {
		return SECUENCIA;
	}



	public static String getCV_SCORE() {
		return CV_SCORE;
	}



	public static String getAT31S() {
		return AT31S;
	}



	public static String getAT34A() {
		return AT34A;
	}



	public static String getAU21S() {
		return AU21S;
	}



	public static String getBC01S() {
		return BC01S;
	}



	public static String getBC20S() {
		return BC20S;
	}



	public static String getBC21S() {
		return BC21S;
	}



	public static String getBI20S() {
		return BI20S;
	}



	public static String getBI21S() {
		return BI21S;
	}



	public static String getBI29S() {
		return BI29S;
	}



	public static String getBI32S() {
		return BI32S;
	}



	public static String getBI34S() {
		return BI34S;
	}



	public static String getBR12S() {
		return BR12S;
	}



	public static String getBR20S() {
		return BR20S;
	}



	public static String getBR27S() {
		return BR27S;
	}



	public static String getBR29S() {
		return BR29S;
	}



	public static String getBR34S() {
		return BR34S;
	}



	public static String getBU09S() {
		return BU09S;
	}



	public static String getBU21S() {
		return BU21S;
	}



	public static String getBU32S() {
		return BU32S;
	}



	public static String getCA09S() {
		return CA09S;
	}



	public static String getCA70S() {
		return CA70S;
	}



	public static String getCO04S() {
		return CO04S;
	}



	public static String getCO04SF() {
		return CO04SF;
	}



	public static String getCT20S() {
		return CT20S;
	}



	public static String getCT24S() {
		return CT24S;
	}



	public static String getCT30S() {
		return CT30S;
	}



	public static String getCT31S() {
		return CT31S;
	}



	public static String getCT32S() {
		return CT32S;
	}



	public static String getDM211S() {
		return DM211S;
	}



	public static String getDM214S() {
		return DM214S;
	}



	public static String getFI20S() {
		return FI20S;
	}



	public static String getFI21S() {
		return FI21S;
	}



	public static String getFI34S() {
		return FI34S;
	}



	public static String getFMD21S() {
		return FMD21S;
	}



	public static String getFR21S() {
		return FR21S;
	}



	public static String getFR29S() {
		return FR29S;
	}



	public static String getFR32S() {
		return FR32S;
	}



	public static String getFR34S() {
		return FR34S;
	}



	public static String getFS20S() {
		return FS20S;
	}



	public static String getFU20S() {
		return FU20S;
	}



	public static String getFU21S() {
		return FU21S;
	}



	public static String getFU32S() {
		return FU32S;
	}



	public static String getFU34S() {
		return FU34S;
	}



	public static String getG103S() {
		return G103S;
	}



	public static String getG209SF() {
		return G209SF;
	}



	public static String getG211S() {
		return G211S;
	}



	public static String getG212SF() {
		return G212SF;
	}



	public static String getG218BF() {
		return G218BF;
	}



	public static String getG220A() {
		return G220A;
	}



	public static String getG221D() {
		return G221D;
	}



	public static String getG417S() {
		return G417S;
	}



	public static String getG500S() {
		return G500S;
	}



	public static String getG540S() {
		return G540S;
	}



	public static String getG547S() {
		return G547S;
	}



	public static String getG960S() {
		return G960S;
	}



	public static String getIN01S() {
		return IN01S;
	}



	public static String getIN06S() {
		return IN06S;
	}



	public static String getIN09S() {
		return IN09S;
	}



	public static String getIN21S() {
		return IN21S;
	}



	public static String getIN25S() {
		return IN25S;
	}



	public static String getIN27S() {
		return IN27S;
	}



	public static String getIN31S() {
		return IN31S;
	}



	public static String getIN34S() {
		return IN34S;
	}



	public static String getLL09S() {
		return LL09S;
	}



	public static String getLL21S() {
		return LL21S;
	}



	public static String getLL30S() {
		return LL30S;
	}



	public static String getLL34S() {
		return LL34S;
	}



	public static String getLMD21S() {
		return LMD21S;
	}



	public static String getLMD30S() {
		return LMD30S;
	}



	public static String getLMD32S() {
		return LMD32S;
	}



	public static String getLMD34S() {
		return LMD34S;
	}



	public static String getLS29S() {
		return LS29S;
	}



	public static String getLS30S() {
		return LS30S;
	}



	public static String getLS34S() {
		return LS34S;
	}



	public static String getMF20S() {
		return MF20S;
	}



	public static String getMF24S() {
		return MF24S;
	}



	public static String getMF31S() {
		return MF31S;
	}



	public static String getMF32S() {
		return MF32S;
	}



	public static String getMT24S() {
		return MT24S;
	}



	public static String getMT33S() {
		return MT33S;
	}



	public static String getMT34B() {
		return MT34B;
	}



	public static String getMT34S() {
		return MT34S;
	}



	public static String getOD34S() {
		return OD34S;
	}



	public static String getOF06S() {
		return OF06S;
	}



	public static String getOF09S() {
		return OF09S;
	}



	public static String getOF32S() {
		return OF32S;
	}



	public static String getOF34S() {
		return OF34S;
	}



	public static String getPT09S() {
		return PT09S;
	}



	public static String getPT20S() {
		return PT20S;
	}



	public static String getPT21S() {
		return PT21S;
	}



	public static String getPT30S() {
		return PT30S;
	}



	public static String getPT34S() {
		return PT34S;
	}



	public static String getRE102S() {
		return RE102S;
	}



	public static String getRE12S() {
		return RE12S;
	}



	public static String getRE30S() {
		return RE30S;
	}



	public static String getRE32S() {
		return RE32S;
	}



	public static String getRI06S() {
		return RI06S;
	}



	public static String getRI20S() {
		return RI20S;
	}



	public static String getRI21S() {
		return RI21S;
	}



	public static String getRI24S() {
		return RI24S;
	}



	public static String getRI27S() {
		return RI27S;
	}



	public static String getRI29S() {
		return RI29S;
	}



	public static String getRI30S() {
		return RI30S;
	}



	public static String getRI31S() {
		return RI31S;
	}



	public static String getRI32S() {
		return RI32S;
	}



	public static String getRR102S() {
		return RR102S;
	}



	public static String getRR201S() {
		return RR201S;
	}



	public static String getRR21S() {
		return RR21S;
	}



	public static String getRR24S() {
		return RR24S;
	}



	public static String getRR25S() {
		return RR25S;
	}



	public static String getRT06S() {
		return RT06S;
	}



	public static String getRT201S() {
		return RT201S;
	}



	public static String getRT21S() {
		return RT21S;
	}



	public static String getRT24S() {
		return RT24S;
	}



	public static String getRT31S() {
		return RT31S;
	}



	public static String getS064D() {
		return S064D;
	}



	public static String getS209D() {
		return S209D;
	}



	public static String getSE09S() {
		return SE09S;
	}



	public static String getSE21S() {
		return SE21S;
	}



	public static String getSE34S() {
		return SE34S;
	}



	public static String getTEL09S() {
		return TEL09S;
	}



	public static String getTEL21S() {
		return TEL21S;
	}



	public static String getTEL30S() {
		return TEL30S;
	}



	public static String getTEL31S() {
		return TEL31S;
	}



	public static String getTEL32S() {
		return TEL32S;
	}



	public static String getUL01S() {
		return UL01S;
	}



	public static String getUL06S() {
		return UL06S;
	}



	public static String getUL21S() {
		return UL21S;
	}



	public static String getUL25S() {
		return UL25S;
	}



	public static String getUL29S() {
		return UL29S;
	}



	public static String getUL30S() {
		return UL30S;
	}



	public static String getUL32S() {
		return UL32S;
	}



	public static String getUL34S() {
		return UL34S;
	}



	public static String getUS25S() {
		return US25S;
	}



	public static String getAGG1101() {
		return AGG1101;
	}



	public static String getAGG1102() {
		return AGG1102;
	}



	public static String getAGG1103() {
		return AGG1103;
	}



	public static String getAGG1104() {
		return AGG1104;
	}



	public static String getAGG1105() {
		return AGG1105;
	}



	public static String getAGG1106() {
		return AGG1106;
	}



	public static String getAGG1107() {
		return AGG1107;
	}



	public static String getAGG1108() {
		return AGG1108;
	}



	public static String getAGG1109() {
		return AGG1109;
	}



	public static String getAGG1110() {
		return AGG1110;
	}



	public static String getAGG1111() {
		return AGG1111;
	}



	public static String getAGG1112() {
		return AGG1112;
	}



	public static String getAGG1113() {
		return AGG1113;
	}



	public static String getAGG1114() {
		return AGG1114;
	}



	public static String getAGG1115() {
		return AGG1115;
	}



	public static String getAGG1116() {
		return AGG1116;
	}



	public static String getAGG1117() {
		return AGG1117;
	}



	public static String getAGG1118() {
		return AGG1118;
	}



	public static String getAGG1119() {
		return AGG1119;
	}



	public static String getAGG1120() {
		return AGG1120;
	}



	public static String getAGG1121() {
		return AGG1121;
	}



	public static String getAGG1122() {
		return AGG1122;
	}



	public static String getAGG1123() {
		return AGG1123;
	}



	public static String getAGG1124() {
		return AGG1124;
	}



	public static String getAGG2401() {
		return AGG2401;
	}



	public static String getAGG2402() {
		return AGG2402;
	}



	public static String getAGG2403() {
		return AGG2403;
	}



	public static String getAGG2404() {
		return AGG2404;
	}



	public static String getAGG2405() {
		return AGG2405;
	}



	public static String getAGG2406() {
		return AGG2406;
	}



	public static String getAGG2407() {
		return AGG2407;
	}



	public static String getAGG2408() {
		return AGG2408;
	}



	public static String getAGG2409() {
		return AGG2409;
	}



	public static String getAGG2410() {
		return AGG2410;
	}



	public static String getAGG2411() {
		return AGG2411;
	}



	public static String getAGG2412() {
		return AGG2412;
	}



	public static String getAGG2413() {
		return AGG2413;
	}



	public static String getAGG2414() {
		return AGG2414;
	}



	public static String getAGG2415() {
		return AGG2415;
	}



	public static String getAGG2416() {
		return AGG2416;
	}



	public static String getAGG2417() {
		return AGG2417;
	}



	public static String getAGG2418() {
		return AGG2418;
	}



	public static String getAGG2419() {
		return AGG2419;
	}



	public static String getAGG2420() {
		return AGG2420;
	}



	public static String getAGG2421() {
		return AGG2421;
	}



	public static String getAGG2422() {
		return AGG2422;
	}



	public static String getAGG2423() {
		return AGG2423;
	}



	public static String getAGG2424() {
		return AGG2424;
	}



	public static String getAGG301() {
		return AGG301;
	}



	public static String getAGG302() {
		return AGG302;
	}



	public static String getAGG303() {
		return AGG303;
	}



	public static String getAGG304() {
		return AGG304;
	}



	public static String getAGG305() {
		return AGG305;
	}



	public static String getAGG306() {
		return AGG306;
	}



	public static String getAGG307() {
		return AGG307;
	}



	public static String getAGG308() {
		return AGG308;
	}



	public static String getAGG309() {
		return AGG309;
	}



	public static String getAGG310() {
		return AGG310;
	}



	public static String getAGG311() {
		return AGG311;
	}



	public static String getAGG312() {
		return AGG312;
	}



	public static String getAGG313() {
		return AGG313;
	}



	public static String getAGG314() {
		return AGG314;
	}



	public static String getAGG315() {
		return AGG315;
	}



	public static String getAGG316() {
		return AGG316;
	}



	public static String getAGG317() {
		return AGG317;
	}



	public static String getAGG318() {
		return AGG318;
	}



	public static String getAGG319() {
		return AGG319;
	}



	public static String getAGG320() {
		return AGG320;
	}



	public static String getAGG321() {
		return AGG321;
	}



	public static String getAGG322() {
		return AGG322;
	}



	public static String getAGG323() {
		return AGG323;
	}



	public static String getAGG324() {
		return AGG324;
	}



	public static String getAGG701() {
		return AGG701;
	}



	public static String getAGG702() {
		return AGG702;
	}



	public static String getAGG703() {
		return AGG703;
	}



	public static String getAGG704() {
		return AGG704;
	}



	public static String getAGG705() {
		return AGG705;
	}



	public static String getAGG706() {
		return AGG706;
	}



	public static String getAGG707() {
		return AGG707;
	}



	public static String getAGG708() {
		return AGG708;
	}



	public static String getAGG709() {
		return AGG709;
	}



	public static String getAGG710() {
		return AGG710;
	}



	public static String getAGG711() {
		return AGG711;
	}



	public static String getAGG712() {
		return AGG712;
	}



	public static String getAGG713() {
		return AGG713;
	}



	public static String getAGG714() {
		return AGG714;
	}



	public static String getAGG715() {
		return AGG715;
	}



	public static String getAGG716() {
		return AGG716;
	}



	public static String getAGG717() {
		return AGG717;
	}



	public static String getAGG718() {
		return AGG718;
	}



	public static String getAGG719() {
		return AGG719;
	}



	public static String getAGG720() {
		return AGG720;
	}



	public static String getAGG721() {
		return AGG721;
	}



	public static String getAGG722() {
		return AGG722;
	}



	public static String getAGG723() {
		return AGG723;
	}



	public static String getAGG724() {
		return AGG724;
	}



	public static String getAGG904() {
		return AGG904;
	}



	public static String getAGG905() {
		return AGG905;
	}



	public static String getAGG906() {
		return AGG906;
	}



	public static String getAGG909() {
		return AGG909;
	}



	public static String getAGG910() {
		return AGG910;
	}



	public static String getAGG911() {
		return AGG911;
	}



	public static String getBKC112() {
		return BKC112;
	}



	public static String getBKC225() {
		return BKC225;
	}



	public static String getBKC231() {
		return BKC231;
	}



	public static String getBKC232() {
		return BKC232;
	}



	public static String getBKC233() {
		return BKC233;
	}



	public static String getBKC235() {
		return BKC235;
	}



	public static String getBKC252() {
		return BKC252;
	}



	public static String getBKC253() {
		return BKC253;
	}



	public static String getBKC254() {
		return BKC254;
	}



	public static String getBKC255() {
		return BKC255;
	}



	public static String getCOLLECTION_TRD() {
		return COLLECTION_TRD;
	}



	public static String getCV25() {
		return CV25;
	}



	public static String getG306S() {
		return G306S;
	}



	public static String getG410S() {
		return G410S;
	}



	public static String getNON_FINANCIAL_TRD() {
		return NON_FINANCIAL_TRD;
	}



	public static String getPAYMNT03() {
		return PAYMNT03;
	}



	public static String getPAYMNT50() {
		return PAYMNT50;
	}



	public static String getPAYMNT65() {
		return PAYMNT65;
	}



	public static String getPER201() {
		return PER201;
	}



	public static String getPER222() {
		return PER222;
	}



	public static String getPER223() {
		return PER223;
	}



	public static String getPER224() {
		return PER224;
	}



	public static String getPER233() {
		return PER233;
	}



	public static String getPUBLIC_SERVICE_TRD() {
		return PUBLIC_SERVICE_TRD;
	}



	public static String getRET11() {
		return RET11;
	}



	public static String getRET13() {
		return RET13;
	}



	public static String getRET132() {
		return RET132;
	}



	public static String getRET14() {
		return RET14;
	}



	public static String getRET142() {
		return RET142;
	}



	public static String getRET152() {
		return RET152;
	}



	public static String getRET201() {
		return RET201;
	}



	public static String getRET222() {
		return RET222;
	}



	public static String getRET223() {
		return RET223;
	}



	public static String getRET224() {
		return RET224;
	}



	public static String getRET225() {
		return RET225;
	}



	public static String getRET315() {
		return RET315;
	}



	public static String getRET320() {
		return RET320;
	}



	public static String getRET51() {
		return RET51;
	}



	public static String getRET81() {
		return RET81;
	}



	public static String getRET84() {
		return RET84;
	}



	public static String getREV14() {
		return REV14;
	}



	public static String getREV202() {
		return REV202;
	}



	public static String getREV203() {
		return REV203;
	}



	public static String getREV204() {
		return REV204;
	}



	public static String getREV222() {
		return REV222;
	}



	public static String getREV223() {
		return REV223;
	}



	public static String getREV225() {
		return REV225;
	}



	public static String getREV253() {
		return REV253;
	}



	public static String getREV320() {
		return REV320;
	}



	public static String getREVBAL01() {
		return REVBAL01;
	}



	public static String getREVBAL02() {
		return REVBAL02;
	}



	public static String getREVBAL03() {
		return REVBAL03;
	}



	public static String getREVBAL04() {
		return REVBAL04;
	}



	public static String getREVBAL05() {
		return REVBAL05;
	}



	public static String getREVBAL06() {
		return REVBAL06;
	}



	public static String getREVBAL07() {
		return REVBAL07;
	}



	public static String getREVBAL08() {
		return REVBAL08;
	}



	public static String getREVBAL09() {
		return REVBAL09;
	}



	public static String getREVBAL10() {
		return REVBAL10;
	}



	public static String getREVBAL11() {
		return REVBAL11;
	}



	public static String getREVBAL12() {
		return REVBAL12;
	}



	public static String getREVBAL13() {
		return REVBAL13;
	}



	public static String getREVBAL14() {
		return REVBAL14;
	}



	public static String getREVBAL15() {
		return REVBAL15;
	}



	public static String getREVBAL16() {
		return REVBAL16;
	}



	public static String getREVBAL17() {
		return REVBAL17;
	}



	public static String getREVBAL18() {
		return REVBAL18;
	}



	public static String getREVBAL19() {
		return REVBAL19;
	}



	public static String getREVBAL20() {
		return REVBAL20;
	}



	public static String getREVBAL21() {
		return REVBAL21;
	}



	public static String getREVBAL22() {
		return REVBAL22;
	}



	public static String getREVBAL23() {
		return REVBAL23;
	}



	public static String getREVBAL24() {
		return REVBAL24;
	}



	public static String getRLE904() {
		return RLE904;
	}



	public static String getRLE905() {
		return RLE905;
	}



	public static String getRLE907() {
		return RLE907;
	}



	public static String getRVLR03() {
		return RVLR03;
	}



	public static String getRVLR06() {
		return RVLR06;
	}



	public static String getRVLR09() {
		return RVLR09;
	}



	public static String getTRANBAL01() {
		return TRANBAL01;
	}



	public static String getTRANBAL02() {
		return TRANBAL02;
	}



	public static String getTRANBAL03() {
		return TRANBAL03;
	}



	public static String getTRANBAL04() {
		return TRANBAL04;
	}



	public static String getTRANBAL05() {
		return TRANBAL05;
	}



	public static String getTRANBAL06() {
		return TRANBAL06;
	}



	public static String getTRANBAL07() {
		return TRANBAL07;
	}



	public static String getTRANBAL08() {
		return TRANBAL08;
	}



	public static String getTRANBAL09() {
		return TRANBAL09;
	}



	public static String getTRANBAL10() {
		return TRANBAL10;
	}



	public static String getTRANBAL11() {
		return TRANBAL11;
	}



	public static String getTRANBAL12() {
		return TRANBAL12;
	}



	public static String getTRANBAL13() {
		return TRANBAL13;
	}



	public static String getTRANBAL14() {
		return TRANBAL14;
	}



	public static String getTRANBAL15() {
		return TRANBAL15;
	}



	public static String getTRANBAL16() {
		return TRANBAL16;
	}



	public static String getTRANBAL17() {
		return TRANBAL17;
	}



	public static String getTRANBAL18() {
		return TRANBAL18;
	}



	public static String getTRANBAL19() {
		return TRANBAL19;
	}



	public static String getTRANBAL20() {
		return TRANBAL20;
	}



	public static String getTRANBAL21() {
		return TRANBAL21;
	}



	public static String getTRANBAL22() {
		return TRANBAL22;
	}



	public static String getTRANBAL23() {
		return TRANBAL23;
	}



	public static String getTRANBAL24() {
		return TRANBAL24;
	}



	public static String getTRD() {
		return TRD;
	}



	public static String getTRV03() {
		return TRV03;
	}



	public static String getTRV05() {
		return TRV05;
	}



	public static String getTRV12() {
		return TRV12;
	}



	public static String getTRV14() {
		return TRV14;
	}



	public static String getTRV17() {
		return TRV17;
	}



	public static String getTRV18() {
		return TRV18;
	}



	public static String getUL_TRD() {
		return UL_TRD;
	}



	public static String getWALSHR07() {
		return WALSHR07;
	}



	public static String getWD21() {
		return WD21;
	}



	public static String getWD31() {
		return WD31;
	}



	public static String getWD51() {
		return WD51;
	}



	public static String getWD61() {
		return WD61;
	}



	public static String getWD71() {
		return WD71;
	}



	public static String getWD81() {
		return WD81;
	}



}
