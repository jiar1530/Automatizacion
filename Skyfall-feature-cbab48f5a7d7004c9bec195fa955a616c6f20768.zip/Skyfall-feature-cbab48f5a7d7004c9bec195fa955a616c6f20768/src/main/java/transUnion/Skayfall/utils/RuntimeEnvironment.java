package transUnion.Skayfall.utils;

import java.io.IOException;

import org.apache.log4j.Logger;

import transUnion.Skyfall.javaUtils.ReadProjectProperties;


public class RuntimeEnvironment {
	static Logger logger = Logger.getLogger(RuntimeEnvironment.class);

	public static String getDefaultUrl() {
		String baseUrlDefault = "";
		String environment = readProperties("Environment");
		logger.info("Ambiente de ejecucion PortalTU--> " + environment);
		switch (environment) {
		case "QA":
			baseUrlDefault = readProperties("QA_Url");
			break;
		case "UAT":
			baseUrlDefault = readProperties("UAT_Url");
			break;
		case "DEV":
			baseUrlDefault = readProperties("DEV_Url");
			break;
		default:
			logger.error("No se pudo leer archivo project.properties");
			break;

		}
		return baseUrlDefault;
	}

	public static String getDefaultDataBaseUrl() throws IOException {
		String baseUrlDefault = "";
		String environment = ReadProjectProperties.valueOf("project", "Environment");
		logger.info("Ambiente de ejecucion Base de datos--> " + environment);
		switch (environment) {
		case "QA":
			baseUrlDefault = readProperties("QA_DataBase");
			break;
		case "UAT":
			baseUrlDefault = readProperties("UAT_DataBase");
			break;
		case "DEV":
			baseUrlDefault = readProperties("DEV_DataBase");
			break;

		default:
			logger.error("No se pudo leer archivo project.properties");
			break;
		}
		return baseUrlDefault;
	}

	public static String getDefaultWS() throws IOException {

		String baseUrlWS = "";
		String environment = ReadProjectProperties.valueOf("project", "Environment");
		logger.info("Ambiente de ejecucion Base de datos--> " + environment);
		switch (environment) {
		case "QA":
			baseUrlWS = ReadProjectProperties.valueOf("project", "QA_Url");
			break;

		case "UAT":
			baseUrlWS = ReadProjectProperties.valueOf("project", "UAT_Url");
			break;

		case "DEV":
			baseUrlWS = ReadProjectProperties.valueOf("project", "DEV_Url");
			break;
		default:
			logger.error("Error leyendo archivo project.properties valide parametros");
			System.exit(1);
			break;
		}
		return baseUrlWS;

	}

	private static String readProperties(String propertie) {
		String value = "";
		try {
			value = ReadProjectProperties.valueOf("project", propertie);
		} catch (IOException e) {
			logger.error("No se pudo leer archivo project.properties --> " + e.getMessage());
			e.printStackTrace();
			System.exit(1);
		}
		return value;
	}

	private RuntimeEnvironment() {
		throw new IllegalStateException("Utility class");
	}
}
