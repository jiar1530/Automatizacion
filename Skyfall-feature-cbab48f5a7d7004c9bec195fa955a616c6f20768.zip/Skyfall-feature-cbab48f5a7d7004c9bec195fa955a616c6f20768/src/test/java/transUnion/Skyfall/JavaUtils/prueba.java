package transUnion.Skyfall.JavaUtils;



import java.io.File;
import java.io.IOException;
import java.util.Scanner;
public class prueba {

	public static void main(String[] args) throws IOException {
	    
	           File myFile = new File("shape_co_base_trades_hd_2016-07-31.txt");
	           System.out.println("Attempting to read from file in: "+myFile.getCanonicalPath());

	           Scanner input = new Scanner(myFile);
	           String in = "";
	           in = input.nextLine();
	       }

	


	
	}

