package transUnion.Skyfall.JavaUtils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import org.apache.log4j.Logger;
import org.assertj.core.api.SoftAssertions;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.ibm.icu.text.SimpleDateFormat;

import transUnion.Skyfall.models.Fase6ResultadoArchivoPlanoUNO;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PruebaFase6TradesHDComparacion {
	String origenFileUNO = "D:\\";
	String fileNameUNO = "UAT.txt";

	String origenFileDOS = "D:\\";
	String fileNameDOS = "DATA.txt";

	String dataUNO;
	String dataDOS;

	SoftAssertions softAssert = new SoftAssertions();
	static Logger logger = Logger.getLogger(PruebaFase6TradesHDComparacion.class);
	static boolean testEstructura;
	static boolean test = true;
	static boolean test2 = true;
	SimpleDateFormat date = new SimpleDateFormat("yyyy/MM/dd");
	static String tercero = "";
	static List<String> listaQueries;
	static List<List<List<String>>> queriesResult1;

	private int linea = 0;
	int Errores = 0;
	int Errores2 = 0;
	private int linea1 = 0;
	private int linea2 = 0;

	@Test
	public void test1Estructura() throws Exception {
		int numeroDeVariables = 0;
		Errores = 0;

		try (BufferedReader buffReaderUno = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(new FileInputStream(origenFileUNO + fileNameUNO)), "UTF-8"))) {
			try (BufferedReader buffReaderDos = new BufferedReader(new InputStreamReader(
					new BufferedInputStream(new FileInputStream(origenFileUNO + fileNameDOS)), "UTF-8"))) {

				String dataUno;
				String dataDos;
				String dataReadingUno = null;
				String dataReadingDos = null;
				this.linea1 = 0;
				this.linea2 = 0;
				PruebaFase6TradesHDComparacion.testEstructura = true;

				while ((dataUno = buffReaderUno.readLine()) != null) {
					PruebaFase6TradesHDComparacion.test = true;
					this.linea1++;
					dataReadingUno = dataUno;

					if (dataReadingUno.endsWith("|")) {
						dataReadingUno = dataReadingUno.replace("|", "|-");
					}

					if (linea1 == 1) {
						imprimirReporte("Prueba_Estructura_" + fileNameUNO.split("\\.")[0], "DETALLE ERROR|\n", false);
						numeroDeVariables = dataReadingUno.split("\\|").length;
					}

					if (linea1 != 1 && (dataReadingUno.split("\\|").length != numeroDeVariables)) {
						imprimirReporte("Prueba_Estructura_" + fileNameUNO.split("\\.")[0],
								"Numero de campos es diferente al establecido, en la linea--> " + linea1
										+ " el archivo tiene --> " + dataReadingUno.split("\\|").length + " campos|"
										+ numeroDeVariables + "\n",
								true);
						testEstructura = false;
						test = false;
					}

					if (!test) {
						logger.error("Se encontraron errores en archivo " + fileNameUNO.split("\\.")[0]
								+ " en la linea--> " + linea1);
						softAssert.fail("Se encontraron errores en archivo " + fileNameUNO.split("\\.")[0]
								+ " en la linea--> " + linea1);

						Errores++;
					} else {
						logger.info("Linea --> " + linea1 + " ok");

					}

				}

				while ((dataDos = buffReaderDos.readLine()) != null) {
					dataReadingDos = dataDos;
					this.linea2++;
					if (dataReadingDos.endsWith("|")) {
						dataReadingDos = dataReadingDos.replace("|", "|-");
					}

					if (linea2 == 1) {
						imprimirReporte("Prueba_Estructura_" + fileNameDOS.split("\\.")[0], "DETALLE ERROR|\n", false);

					}

					if (linea2 != 1 && (dataReadingUno.split("\\|").length != numeroDeVariables)) {
						imprimirReporte("Prueba_Estructura_" + fileNameDOS.split("\\.")[0],
								"Numero de campos es diferente al referenciado en archivo "
										+ fileNameUNO.split("\\.")[0] + ", en la linea--> " + linea2
										+ " el archivo tiene --> " + dataReadingDos.split("\\|").length + " campos|"
										+ numeroDeVariables + "\n",
								true);
						testEstructura = false;
						test2 = false;
					}

					if (!test2) {
						logger.error("Se encontraron errores en archivo " + fileNameDOS.split("\\.")[0]
								+ " en la linea--> " + linea2);
						softAssert.fail("Se encontraron errores en archivo " + fileNameDOS.split("\\.")[0]
								+ " en la linea--> " + linea2);

						Errores2++;
					} else {
						logger.info("Linea --> " + linea2 + " ok");

					}

				}

				if (linea1 != linea2) {
					imprimirReporte("Prueba_Estructura_" + fileNameUNO.split("\\.")[0],
							"Numero de lineas en archivo " + fileNameUNO.split("\\.")[0] + "= " + linea1
									+ " es diferente al numero de lineas en archivo " + fileNameDOS.split("\\.")[0]
									+ "= " + linea2 + "\n",
							true);
					imprimirReporte("Prueba_Estructura_" + fileNameDOS.split("\\.")[0],
							"Numero de lineas en archivo " + fileNameDOS.split("\\.")[0] + "= " + linea2
									+ " es diferente al numero de lineas en archivo " + fileNameUNO.split("\\.")[0]
									+ "= " + linea1 + "\n",
							true);
					softAssert.fail("Numero de lineas en archivo " + fileNameDOS.split("\\.")[0] + "= " + linea2
							+ " es diferente al numero de lineas en archivo " + fileNameUNO.split("\\.")[0] + "= "
							+ linea1);
					Errores++;
					Errores2++;
					testEstructura = false;
				}
				imprimirReporte("Prueba_Estructura_" + fileNameUNO.split("\\.")[0],
						"Numero de registros analizados " + (linea1 - 1) + " errores encontrados " + Errores + "\n",
						true);
				imprimirReporte("Prueba_Estructura_" + fileNameDOS.split("\\.")[0],
						"Numero de registros analizados " + (linea1 - 1) + " errores encontrados " + Errores2 + "\n",
						true);
				softAssert.assertAll();
				imprimirReporte("Prueba_Estructura_" + fileNameUNO.split("\\.")[0], "Prueba ejecutada sin errores\n",
						true);
				imprimirReporte("Prueba_Estructura_" + fileNameDOS.split("\\.")[0], "Prueba ejecutada sin errores\n",
						true);
			}
		}
	}

	@Test
	public void test2pruebaArchivo() throws Exception {

		Errores = 0;
		this.linea = 1;
		imprimirReporte("Test_Archivo_UAT", "", false);
		if (testEstructura) {
			try (BufferedReader buffReaderUNO = new BufferedReader(new InputStreamReader(
					new BufferedInputStream(new FileInputStream(origenFileUNO + fileNameUNO)), "UTF-8"))) {
				String dataUNO = "";
				dataUNO = buffReaderUNO.readLine();

				try (BufferedReader buffReaderDOS = new BufferedReader(new InputStreamReader(
						new BufferedInputStream(new FileInputStream(origenFileDOS + fileNameDOS)), "UTF-8"))) {
					String dataDOS = "";
					dataDOS = buffReaderDOS.readLine();
					int numParDataUno = dataUNO.split("\\|").length;
					int numParDataDos = dataDOS.split("\\|").length;
					imprimirReporte("Test_Archivo_UAT", "Linea\tSec_ter\tVariable\tSAS_Valor\tDATA_Valor\tPatron\n",
							true);
					while ((dataUNO = buffReaderUNO.readLine()) != null
							&& (dataDOS = buffReaderDOS.readLine()) != null) {
						this.linea++;
						if (dataUNO.endsWith("|")) {
							dataUNO = dataUNO + " |";
						}
						if (dataDOS.endsWith("|")) {
							dataDOS = dataDOS + " |";
						}
						test = true;
						System.out.println(dataUNO.split("\\|").length);
						if (dataUNO.split("\\|").length == numParDataUno
								&& dataDOS.split("\\|").length == numParDataDos) {
							// archivo plano set

							if (!dataUNO.split("\\|")[0].trim().equals(dataDOS.split("\\|")[0].trim())) {
								reportarError(dataUNO.split("\\|")[0].trim(), dataDOS.split("\\|")[0].trim(),
										"Secuencia Error");
								softAssert.assertAll();
								System.exit(1);
							} else {

								tercero = dataUNO.split("\\|")[0].trim();
								for (int variable = 1; variable < dataUNO.split("\\|").length; variable++) {
									if (!dataUNO.split("\\|")[variable].trim()
											.equals(dataDOS.split("\\|")[variable].trim())) {
										reportarError(dataUNO.split("\\|")[variable].trim(),
												dataDOS.split("\\|")[variable].trim(), "V" + variable);
									}

								}

							}
						} else {
							logger.error("Error validando secuencia de tercero");
							softAssert.fail("Error validando secuencia de tercero");
						}

						if (!test) {
							logger.error(
									"Se encontraron errores en la comparacion de datos en la secuencia de tercero--> "
											+ dataUNO.split("\\|")[0]);
							softAssert.fail(
									"Se encontraron errores en la comparacion de datos en la secuencia de tercero--> "
											+ dataUNO.split("\\|")[0]);

						}

						else {
							System.out.println(
									linea + " Consecutivo " + Fase6ResultadoArchivoPlanoUNO.getSECUENCIA_TERCERO());
						}

					}
					imprimirReporte("Test_Archivo_UAT",
							"Numero de registros analizados " + (linea) + " errores encontrados " + Errores + "\n",
							true);
					softAssert.assertAll();
					imprimirReporte("Test_Archivo_UAT",
							"Prueba fue ejecutada sin errores, movimientos analizados--> " + (linea - 1), true);
				}
			}
		} else {

			softAssert.fail("Test de estructura no fue aprobado");
			softAssert.assertAll();
		}

	}

	private void reportarError(String ArchivoResultados, String ArchivoResultadosDb, String parametro) {
		if (parametro.equals("Secuencia Error")) {
			imprimirReporte("Test_Archivo_UAT",
					"Secuencia de tercero errada " + ArchivoResultados + " " + ArchivoResultadosDb, true);
		} else if (ArchivoResultados.contains(".") || ArchivoResultadosDb.contains(".")) {
			double resultado1 = Double.parseDouble(ArchivoResultados);
			double resultado2 = Double.parseDouble(ArchivoResultadosDb);
			double resultadoPatro = (resultado1) - (resultado2);

			String data = linea + "\t" + tercero

					+ "\t" + parametro + "\t" + ArchivoResultados.replace(".", ",") + "\t"
					+ ArchivoResultadosDb.replace(".", ",") + "\t" + resultadoPatro + "\n";
			imprimirReporte("Test_Archivo_UAT", data, true);
		} else {
			int resultado1 = Integer.parseInt(ArchivoResultados);

			int resultado2 = Integer.parseInt(ArchivoResultadosDb);
			int resultadoPatron = (resultado1) - (resultado2);
			String data = linea + "\t" + tercero

					+ "\t" + parametro + "\t" + ArchivoResultados.replace(".", ",") + "\t"
					+ ArchivoResultadosDb.replace(".", ",") + "\t" + resultadoPatron + "\n";
			imprimirReporte("Test_Archivo_UAT", data, true);
		}

		// imprimirReporte("Test_Roland_", data, true);

		logger.error("Error en la linea--> " + linea + " IdTercero--> " + tercero + " Variable " + parametro
				+ " File--> " + ArchivoResultados + " Abinitions--> " + ArchivoResultadosDb);
		test = false;
		Errores++;
		//
	}

	private void imprimirReporte(String prueba, String data, Boolean escribir) {
		BufferedWriter bw = null;
		FileWriter fw = null;

		try {

			File file = new File(origenFileUNO + prueba + ".txt");
			// Si el archivo no existe, se crea!
			if (!file.exists()) {
				file.createNewFile();
			}
			// flag true, indica adjuntar información al archivo.
			fw = new FileWriter(file.getAbsoluteFile(), escribir);
			bw = new BufferedWriter(fw);
			bw.write(data);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				// Cierra instancias de FileWriter y BufferedWriter
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

}