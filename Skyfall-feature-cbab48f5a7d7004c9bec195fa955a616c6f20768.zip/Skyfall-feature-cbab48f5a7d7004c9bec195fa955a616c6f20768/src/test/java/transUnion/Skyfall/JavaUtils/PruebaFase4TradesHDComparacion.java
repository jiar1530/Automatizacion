package transUnion.Skyfall.JavaUtils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.assertj.core.api.SoftAssertions;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.ibm.icu.text.SimpleDateFormat;

import transUnion.Skyfall.models.Fase4ResultadoArchivoPlanoDOS;
import transUnion.Skyfall.models.Fase4ResultadoArchivoPlanoUNO;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PruebaFase4TradesHDComparacion {
	String origenFileUNO = "C:\\Users\\jugomez\\Documents\\VariablesSkyfall\\Test_Skyfall_01\\";
	String fileNameUNO = "UAT.txt";

	String origenFileDOS = "C:\\Users\\jugomez\\Documents\\VariablesSkyfall\\Test_Skyfall_01\\";
	String fileNameDOS = "DATA.txt";
	
	String dataUNO;
	String dataDOS;
	
	
	SoftAssertions softAssert = new SoftAssertions();
	static Logger logger = Logger.getLogger(PruebaFase4TradesHDComparacion.class);
	static boolean testEstructura;
	static boolean test = true;
	SimpleDateFormat date = new SimpleDateFormat("yyyy/MM/dd");
	static String[] cabecero = { "SECUENCIA_TERCERO", "AGG1101", "AGG1102",
			"AGG1103", "AGG1104", "AGG1105", "AGG1106", "AGG1107", "AGG1108", "AGG1109", "AGG1110", "AGG1111",
			"AGG1112", "AGG1113", "AGG1114", "AGG1115", "AGG1116", "AGG1117", "AGG1118", "AGG1119", "AGG1120",
			"AGG1121", "AGG1122", "AGG1123", "AGG1124", "AGG701", "AGG702", "AGG703", "AGG704", "AGG705", "AGG706",
			"AGG707", "AGG708", "AGG709", "AGG710", "AGG711", "AGG712", "AGG713", "AGG714", "AGG715", "AGG716",
			"AGG717", "AGG718", "AGG719", "AGG720", "AGG721", "AGG722", "AGG723", "AGG724", "AGG904", "AGG909",
			"AGG910", "AGG911", "AT27SF", "AT31S", "AU21S", "AU51A", "BC01S", "BC20S", "BC21S", "BI20S", "BI21S",
			"BI29S", "BI32S", "BKC231", "BKC232", "BKC233", "BKC235", "BKC252", "BKC253", "BKC254", "BKC255", "BR12S",
			"BR20S", "BU21S", "BU32S", "CO04S", "COLLECTION_TRD", "CT20S", "CT32S", "CV25", "FI20S", "FI21S", "FI34S",
			"FMD21S", "FR21S", "FR32S", "FU20S", "FU21S", "FU32S", "FU34S", "G103S", "G209SF", "G211S", "G218C",
			"G417S", "G500S", "G540S", "G547S", "G960S", "IN06S", "IN09S", "IN21S", "IN25S", "IN27S", "IN31S", "LL21S",
			"LL34S", "LMD21S", "LMD32S", "LMD34S", "MF20S", "MF24S", "MF31S", "MF32S", "MT24S", "MT33S", "MT34B",
			"MT34S", "NON_FINANCIAL_TRD", "OF32S", "OF34S", "PAYMNT03", "PER222", "PER224", "PT20S", "PT21S", "PT34S",
			"PUBLIC_SERVICE_TRD", "RE102S", "RE12S", "RE30S", "RE32S", "RET11", "RET132", "RET14", "RET142", "RET222",
			"RET223", "RET224", "RET225", "RET315", "RET320", "RET51", "RET84", "REV202", "REV203", "REV204", "REV222",
			"REV223", "REV225", "REV320", "REV92", "REVBAL01", "REVBAL02", "REVBAL03", "REVBAL04", "REVBAL05",
			"REVBAL06", "REVBAL07", "REVBAL08", "REVBAL09", "REVBAL10", "REVBAL11", "REVBAL12", "REVBAL13", "REVBAL14",
			"REVBAL15", "REVBAL16", "REVBAL17", "REVBAL18", "REVBAL19", "REVBAL20", "REVBAL21", "REVBAL22", "REVBAL23",
			"REVBAL24", "RI20S", "RI21S", "RI24S", "RI27S", "RI29S", "RI30S", "RI31S", "RI32S", "RLE904", "RLE905",
			"RR102S", "RR201S", "RT06S", "RT201S", "RT31S", "RVLR03", "RVLR06", "S043S", "S064D", "S209D", "SE21S",
			"SE34S", "TEL31S", "TEL32S", "TRANBAL01", "TRANBAL02", "TRANBAL03", "TRANBAL04", "TRANBAL05", "TRANBAL06",
			"TRANBAL07", "TRANBAL08", "TRANBAL09", "TRANBAL10", "TRANBAL11", "TRANBAL12", "TRANBAL13", "TRANBAL14",
			"TRANBAL15", "TRANBAL16", "TRANBAL17", "TRANBAL18", "TRANBAL19", "TRANBAL20", "TRANBAL21", "TRANBAL22",
			"TRANBAL23", "TRANBAL24", "TRV05", "TRV14", "TRV17", "TRV18", "UL01S", "UL06S", "UL21S", "UL25S", "UL30S",
			"UL32S", "US20S", "US25S", "WALSHR07", "WD71" };
	static List<String> listaQueries;
	static List<List<List<String>>> queriesResult1;

	private int linea = 0;
	int Errores = 0;

	@Test
	public void test1Estructura() throws Exception {
		Errores = 0;

		try (BufferedReader buffReader = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(new FileInputStream(origenFileUNO + fileNameUNO)), "UTF-8"))) {
			String data;
			String dataReading = null;
			this.linea = 1;
			PruebaFase4TradesHDComparacion.testEstructura = true;
			imprimirReporte("Prueba_Estructura_", "DETALLE ERROR|"
					+ Arrays.toString(cabecero).replace(",", "|").replace("[", "").replace("]", "").replace(" ", "")
					+ "\n", false);
			while ((data = buffReader.readLine()) != null) {
				PruebaFase4TradesHDComparacion.test = true;

				dataReading = data;

				if (dataReading.endsWith("|")) {
					dataReading = dataReading.replace("|", "|-");
				}
				if (linea == 1 && linea == 2 && (!dataReading.equals(Arrays.toString(cabecero).replace(",", "|")
						.replace("[", "").replace("]", "").replace(" ", "")))) {
					imprimirReporte("Prueba_Estructura_", "Error en el nombrado de campos\n", true);
					PruebaFase4TradesHDComparacion.testEstructura = false;
					test = false;
				}
				if (linea != 2 && (dataReading.split("\\|").length != 241)) {
					imprimirReporte("Prueba_Estructura_",
							"Numero de campos es diferente al establecido, en la linea--> " + linea
									+ " el archivo tiene --> " + dataReading.split("\\|").length + " campos|" + data
									+ "\n",
							true);
					// PruebaFase1TradesComparacion.testEstructura = false;
					test = false;
				}

				if (!test) {
					logger.error("Se encontraron errores en la comparacion en la linea--> " + linea);
					softAssert.fail("Se encontraron errores en la comparacion en la linea--> " + linea);

					Errores++;
				} else {
					logger.info("Linea --> " + linea + " ok");

				}
				this.linea++;
			}
			imprimirReporte("Prueba_Estructura_",
					"Numero de registros analizados " + (linea - 1) + " errores encontrados " + Errores + "\n", true);
			softAssert.assertAll();
			imprimirReporte("Prueba_Estructura_", "Prueba ejecutada sin errores\n", true);
		}
	}

	@Test
	public void test2pruebaArchivo() throws Exception {

		String idTerceroL = "";
		Errores = 0;
		this.linea = 1;
		imprimirReporte("Test_Archivo_", "", false);
		if (true/*PruebaFase1TradesHDComparacion.testEstructura*/) {
		try (BufferedReader buffReaderUNO = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(new FileInputStream(origenFileUNO + fileNameUNO)), "UTF-8"))) {
			String dataUNO="";
			buffReaderUNO.readLine();
		
	
		
		try (BufferedReader buffReaderDOS = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(new FileInputStream(origenFileDOS + fileNameDOS)), "UTF-8"))) {
			String dataDOS="";
			buffReaderDOS.readLine();
		

			
		imprimirReporte("Test_Archivo_", "Linea\tSec_ter\tVariable\tSAS_Valor\tDATA_Valor\tPatron\n", true);
			while ((dataUNO = buffReaderUNO.readLine()) != null && (dataDOS = buffReaderDOS.readLine()) != null){
				this.linea++;
				if (dataUNO.endsWith("|")) {
					dataUNO = dataUNO + " |";
				}
				test = true;
				if (dataUNO.split("\\|").length == 239) {
					// archivo plano set
					Fase4ResultadoArchivoPlanoUNO.setDatosArchivoPlano(dataUNO);

				}
				if(dataDOS.split("\\|").length == 239) {
					// archivo plano set
					Fase4ResultadoArchivoPlanoDOS.setDatosArchivoPlano(dataDOS);

				}


				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1101().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1101())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1101(), Fase4ResultadoArchivoPlanoDOS.getAGG1101(), cabecero[1]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1102().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1102())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1102(), Fase4ResultadoArchivoPlanoDOS.getAGG1102(), cabecero[2]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1103().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1103())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1103(), Fase4ResultadoArchivoPlanoDOS.getAGG1103(), cabecero[3]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1104().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1104())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1104(), Fase4ResultadoArchivoPlanoDOS.getAGG1104(), cabecero[4]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1105().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1105())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1105(), Fase4ResultadoArchivoPlanoDOS.getAGG1105(), cabecero[5]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1106().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1106())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1106(), Fase4ResultadoArchivoPlanoDOS.getAGG1106(), cabecero[6]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1107().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1107())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1107(), Fase4ResultadoArchivoPlanoDOS.getAGG1107(), cabecero[7]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1108().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1108())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1108(), Fase4ResultadoArchivoPlanoDOS.getAGG1108(), cabecero[8]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1109().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1109())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1109(), Fase4ResultadoArchivoPlanoDOS.getAGG1109(), cabecero[9]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1110().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1110())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1110(), Fase4ResultadoArchivoPlanoDOS.getAGG1110(), cabecero[10]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1111().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1111())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1111(), Fase4ResultadoArchivoPlanoDOS.getAGG1111(), cabecero[11]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1112().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1112())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1112(), Fase4ResultadoArchivoPlanoDOS.getAGG1112(), cabecero[12]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1113().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1113())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1113(), Fase4ResultadoArchivoPlanoDOS.getAGG1113(), cabecero[13]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1114().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1114())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1114(), Fase4ResultadoArchivoPlanoDOS.getAGG1114(), cabecero[14]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1115().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1115())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1115(), Fase4ResultadoArchivoPlanoDOS.getAGG1115(), cabecero[15]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1116().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1116())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1116(), Fase4ResultadoArchivoPlanoDOS.getAGG1116(), cabecero[16]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1117().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1117())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1117(), Fase4ResultadoArchivoPlanoDOS.getAGG1117(), cabecero[17]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1118().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1118())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1118(), Fase4ResultadoArchivoPlanoDOS.getAGG1118(), cabecero[18]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1119().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1119())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1119(), Fase4ResultadoArchivoPlanoDOS.getAGG1119(), cabecero[19]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1120().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1120())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1120(), Fase4ResultadoArchivoPlanoDOS.getAGG1120(), cabecero[20]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1121().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1121())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1121(), Fase4ResultadoArchivoPlanoDOS.getAGG1121(), cabecero[21]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1122().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1122())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1122(), Fase4ResultadoArchivoPlanoDOS.getAGG1122(), cabecero[22]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1123().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1123())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1123(), Fase4ResultadoArchivoPlanoDOS.getAGG1123(), cabecero[23]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG1124().equals(Fase4ResultadoArchivoPlanoDOS.getAGG1124())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG1124(), Fase4ResultadoArchivoPlanoDOS.getAGG1124(), cabecero[24]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG701().equals(Fase4ResultadoArchivoPlanoDOS.getAGG701())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG701(), Fase4ResultadoArchivoPlanoDOS.getAGG701(), cabecero[25]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG702().equals(Fase4ResultadoArchivoPlanoDOS.getAGG702())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG702(), Fase4ResultadoArchivoPlanoDOS.getAGG702(), cabecero[26]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG703().equals(Fase4ResultadoArchivoPlanoDOS.getAGG703())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG703(), Fase4ResultadoArchivoPlanoDOS.getAGG703(), cabecero[27]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG704().equals(Fase4ResultadoArchivoPlanoDOS.getAGG704())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG704(), Fase4ResultadoArchivoPlanoDOS.getAGG704(), cabecero[28]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG705().equals(Fase4ResultadoArchivoPlanoDOS.getAGG705())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG705(), Fase4ResultadoArchivoPlanoDOS.getAGG705(), cabecero[29]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG706().equals(Fase4ResultadoArchivoPlanoDOS.getAGG706())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG706(), Fase4ResultadoArchivoPlanoDOS.getAGG706(), cabecero[30]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG707().equals(Fase4ResultadoArchivoPlanoDOS.getAGG707())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG707(), Fase4ResultadoArchivoPlanoDOS.getAGG707(), cabecero[31]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG708().equals(Fase4ResultadoArchivoPlanoDOS.getAGG708())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG708(), Fase4ResultadoArchivoPlanoDOS.getAGG708(), cabecero[32]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG709().equals(Fase4ResultadoArchivoPlanoDOS.getAGG709())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG709(), Fase4ResultadoArchivoPlanoDOS.getAGG709(), cabecero[33]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG710().equals(Fase4ResultadoArchivoPlanoDOS.getAGG710())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG710(), Fase4ResultadoArchivoPlanoDOS.getAGG710(), cabecero[34]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG711().equals(Fase4ResultadoArchivoPlanoDOS.getAGG711())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG711(), Fase4ResultadoArchivoPlanoDOS.getAGG711(), cabecero[35]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG712().equals(Fase4ResultadoArchivoPlanoDOS.getAGG712())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG712(), Fase4ResultadoArchivoPlanoDOS.getAGG712(), cabecero[36]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG713().equals(Fase4ResultadoArchivoPlanoDOS.getAGG713())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG713(), Fase4ResultadoArchivoPlanoDOS.getAGG713(), cabecero[37]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG714().equals(Fase4ResultadoArchivoPlanoDOS.getAGG714())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG714(), Fase4ResultadoArchivoPlanoDOS.getAGG714(), cabecero[38]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG715().equals(Fase4ResultadoArchivoPlanoDOS.getAGG715())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG715(), Fase4ResultadoArchivoPlanoDOS.getAGG715(), cabecero[39]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG716().equals(Fase4ResultadoArchivoPlanoDOS.getAGG716())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG716(), Fase4ResultadoArchivoPlanoDOS.getAGG716(), cabecero[40]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG717().equals(Fase4ResultadoArchivoPlanoDOS.getAGG717())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG717(), Fase4ResultadoArchivoPlanoDOS.getAGG717(), cabecero[41]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG718().equals(Fase4ResultadoArchivoPlanoDOS.getAGG718())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG718(), Fase4ResultadoArchivoPlanoDOS.getAGG718(), cabecero[42]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG719().equals(Fase4ResultadoArchivoPlanoDOS.getAGG719())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG719(), Fase4ResultadoArchivoPlanoDOS.getAGG719(), cabecero[43]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG720().equals(Fase4ResultadoArchivoPlanoDOS.getAGG720())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG720(), Fase4ResultadoArchivoPlanoDOS.getAGG720(), cabecero[44]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG721().equals(Fase4ResultadoArchivoPlanoDOS.getAGG721())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG721(), Fase4ResultadoArchivoPlanoDOS.getAGG721(), cabecero[45]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG722().equals(Fase4ResultadoArchivoPlanoDOS.getAGG722())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG722(), Fase4ResultadoArchivoPlanoDOS.getAGG722(), cabecero[46]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG723().equals(Fase4ResultadoArchivoPlanoDOS.getAGG723())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG723(), Fase4ResultadoArchivoPlanoDOS.getAGG723(), cabecero[47]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG724().equals(Fase4ResultadoArchivoPlanoDOS.getAGG724())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG724(), Fase4ResultadoArchivoPlanoDOS.getAGG724(), cabecero[48]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG904().equals(Fase4ResultadoArchivoPlanoDOS.getAGG904())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG904(), Fase4ResultadoArchivoPlanoDOS.getAGG904(), cabecero[49]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG909().equals(Fase4ResultadoArchivoPlanoDOS.getAGG909())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG909(), Fase4ResultadoArchivoPlanoDOS.getAGG909(), cabecero[50]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG910().equals(Fase4ResultadoArchivoPlanoDOS.getAGG910())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG910(), Fase4ResultadoArchivoPlanoDOS.getAGG910(), cabecero[51]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAGG911().equals(Fase4ResultadoArchivoPlanoDOS.getAGG911())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAGG911(), Fase4ResultadoArchivoPlanoDOS.getAGG911(), cabecero[52]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAT27SF().equals(Fase4ResultadoArchivoPlanoDOS.getAT27SF())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAT27SF(), Fase4ResultadoArchivoPlanoDOS.getAT27SF(), cabecero[53]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAT31S().equals(Fase4ResultadoArchivoPlanoDOS.getAT31S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAT31S(), Fase4ResultadoArchivoPlanoDOS.getAT31S(), cabecero[54]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAU21S().equals(Fase4ResultadoArchivoPlanoDOS.getAU21S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAU21S(), Fase4ResultadoArchivoPlanoDOS.getAU21S(), cabecero[55]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getAU51A().equals(Fase4ResultadoArchivoPlanoDOS.getAU51A())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getAU51A(), Fase4ResultadoArchivoPlanoDOS.getAU51A(), cabecero[56]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBC01S().equals(Fase4ResultadoArchivoPlanoDOS.getBC01S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBC01S(), Fase4ResultadoArchivoPlanoDOS.getBC01S(), cabecero[57]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBC20S().equals(Fase4ResultadoArchivoPlanoDOS.getBC20S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBC20S(), Fase4ResultadoArchivoPlanoDOS.getBC20S(), cabecero[58]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBC21S().equals(Fase4ResultadoArchivoPlanoDOS.getBC21S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBC21S(), Fase4ResultadoArchivoPlanoDOS.getBC21S(), cabecero[59]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBI20S().equals(Fase4ResultadoArchivoPlanoDOS.getBI20S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBI20S(), Fase4ResultadoArchivoPlanoDOS.getBI20S(), cabecero[60]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBI21S().equals(Fase4ResultadoArchivoPlanoDOS.getBI21S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBI21S(), Fase4ResultadoArchivoPlanoDOS.getBI21S(), cabecero[61]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBI29S().equals(Fase4ResultadoArchivoPlanoDOS.getBI29S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBI29S(), Fase4ResultadoArchivoPlanoDOS.getBI29S(), cabecero[62]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBI32S().equals(Fase4ResultadoArchivoPlanoDOS.getBI32S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBI32S(), Fase4ResultadoArchivoPlanoDOS.getBI32S(), cabecero[63]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBKC231().equals(Fase4ResultadoArchivoPlanoDOS.getBKC231())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBKC231(), Fase4ResultadoArchivoPlanoDOS.getBKC231(), cabecero[64]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBKC232().equals(Fase4ResultadoArchivoPlanoDOS.getBKC232())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBKC232(), Fase4ResultadoArchivoPlanoDOS.getBKC232(), cabecero[65]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBKC233().equals(Fase4ResultadoArchivoPlanoDOS.getBKC233())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBKC233(), Fase4ResultadoArchivoPlanoDOS.getBKC233(), cabecero[66]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBKC235().equals(Fase4ResultadoArchivoPlanoDOS.getBKC235())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBKC235(), Fase4ResultadoArchivoPlanoDOS.getBKC235(), cabecero[67]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBKC252().equals(Fase4ResultadoArchivoPlanoDOS.getBKC252())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBKC252(), Fase4ResultadoArchivoPlanoDOS.getBKC252(), cabecero[68]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBKC253().equals(Fase4ResultadoArchivoPlanoDOS.getBKC253())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBKC253(), Fase4ResultadoArchivoPlanoDOS.getBKC253(), cabecero[69]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBKC254().equals(Fase4ResultadoArchivoPlanoDOS.getBKC254())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBKC254(), Fase4ResultadoArchivoPlanoDOS.getBKC254(), cabecero[70]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBKC255().equals(Fase4ResultadoArchivoPlanoDOS.getBKC255())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBKC255(), Fase4ResultadoArchivoPlanoDOS.getBKC255(), cabecero[71]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBR12S().equals(Fase4ResultadoArchivoPlanoDOS.getBR12S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBR12S(), Fase4ResultadoArchivoPlanoDOS.getBR12S(), cabecero[72]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBR20S().equals(Fase4ResultadoArchivoPlanoDOS.getBR20S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBR20S(), Fase4ResultadoArchivoPlanoDOS.getBR20S(), cabecero[73]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBU21S().equals(Fase4ResultadoArchivoPlanoDOS.getBU21S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBU21S(), Fase4ResultadoArchivoPlanoDOS.getBU21S(), cabecero[74]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getBU32S().equals(Fase4ResultadoArchivoPlanoDOS.getBU32S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getBU32S(), Fase4ResultadoArchivoPlanoDOS.getBU32S(), cabecero[75]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getCO04S().equals(Fase4ResultadoArchivoPlanoDOS.getCO04S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getCO04S(), Fase4ResultadoArchivoPlanoDOS.getCO04S(), cabecero[76]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getCOLLECTION_TRD().equals(Fase4ResultadoArchivoPlanoDOS.getCOLLECTION_TRD())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getCOLLECTION_TRD(), Fase4ResultadoArchivoPlanoDOS.getCOLLECTION_TRD(), cabecero[77]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getCT20S().equals(Fase4ResultadoArchivoPlanoDOS.getCT20S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getCT20S(), Fase4ResultadoArchivoPlanoDOS.getCT20S(), cabecero[78]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getCT32S().equals(Fase4ResultadoArchivoPlanoDOS.getCT32S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getCT32S(), Fase4ResultadoArchivoPlanoDOS.getCT32S(), cabecero[79]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getCV25().equals(Fase4ResultadoArchivoPlanoDOS.getCV25())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getCV25(), Fase4ResultadoArchivoPlanoDOS.getCV25(), cabecero[80]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getFI20S().equals(Fase4ResultadoArchivoPlanoDOS.getFI20S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getFI20S(), Fase4ResultadoArchivoPlanoDOS.getFI20S(), cabecero[81]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getFI21S().equals(Fase4ResultadoArchivoPlanoDOS.getFI21S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getFI21S(), Fase4ResultadoArchivoPlanoDOS.getFI21S(), cabecero[82]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getFI34S().equals(Fase4ResultadoArchivoPlanoDOS.getFI34S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getFI34S(), Fase4ResultadoArchivoPlanoDOS.getFI34S(), cabecero[83]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getFMD21S().equals(Fase4ResultadoArchivoPlanoDOS.getFMD21S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getFMD21S(), Fase4ResultadoArchivoPlanoDOS.getFMD21S(), cabecero[84]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getFR21S().equals(Fase4ResultadoArchivoPlanoDOS.getFR21S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getFR21S(), Fase4ResultadoArchivoPlanoDOS.getFR21S(), cabecero[85]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getFR32S().equals(Fase4ResultadoArchivoPlanoDOS.getFR32S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getFR32S(), Fase4ResultadoArchivoPlanoDOS.getFR32S(), cabecero[86]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getFU20S().equals(Fase4ResultadoArchivoPlanoDOS.getFU20S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getFU20S(), Fase4ResultadoArchivoPlanoDOS.getFU20S(), cabecero[87]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getFU21S().equals(Fase4ResultadoArchivoPlanoDOS.getFU21S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getFU21S(), Fase4ResultadoArchivoPlanoDOS.getFU21S(), cabecero[88]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getFU32S().equals(Fase4ResultadoArchivoPlanoDOS.getFU32S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getFU32S(), Fase4ResultadoArchivoPlanoDOS.getFU32S(), cabecero[89]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getFU34S().equals(Fase4ResultadoArchivoPlanoDOS.getFU34S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getFU34S(), Fase4ResultadoArchivoPlanoDOS.getFU34S(), cabecero[90]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getG103S().equals(Fase4ResultadoArchivoPlanoDOS.getG103S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getG103S(), Fase4ResultadoArchivoPlanoDOS.getG103S(), cabecero[91]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getG209SF().equals(Fase4ResultadoArchivoPlanoDOS.getG209SF())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getG209SF(), Fase4ResultadoArchivoPlanoDOS.getG209SF(), cabecero[92]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getG211S().equals(Fase4ResultadoArchivoPlanoDOS.getG211S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getG211S(), Fase4ResultadoArchivoPlanoDOS.getG211S(), cabecero[93]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getG218C().equals(Fase4ResultadoArchivoPlanoDOS.getG218C())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getG218C(), Fase4ResultadoArchivoPlanoDOS.getG218C(), cabecero[94]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getG417S().equals(Fase4ResultadoArchivoPlanoDOS.getG417S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getG417S(), Fase4ResultadoArchivoPlanoDOS.getG417S(), cabecero[95]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getG500S().equals(Fase4ResultadoArchivoPlanoDOS.getG500S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getG500S(), Fase4ResultadoArchivoPlanoDOS.getG500S(), cabecero[96]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getG540S().equals(Fase4ResultadoArchivoPlanoDOS.getG540S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getG540S(), Fase4ResultadoArchivoPlanoDOS.getG540S(), cabecero[97]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getG547S().equals(Fase4ResultadoArchivoPlanoDOS.getG547S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getG547S(), Fase4ResultadoArchivoPlanoDOS.getG547S(), cabecero[98]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getG960S().equals(Fase4ResultadoArchivoPlanoDOS.getG960S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getG960S(), Fase4ResultadoArchivoPlanoDOS.getG960S(), cabecero[99]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getIN06S().equals(Fase4ResultadoArchivoPlanoDOS.getIN06S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getIN06S(), Fase4ResultadoArchivoPlanoDOS.getIN06S(), cabecero[100]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getIN09S().equals(Fase4ResultadoArchivoPlanoDOS.getIN09S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getIN09S(), Fase4ResultadoArchivoPlanoDOS.getIN09S(), cabecero[101]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getIN21S().equals(Fase4ResultadoArchivoPlanoDOS.getIN21S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getIN21S(), Fase4ResultadoArchivoPlanoDOS.getIN21S(), cabecero[102]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getIN25S().equals(Fase4ResultadoArchivoPlanoDOS.getIN25S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getIN25S(), Fase4ResultadoArchivoPlanoDOS.getIN25S(), cabecero[103]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getIN27S().equals(Fase4ResultadoArchivoPlanoDOS.getIN27S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getIN27S(), Fase4ResultadoArchivoPlanoDOS.getIN27S(), cabecero[104]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getIN31S().equals(Fase4ResultadoArchivoPlanoDOS.getIN31S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getIN31S(), Fase4ResultadoArchivoPlanoDOS.getIN31S(), cabecero[105]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getLL21S().equals(Fase4ResultadoArchivoPlanoDOS.getLL21S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getLL21S(), Fase4ResultadoArchivoPlanoDOS.getLL21S(), cabecero[106]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getLL34S().equals(Fase4ResultadoArchivoPlanoDOS.getLL34S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getLL34S(), Fase4ResultadoArchivoPlanoDOS.getLL34S(), cabecero[107]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getLMD21S().equals(Fase4ResultadoArchivoPlanoDOS.getLMD21S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getLMD21S(), Fase4ResultadoArchivoPlanoDOS.getLMD21S(), cabecero[108]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getLMD32S().equals(Fase4ResultadoArchivoPlanoDOS.getLMD32S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getLMD32S(), Fase4ResultadoArchivoPlanoDOS.getLMD32S(), cabecero[109]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getLMD34S().equals(Fase4ResultadoArchivoPlanoDOS.getLMD34S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getLMD34S(), Fase4ResultadoArchivoPlanoDOS.getLMD34S(), cabecero[110]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getMF20S().equals(Fase4ResultadoArchivoPlanoDOS.getMF20S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getMF20S(), Fase4ResultadoArchivoPlanoDOS.getMF20S(), cabecero[111]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getMF24S().equals(Fase4ResultadoArchivoPlanoDOS.getMF24S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getMF24S(), Fase4ResultadoArchivoPlanoDOS.getMF24S(), cabecero[112]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getMF31S().equals(Fase4ResultadoArchivoPlanoDOS.getMF31S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getMF31S(), Fase4ResultadoArchivoPlanoDOS.getMF31S(), cabecero[113]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getMF32S().equals(Fase4ResultadoArchivoPlanoDOS.getMF32S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getMF32S(), Fase4ResultadoArchivoPlanoDOS.getMF32S(), cabecero[114]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getMT24S().equals(Fase4ResultadoArchivoPlanoDOS.getMT24S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getMT24S(), Fase4ResultadoArchivoPlanoDOS.getMT24S(), cabecero[115]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getMT33S().equals(Fase4ResultadoArchivoPlanoDOS.getMT33S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getMT33S(), Fase4ResultadoArchivoPlanoDOS.getMT33S(), cabecero[116]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getMT34B().equals(Fase4ResultadoArchivoPlanoDOS.getMT34B())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getMT34B(), Fase4ResultadoArchivoPlanoDOS.getMT34B(), cabecero[117]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getMT34S().equals(Fase4ResultadoArchivoPlanoDOS.getMT34S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getMT34S(), Fase4ResultadoArchivoPlanoDOS.getMT34S(), cabecero[118]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getNON_FINANCIAL_TRD().equals(Fase4ResultadoArchivoPlanoDOS.getNON_FINANCIAL_TRD())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getNON_FINANCIAL_TRD(), Fase4ResultadoArchivoPlanoDOS.getNON_FINANCIAL_TRD(), cabecero[119]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getOF32S().equals(Fase4ResultadoArchivoPlanoDOS.getOF32S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getOF32S(), Fase4ResultadoArchivoPlanoDOS.getOF32S(), cabecero[120]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getOF34S().equals(Fase4ResultadoArchivoPlanoDOS.getOF34S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getOF34S(), Fase4ResultadoArchivoPlanoDOS.getOF34S(), cabecero[121]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getPAYMNT03().equals(Fase4ResultadoArchivoPlanoDOS.getPAYMNT03())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getPAYMNT03(), Fase4ResultadoArchivoPlanoDOS.getPAYMNT03(), cabecero[122]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getPER222().equals(Fase4ResultadoArchivoPlanoDOS.getPER222())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getPER222(), Fase4ResultadoArchivoPlanoDOS.getPER222(), cabecero[123]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getPER224().equals(Fase4ResultadoArchivoPlanoDOS.getPER224())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getPER224(), Fase4ResultadoArchivoPlanoDOS.getPER224(), cabecero[124]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getPT20S().equals(Fase4ResultadoArchivoPlanoDOS.getPT20S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getPT20S(), Fase4ResultadoArchivoPlanoDOS.getPT20S(), cabecero[125]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getPT21S().equals(Fase4ResultadoArchivoPlanoDOS.getPT21S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getPT21S(), Fase4ResultadoArchivoPlanoDOS.getPT21S(), cabecero[126]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getPT34S().equals(Fase4ResultadoArchivoPlanoDOS.getPT34S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getPT34S(), Fase4ResultadoArchivoPlanoDOS.getPT34S(), cabecero[127]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getPUBLIC_SERVICE_TRD().equals(Fase4ResultadoArchivoPlanoDOS.getPUBLIC_SERVICE_TRD())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getPUBLIC_SERVICE_TRD(), Fase4ResultadoArchivoPlanoDOS.getPUBLIC_SERVICE_TRD(), cabecero[128]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRE102S().equals(Fase4ResultadoArchivoPlanoDOS.getRE102S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRE102S(), Fase4ResultadoArchivoPlanoDOS.getRE102S(), cabecero[129]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRE12S().equals(Fase4ResultadoArchivoPlanoDOS.getRE12S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRE12S(), Fase4ResultadoArchivoPlanoDOS.getRE12S(), cabecero[130]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRE30S().equals(Fase4ResultadoArchivoPlanoDOS.getRE30S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRE30S(), Fase4ResultadoArchivoPlanoDOS.getRE30S(), cabecero[131]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRE32S().equals(Fase4ResultadoArchivoPlanoDOS.getRE32S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRE32S(), Fase4ResultadoArchivoPlanoDOS.getRE32S(), cabecero[132]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRET11().equals(Fase4ResultadoArchivoPlanoDOS.getRET11())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRET11(), Fase4ResultadoArchivoPlanoDOS.getRET11(), cabecero[133]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRET132().equals(Fase4ResultadoArchivoPlanoDOS.getRET132())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRET132(), Fase4ResultadoArchivoPlanoDOS.getRET132(), cabecero[134]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRET14().equals(Fase4ResultadoArchivoPlanoDOS.getRET14())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRET14(), Fase4ResultadoArchivoPlanoDOS.getRET14(), cabecero[135]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRET142().equals(Fase4ResultadoArchivoPlanoDOS.getRET142())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRET142(), Fase4ResultadoArchivoPlanoDOS.getRET142(), cabecero[136]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRET222().equals(Fase4ResultadoArchivoPlanoDOS.getRET222())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRET222(), Fase4ResultadoArchivoPlanoDOS.getRET222(), cabecero[137]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRET223().equals(Fase4ResultadoArchivoPlanoDOS.getRET223())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRET223(), Fase4ResultadoArchivoPlanoDOS.getRET223(), cabecero[138]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRET224().equals(Fase4ResultadoArchivoPlanoDOS.getRET224())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRET224(), Fase4ResultadoArchivoPlanoDOS.getRET224(), cabecero[139]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRET225().equals(Fase4ResultadoArchivoPlanoDOS.getRET225())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRET225(), Fase4ResultadoArchivoPlanoDOS.getRET225(), cabecero[140]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRET315().equals(Fase4ResultadoArchivoPlanoDOS.getRET315())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRET315(), Fase4ResultadoArchivoPlanoDOS.getRET315(), cabecero[141]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRET320().equals(Fase4ResultadoArchivoPlanoDOS.getRET320())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRET320(), Fase4ResultadoArchivoPlanoDOS.getRET320(), cabecero[142]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRET51().equals(Fase4ResultadoArchivoPlanoDOS.getRET51())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRET51(), Fase4ResultadoArchivoPlanoDOS.getRET51(), cabecero[143]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRET84().equals(Fase4ResultadoArchivoPlanoDOS.getRET84())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRET84(), Fase4ResultadoArchivoPlanoDOS.getRET84(), cabecero[144]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREV202().equals(Fase4ResultadoArchivoPlanoDOS.getREV202())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREV202(), Fase4ResultadoArchivoPlanoDOS.getREV202(), cabecero[145]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREV203().equals(Fase4ResultadoArchivoPlanoDOS.getREV203())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREV203(), Fase4ResultadoArchivoPlanoDOS.getREV203(), cabecero[146]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREV204().equals(Fase4ResultadoArchivoPlanoDOS.getREV204())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREV204(), Fase4ResultadoArchivoPlanoDOS.getREV204(), cabecero[147]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREV222().equals(Fase4ResultadoArchivoPlanoDOS.getREV222())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREV222(), Fase4ResultadoArchivoPlanoDOS.getREV222(), cabecero[148]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREV223().equals(Fase4ResultadoArchivoPlanoDOS.getREV223())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREV223(), Fase4ResultadoArchivoPlanoDOS.getREV223(), cabecero[149]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREV225().equals(Fase4ResultadoArchivoPlanoDOS.getREV225())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREV225(), Fase4ResultadoArchivoPlanoDOS.getREV225(), cabecero[150]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREV320().equals(Fase4ResultadoArchivoPlanoDOS.getREV320())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREV320(), Fase4ResultadoArchivoPlanoDOS.getREV320(), cabecero[151]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREV92().equals(Fase4ResultadoArchivoPlanoDOS.getREV92())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREV92(), Fase4ResultadoArchivoPlanoDOS.getREV92(), cabecero[152]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL01().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL01())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL01(), Fase4ResultadoArchivoPlanoDOS.getREVBAL01(), cabecero[153]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL02().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL02())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL02(), Fase4ResultadoArchivoPlanoDOS.getREVBAL02(), cabecero[154]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL03().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL03())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL03(), Fase4ResultadoArchivoPlanoDOS.getREVBAL03(), cabecero[155]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL04().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL04())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL04(), Fase4ResultadoArchivoPlanoDOS.getREVBAL04(), cabecero[156]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL05().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL05())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL05(), Fase4ResultadoArchivoPlanoDOS.getREVBAL05(), cabecero[157]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL06().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL06())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL06(), Fase4ResultadoArchivoPlanoDOS.getREVBAL06(), cabecero[158]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL07().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL07())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL07(), Fase4ResultadoArchivoPlanoDOS.getREVBAL07(), cabecero[159]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL08().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL08())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL08(), Fase4ResultadoArchivoPlanoDOS.getREVBAL08(), cabecero[160]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL09().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL09())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL09(), Fase4ResultadoArchivoPlanoDOS.getREVBAL09(), cabecero[161]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL10().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL10())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL10(), Fase4ResultadoArchivoPlanoDOS.getREVBAL10(), cabecero[162]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL11().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL11())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL11(), Fase4ResultadoArchivoPlanoDOS.getREVBAL11(), cabecero[163]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL12().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL12())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL12(), Fase4ResultadoArchivoPlanoDOS.getREVBAL12(), cabecero[164]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL13().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL13())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL13(), Fase4ResultadoArchivoPlanoDOS.getREVBAL13(), cabecero[165]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL14().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL14())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL14(), Fase4ResultadoArchivoPlanoDOS.getREVBAL14(), cabecero[166]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL15().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL15())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL15(), Fase4ResultadoArchivoPlanoDOS.getREVBAL15(), cabecero[167]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL16().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL16())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL16(), Fase4ResultadoArchivoPlanoDOS.getREVBAL16(), cabecero[168]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL17().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL17())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL17(), Fase4ResultadoArchivoPlanoDOS.getREVBAL17(), cabecero[169]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL18().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL18())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL18(), Fase4ResultadoArchivoPlanoDOS.getREVBAL18(), cabecero[170]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL19().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL19())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL19(), Fase4ResultadoArchivoPlanoDOS.getREVBAL19(), cabecero[171]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL20().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL20())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL20(), Fase4ResultadoArchivoPlanoDOS.getREVBAL20(), cabecero[172]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL21().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL21())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL21(), Fase4ResultadoArchivoPlanoDOS.getREVBAL21(), cabecero[173]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL22().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL22())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL22(), Fase4ResultadoArchivoPlanoDOS.getREVBAL22(), cabecero[174]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL23().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL23())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL23(), Fase4ResultadoArchivoPlanoDOS.getREVBAL23(), cabecero[175]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getREVBAL24().equals(Fase4ResultadoArchivoPlanoDOS.getREVBAL24())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getREVBAL24(), Fase4ResultadoArchivoPlanoDOS.getREVBAL24(), cabecero[176]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRI20S().equals(Fase4ResultadoArchivoPlanoDOS.getRI20S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRI20S(), Fase4ResultadoArchivoPlanoDOS.getRI20S(), cabecero[177]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRI21S().equals(Fase4ResultadoArchivoPlanoDOS.getRI21S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRI21S(), Fase4ResultadoArchivoPlanoDOS.getRI21S(), cabecero[178]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRI24S().equals(Fase4ResultadoArchivoPlanoDOS.getRI24S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRI24S(), Fase4ResultadoArchivoPlanoDOS.getRI24S(), cabecero[179]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRI27S().equals(Fase4ResultadoArchivoPlanoDOS.getRI27S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRI27S(), Fase4ResultadoArchivoPlanoDOS.getRI27S(), cabecero[180]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRI29S().equals(Fase4ResultadoArchivoPlanoDOS.getRI29S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRI29S(), Fase4ResultadoArchivoPlanoDOS.getRI29S(), cabecero[181]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRI30S().equals(Fase4ResultadoArchivoPlanoDOS.getRI30S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRI30S(), Fase4ResultadoArchivoPlanoDOS.getRI30S(), cabecero[182]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRI31S().equals(Fase4ResultadoArchivoPlanoDOS.getRI31S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRI31S(), Fase4ResultadoArchivoPlanoDOS.getRI31S(), cabecero[183]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRI32S().equals(Fase4ResultadoArchivoPlanoDOS.getRI32S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRI32S(), Fase4ResultadoArchivoPlanoDOS.getRI32S(), cabecero[184]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRLE904().equals(Fase4ResultadoArchivoPlanoDOS.getRLE904())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRLE904(), Fase4ResultadoArchivoPlanoDOS.getRLE904(), cabecero[185]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRLE905().equals(Fase4ResultadoArchivoPlanoDOS.getRLE905())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRLE905(), Fase4ResultadoArchivoPlanoDOS.getRLE905(), cabecero[186]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRR102S().equals(Fase4ResultadoArchivoPlanoDOS.getRR102S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRR102S(), Fase4ResultadoArchivoPlanoDOS.getRR102S(), cabecero[187]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRR201S().equals(Fase4ResultadoArchivoPlanoDOS.getRR201S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRR201S(), Fase4ResultadoArchivoPlanoDOS.getRR201S(), cabecero[188]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRT06S().equals(Fase4ResultadoArchivoPlanoDOS.getRT06S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRT06S(), Fase4ResultadoArchivoPlanoDOS.getRT06S(), cabecero[189]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRT201S().equals(Fase4ResultadoArchivoPlanoDOS.getRT201S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRT201S(), Fase4ResultadoArchivoPlanoDOS.getRT201S(), cabecero[190]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRT31S().equals(Fase4ResultadoArchivoPlanoDOS.getRT31S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRT31S(), Fase4ResultadoArchivoPlanoDOS.getRT31S(), cabecero[191]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRVLR03().equals(Fase4ResultadoArchivoPlanoDOS.getRVLR03())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRVLR03(), Fase4ResultadoArchivoPlanoDOS.getRVLR03(), cabecero[192]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getRVLR06().equals(Fase4ResultadoArchivoPlanoDOS.getRVLR06())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getRVLR06(), Fase4ResultadoArchivoPlanoDOS.getRVLR06(), cabecero[193]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getS043S().equals(Fase4ResultadoArchivoPlanoDOS.getS043S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getS043S(), Fase4ResultadoArchivoPlanoDOS.getS043S(), cabecero[194]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getS064D().equals(Fase4ResultadoArchivoPlanoDOS.getS064D())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getS064D(), Fase4ResultadoArchivoPlanoDOS.getS064D(), cabecero[195]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getS209D().equals(Fase4ResultadoArchivoPlanoDOS.getS209D())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getS209D(), Fase4ResultadoArchivoPlanoDOS.getS209D(), cabecero[196]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getSE21S().equals(Fase4ResultadoArchivoPlanoDOS.getSE21S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getSE21S(), Fase4ResultadoArchivoPlanoDOS.getSE21S(), cabecero[197]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getSE34S().equals(Fase4ResultadoArchivoPlanoDOS.getSE34S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getSE34S(), Fase4ResultadoArchivoPlanoDOS.getSE34S(), cabecero[198]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTEL31S().equals(Fase4ResultadoArchivoPlanoDOS.getTEL31S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTEL31S(), Fase4ResultadoArchivoPlanoDOS.getTEL31S(), cabecero[199]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTEL32S().equals(Fase4ResultadoArchivoPlanoDOS.getTEL32S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTEL32S(), Fase4ResultadoArchivoPlanoDOS.getTEL32S(), cabecero[200]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL01().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL01())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL01(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL01(), cabecero[201]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL02().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL02())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL02(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL02(), cabecero[202]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL03().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL03())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL03(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL03(), cabecero[203]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL04().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL04())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL04(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL04(), cabecero[204]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL05().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL05())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL05(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL05(), cabecero[205]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL06().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL06())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL06(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL06(), cabecero[206]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL07().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL07())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL07(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL07(), cabecero[207]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL08().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL08())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL08(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL08(), cabecero[208]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL09().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL09())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL09(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL09(), cabecero[209]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL10().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL10())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL10(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL10(), cabecero[210]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL11().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL11())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL11(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL11(), cabecero[211]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL12().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL12())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL12(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL12(), cabecero[212]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL13().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL13())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL13(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL13(), cabecero[213]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL14().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL14())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL14(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL14(), cabecero[214]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL15().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL15())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL15(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL15(), cabecero[215]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL16().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL16())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL16(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL16(), cabecero[216]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL17().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL17())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL17(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL17(), cabecero[217]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL18().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL18())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL18(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL18(), cabecero[218]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL19().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL19())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL19(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL19(), cabecero[219]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL20().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL20())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL20(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL20(), cabecero[220]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL21().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL21())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL21(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL21(), cabecero[221]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL22().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL22())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL22(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL22(), cabecero[222]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL23().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL23())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL23(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL23(), cabecero[223]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRANBAL24().equals(Fase4ResultadoArchivoPlanoDOS.getTRANBAL24())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRANBAL24(), Fase4ResultadoArchivoPlanoDOS.getTRANBAL24(), cabecero[224]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRV05().equals(Fase4ResultadoArchivoPlanoDOS.getTRV05())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRV05(), Fase4ResultadoArchivoPlanoDOS.getTRV05(), cabecero[225]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRV14().equals(Fase4ResultadoArchivoPlanoDOS.getTRV14())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRV14(), Fase4ResultadoArchivoPlanoDOS.getTRV14(), cabecero[226]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRV17().equals(Fase4ResultadoArchivoPlanoDOS.getTRV17())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRV17(), Fase4ResultadoArchivoPlanoDOS.getTRV17(), cabecero[227]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getTRV18().equals(Fase4ResultadoArchivoPlanoDOS.getTRV18())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getTRV18(), Fase4ResultadoArchivoPlanoDOS.getTRV18(), cabecero[228]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getUL01S().equals(Fase4ResultadoArchivoPlanoDOS.getUL01S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getUL01S(), Fase4ResultadoArchivoPlanoDOS.getUL01S(), cabecero[229]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getUL06S().equals(Fase4ResultadoArchivoPlanoDOS.getUL06S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getUL06S(), Fase4ResultadoArchivoPlanoDOS.getUL06S(), cabecero[230]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getUL21S().equals(Fase4ResultadoArchivoPlanoDOS.getUL21S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getUL21S(), Fase4ResultadoArchivoPlanoDOS.getUL21S(), cabecero[231]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getUL25S().equals(Fase4ResultadoArchivoPlanoDOS.getUL25S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getUL25S(), Fase4ResultadoArchivoPlanoDOS.getUL25S(), cabecero[232]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getUL30S().equals(Fase4ResultadoArchivoPlanoDOS.getUL30S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getUL30S(), Fase4ResultadoArchivoPlanoDOS.getUL30S(), cabecero[233]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getUL32S().equals(Fase4ResultadoArchivoPlanoDOS.getUL32S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getUL32S(), Fase4ResultadoArchivoPlanoDOS.getUL32S(), cabecero[234]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getUS20S().equals(Fase4ResultadoArchivoPlanoDOS.getUS20S())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getUS20S(), Fase4ResultadoArchivoPlanoDOS.getUS20S(), cabecero[235]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getUS25S().equals(Fase4ResultadoArchivoPlanoDOS.getUS25S())) { 
					reportarError(Fase4ResultadoArchivoPlanoUNO.getUS25S(), Fase4ResultadoArchivoPlanoDOS.getUS25S(), cabecero[236]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getWALSHR07().equals(Fase4ResultadoArchivoPlanoDOS.getWALSHR07())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getWALSHR07(), Fase4ResultadoArchivoPlanoDOS.getWALSHR07(), cabecero[237]);}
				if (!Fase4ResultadoArchivoPlanoUNO.getWD71().equals(Fase4ResultadoArchivoPlanoDOS.getWD71())) {
					reportarError(Fase4ResultadoArchivoPlanoUNO.getWD71(), Fase4ResultadoArchivoPlanoDOS.getWD71(), cabecero[238]);}

				
				

				if (!test) {
					logger.error("Se encontraron errores en la comparacion de datos "
							+ " Consecutivo  " + Fase4ResultadoArchivoPlanoUNO.getSECUENCIA_TERCERO());
					softAssert.fail("Se encontraron errores en la comparacion de datos  "
							 + " Consecutivo " + Fase4ResultadoArchivoPlanoUNO.getSECUENCIA_TERCERO());

				}

				else {
					System.out
							.println(linea + " Consecutivo " + Fase4ResultadoArchivoPlanoUNO.getSECUENCIA_TERCERO());
				}

			}
			imprimirReporte("Test_Archivo_", "Numero de registros analizados "+(linea)
					+	" errores encontrados "+ Errores+"\n", true);
			softAssert.assertAll();
			imprimirReporte("Test_Archivo_", "Prueba fue ejecutada sin errores, movimientos analizados--> " + (linea - 1),
					true);
		}
		}
		}
				else {

					softAssert.fail("Test de estructura no fue aprobado");
					
				}

			}
		


	private void reportarError(String ArchivoResultados, String ArchivoResultadosDb, String parametro) {

	
		
		if(ArchivoResultados.contains(".")|| ArchivoResultadosDb.contains(".")) {
//			ArchivoResultados.replace(",", ".");
//			ArchivoResultadosDb.replace(",", ".");
			double resultado1 = Double.parseDouble(ArchivoResultados);
			 double resultado2 = Double.parseDouble(ArchivoResultadosDb);
			 double resultadoPatro =(resultado1)-(resultado2);
			
			 String data = linea + "\t"
						+ Fase4ResultadoArchivoPlanoUNO.getSECUENCIA_TERCERO()
						
						+ "\t" + parametro + "\t" + ArchivoResultados.replace(".", ",") + "\t"+ ArchivoResultadosDb.replace(".", ",") +"\t"+ resultadoPatro +"\n";
			 imprimirReporte("Test_Archivo_", data, true);
		}else {
		 int resultado1 = Integer.parseInt(ArchivoResultados);
	
		 int resultado2 = Integer.parseInt(ArchivoResultadosDb);
		 int resultadoPatron =(resultado1)-(resultado2);
		 String data = linea + "\t"
					+ Fase4ResultadoArchivoPlanoUNO.getSECUENCIA_TERCERO()
					
					+ "\t" + parametro + "\t" + ArchivoResultados.replace(".", ",") + "\t"+ ArchivoResultadosDb.replace(".", ",") +"\t"+ resultadoPatron +"\n";
		 imprimirReporte("Test_Archivo_", data, true);
		}
		
		
		//imprimirReporte("Test_Roland_", data, true);
	
		logger.error("Error en la linea--> " + linea 
				+ " IdTercero--> " + Fase4ResultadoArchivoPlanoUNO.getSECUENCIA_TERCERO() + " Variable " + parametro + " File--> " + ArchivoResultados
				+ " Abinitions--> " + ArchivoResultadosDb);
		test = false;
		Errores++;
//
	}

	private void imprimirReporte(String prueba, String data, Boolean escribir) {
		BufferedWriter bw = null;
		FileWriter fw = null;

		try {

			File file = new File(origenFileUNO + prueba + fileNameUNO);
			// Si el archivo no existe, se crea!
			if (!file.exists()) {
				file.createNewFile();
			}
			// flag true, indica adjuntar información al archivo.
			fw = new FileWriter(file.getAbsoluteFile(), escribir);
			bw = new BufferedWriter(fw);
			bw.write(data);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				// Cierra instancias de FileWriter y BufferedWriter
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

}