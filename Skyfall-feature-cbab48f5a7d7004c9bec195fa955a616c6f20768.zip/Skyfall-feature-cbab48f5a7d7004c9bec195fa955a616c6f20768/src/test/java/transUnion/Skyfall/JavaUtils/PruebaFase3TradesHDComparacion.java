package transUnion.Skyfall.JavaUtils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.assertj.core.api.SoftAssertions;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.ibm.icu.text.SimpleDateFormat;

import transUnion.Skyfall.javaUtils.DataBaseUtils;
import transUnion.Skyfall.javaUtils.ReadSqlFile;
import transUnion.Skyfall.models.Fase1ResultadoArchivoPlano;
import transUnion.Skyfall.models.Fase3ResultadoArchivoPlano;
import transUnion.Skyfall.models.Fase3ResultadoBD;




@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PruebaFase3TradesHDComparacion {
	String origenFile = "C:\\Users\\romarti.UNIVERSO\\Automatizacion\\SkyFall\\Archivos_Txt\\test_historicos\\";
	String fileName = "Historico_2020-11-27.txt";
	SoftAssertions softAssert = new SoftAssertions();
	static Logger logger = Logger.getLogger(PruebaFase3TradesHDComparacion.class);
	static boolean testEstructura;
	static boolean test = true;
	SimpleDateFormat date = new SimpleDateFormat("yyyy/MM/dd");
	static String[] cabecero = { "SECUENCIA_TERCERO","FECHA_CALIFICACION","FECHA_CORTE_INFO","AT34A","BI34S",
					"BR27S","BR29S","BR34S","BU09S","CA09S","CA70S","CO04SF","CT24S","CT30S","CT31S","DM211S","DM214S","FR29S",
					"FR34S","FS20S","G212SF","G218BF","G220A","G221D","G306S","G410S","IN01S","IN34S","LL09S","LL30S","LMD30S",
					"LS29S","LS30S","LS34S","OD34S","OF06S","OF09S","PT09S","PT30S","RI06S","RR21S","RR24S","RR25S","RT21S",
					"RT24S","SE09S","TEL09S","TEL21S","TEL30S","UL29S","UL34S","AGG2402","AGG2403","AGG2404","AGG2405","AGG2406",
					"AGG2407","AGG2408","AGG2409","AGG2410","AGG2411","AGG2412","AGG2413","AGG2414","AGG2415","AGG2416","AGG2417",
					"AGG2418","AGG2419","AGG2420","AGG2421","AGG2422","AGG2423","AGG2424","AGG301","AGG302","AGG303","AGG304","AGG305",
					"AGG306","AGG307","AGG308","AGG309","AGG310","AGG311","AGG312","AGG313","AGG314","AGG315","AGG316","AGG317","AGG318",
					"AGG319","AGG320","AGG321","AGG322","AGG323","AGG324","BKC112","AGG905","AGG906","BKC225","PAYMNT50","PAYMNT65","PER201",
					"PER223","PER233","RET13","RET152","RET201","RET81","REV14","REV253","RLE907","RVLR09","TRD","TRV03","TRV12","UL_TRD","WD21",
					"WD31","WD51","WD61","WD81","RET225","BR20S","FU21S","US25S","MF31S","TRV18","POSITIVE_SF","NEGATIVE_SF","SEGMENT_SF","TELCO_SF",
					"WGT_SCR_SF","AGG_SCR_SF","POSITIVE_SR","NEGATIVE_SR","SEGMENT_SR","WGT_SCR_SR","AGG_SCR_SR","CREDITVISION",
					"CREDITVISION_LINK_SERVICIOS_FIN","CREDITVISION_LINK"
};
	static List<String> listaQueries;
	static List<List<List<String>>> queriesResult1;

	private int linea = 0;
	int Errores=0;
	@Test
	public void test1Estructura() throws Exception {
		Errores = 0;
		System.out.println(origenFile+fileName);
		String valor = origenFile+fileName;
		try (BufferedReader buffReader = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(new FileInputStream(origenFile + fileName)),
				"UTF-8"))) {
			String data;
			String dataReading = null;
			this.linea = 1;
			PruebaFase3TradesHDComparacion.testEstructura=true;
			imprimirReporte("Prueba_Estructura_", "DETALLE ERROR|"
					+ Arrays.toString(cabecero).replace(",", "|").replace("[", "").replace("]", "").replace(" ", "")
					+ "\n", false);
			while ((data = buffReader.readLine()) != null) {
				PruebaFase3TradesHDComparacion.test = true;

				dataReading = data;

				if (dataReading.endsWith("|")) {
					dataReading = dataReading.replace("|", "|-");
				}
				if (linea == 1 && linea == 2 && (!dataReading.equals(Arrays.toString(cabecero).replace(",", "|").replace("[", "")
						.replace("]", "").replace(" ", "")))) {
					imprimirReporte("Prueba_Estructura_", "Error en el nombrado de campos\n", true);
					PruebaFase3TradesHDComparacion.testEstructura = false;
					test = false;
				}
				if (linea != 2 && (dataReading.split("\\|").length != 144)) {
					imprimirReporte("Prueba_Estructura_",
							"Numero de campos es diferente al establecido, en la linea--> " + linea
									+ " el archivo tiene --> " + dataReading.split("\\|").length + " campos|" + data + "\n",
							true);
					//PruebaFase1TradesComparacion.testEstructura = false;
					test=false;
				}
		


				if (!test) {
					logger.error("Se encontraron errores en la comparacion en la linea--> " + linea);
					softAssert.fail("Se encontraron errores en la comparacion en la linea--> " + linea);

Errores++;
				}
				else {
					logger.info("Linea --> " + linea + " ok");

				}
				this.linea++;
			}
			imprimirReporte("Prueba_Estructura_", "Numero de registros analizados "+(linea-1)
				+	" errores encontrados "+ Errores+"\n", true);
			softAssert.assertAll();
			imprimirReporte("Prueba_Estructura_", "Prueba ejecutada sin errores\n", true);
		}
	}

	@Test
	public void test2pruebaArchivo() throws Exception {
		
		String idTerceroL = "";	
		Errores=0;
		this.linea = 1;
		imprimirReporte("Test_Archivo_", "", false);
		if (true/*PruebaFase1TradesHDComparacion.testEstructura*/) {
			try (BufferedReader buffReader = new BufferedReader(new InputStreamReader(
					new BufferedInputStream(new FileInputStream(origenFile + fileName)),
					"UTF-8"))) {
				String data;
				buffReader.readLine();
		
				imprimirReporte("Test_Archivo_", "Linea\tSec_ter\tVariable\tInfo_Archivo\tInfo_BD\n", true);
				DataBaseUtils.getDefaultConnection();
				while ((data = buffReader.readLine()) != null) {
					this.linea++;
					if (data.endsWith("|")) {
						data = data + " |";
					}
					test = true;
					if (data.split("\\|").length == 144) {
						//archivo plano set
						Fase3ResultadoArchivoPlano.setDatosArchivoPlano(data);
						consultarBD(Fase3ResultadoArchivoPlano.getSECUENCIA_TERCERO());
						idTerceroL = Fase3ResultadoArchivoPlano.getSECUENCIA_TERCERO();
						
							if (queriesResult1.get(0).size() != 0) {
										//query set
								Fase3ResultadoBD.setDatosBD(queriesResult1.get(0).get(0));
								
								if (!Fase3ResultadoArchivoPlano.getSECUENCIA_TERCERO().equals(Fase3ResultadoBD.getSECUENCIA_TERCERO())) {
									reportarError(Fase3ResultadoArchivoPlano.getSECUENCIA_TERCERO(), Fase3ResultadoBD.getSECUENCIA_TERCERO(), cabecero[0]);}
								
								//Fechas
								
								
								
									
										if (!Fase3ResultadoArchivoPlano.getFECHA_CALIFICACION()
												.equals(Fase3ResultadoBD.getFECHA_CALIFICACION())) {
											
											reportarError(Fase3ResultadoArchivoPlano.getFECHA_CALIFICACION(), 
													Fase3ResultadoBD.getFECHA_CALIFICACION(), cabecero[1]);
											}

									
							
									
										if (!Fase3ResultadoArchivoPlano.getFECHA_CORTE_INFO()
												.equals(Fase3ResultadoBD.getFECHA_CORTE_INFO())) {
										
											reportarError(Fase3ResultadoArchivoPlano.getFECHA_CORTE_INFO(), 
													Fase3ResultadoBD.getFECHA_CORTE_INFO(), cabecero[2]);
											}

									
							
								if (!Fase3ResultadoArchivoPlano.getAT34A().equals(Fase3ResultadoBD.getAT34A())) {
									reportarError(Fase3ResultadoArchivoPlano.getAT34A(), Fase3ResultadoBD.getAT34A(), cabecero[3]);}
								if (!Fase3ResultadoArchivoPlano.getBI34S().equals(Fase3ResultadoBD.getBI34S())) {
									reportarError(Fase3ResultadoArchivoPlano.getBI34S(), Fase3ResultadoBD.getBI34S(), cabecero[4]);}
								if (!Fase3ResultadoArchivoPlano.getBR27S().equals(Fase3ResultadoBD.getBR27S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getBR27S(), Fase3ResultadoBD.getBR27S(), cabecero[5]);}
								if (!Fase3ResultadoArchivoPlano.getBR29S().equals(Fase3ResultadoBD.getBR29S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getBR29S(), Fase3ResultadoBD.getBR29S(), cabecero[6]);}
								if (!Fase3ResultadoArchivoPlano.getBR34S().equals(Fase3ResultadoBD.getBR34S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getBR34S(), Fase3ResultadoBD.getBR34S(), cabecero[7]);}
								if (!Fase3ResultadoArchivoPlano.getBU09S().equals(Fase3ResultadoBD.getBU09S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getBU09S(), Fase3ResultadoBD.getBU09S(), cabecero[8]);}
								if (!Fase3ResultadoArchivoPlano.getCA09S().equals(Fase3ResultadoBD.getCA09S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getCA09S(), Fase3ResultadoBD.getCA09S(), cabecero[9]);}
								if (!Fase3ResultadoArchivoPlano.getCA70S().equals(Fase3ResultadoBD.getCA70S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getCA70S(), Fase3ResultadoBD.getCA70S(), cabecero[10]);}
								if (!Fase3ResultadoArchivoPlano.getCO04SF().equals(Fase3ResultadoBD.getCO04SF())) { 
									reportarError(Fase3ResultadoArchivoPlano.getCO04SF(), Fase3ResultadoBD.getCO04SF(), cabecero[11]);}
								if (!Fase3ResultadoArchivoPlano.getCT24S().equals(Fase3ResultadoBD.getCT24S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getCT24S(), Fase3ResultadoBD.getCT24S(), cabecero[12]);}
								if (!Fase3ResultadoArchivoPlano.getCT30S().equals(Fase3ResultadoBD.getCT30S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getCT30S(), Fase3ResultadoBD.getCT30S(), cabecero[13]);}
								if (!Fase3ResultadoArchivoPlano.getCT31S().equals(Fase3ResultadoBD.getCT31S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getCT31S(), Fase3ResultadoBD.getCT31S(), cabecero[14]);}
								if (!Fase3ResultadoArchivoPlano.getDM211S().equals(Fase3ResultadoBD.getDM211S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getDM211S(), Fase3ResultadoBD.getDM211S(), cabecero[15]);}
								if (!Fase3ResultadoArchivoPlano.getDM214S().equals(Fase3ResultadoBD.getDM214S())) {
									reportarError(Fase3ResultadoArchivoPlano.getDM214S(), Fase3ResultadoBD.getDM214S(), cabecero[16]);}
								if (!Fase3ResultadoArchivoPlano.getFR29S().equals(Fase3ResultadoBD.getFR29S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getFR29S(), Fase3ResultadoBD.getFR29S(), cabecero[17]);}
								if (!Fase3ResultadoArchivoPlano.getFR34S().equals(Fase3ResultadoBD.getFR34S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getFR34S(), Fase3ResultadoBD.getFR34S(), cabecero[18]);}
								if (!Fase3ResultadoArchivoPlano.getFS20S().equals(Fase3ResultadoBD.getFS20S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getFS20S(), Fase3ResultadoBD.getFS20S(), cabecero[19]);}
								if (!Fase3ResultadoArchivoPlano.getG212SF().equals(Fase3ResultadoBD.getG212SF())) { 
									reportarError(Fase3ResultadoArchivoPlano.getG212SF(), Fase3ResultadoBD.getG212SF(), cabecero[20]);}
								if (!Fase3ResultadoArchivoPlano.getG218BF().equals(Fase3ResultadoBD.getG218BF())) { 
									reportarError(Fase3ResultadoArchivoPlano.getG218BF(), Fase3ResultadoBD.getG218BF(), cabecero[21]);}
								if (!Fase3ResultadoArchivoPlano.getG220A().equals(Fase3ResultadoBD.getG220A())) { 
									reportarError(Fase3ResultadoArchivoPlano.getG220A(), Fase3ResultadoBD.getG220A(), cabecero[22]);}
								if (!Fase3ResultadoArchivoPlano.getG221D().equals(Fase3ResultadoBD.getG221D())) { 
									reportarError(Fase3ResultadoArchivoPlano.getG221D(), Fase3ResultadoBD.getG221D(), cabecero[23]);}
								if (!Fase3ResultadoArchivoPlano.getG306S().equals(Fase3ResultadoBD.getG306S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getG306S(), Fase3ResultadoBD.getG306S(), cabecero[24]);}
								if (!Fase3ResultadoArchivoPlano.getG410S().equals(Fase3ResultadoBD.getG410S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getG410S(), Fase3ResultadoBD.getG410S(), cabecero[25]);}
								if (!Fase3ResultadoArchivoPlano.getIN01S().equals(Fase3ResultadoBD.getIN01S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getIN01S(), Fase3ResultadoBD.getIN01S(), cabecero[26]);}
								if (!Fase3ResultadoArchivoPlano.getIN34S().equals(Fase3ResultadoBD.getIN34S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getIN34S(), Fase3ResultadoBD.getIN34S(), cabecero[27]);}
								if (!Fase3ResultadoArchivoPlano.getLL09S().equals(Fase3ResultadoBD.getLL09S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getLL09S(), Fase3ResultadoBD.getLL09S(), cabecero[28]);}
								if (!Fase3ResultadoArchivoPlano.getLL30S().equals(Fase3ResultadoBD.getLL30S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getLL30S(), Fase3ResultadoBD.getLL30S(), cabecero[29]);}
								if (!Fase3ResultadoArchivoPlano.getLMD30S().equals(Fase3ResultadoBD.getLMD30S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getLMD30S(), Fase3ResultadoBD.getLMD30S(), cabecero[30]);}
								if (!Fase3ResultadoArchivoPlano.getLS29S().equals(Fase3ResultadoBD.getLS29S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getLS29S(), Fase3ResultadoBD.getLS29S(), cabecero[31]);}
								if (!Fase3ResultadoArchivoPlano.getLS30S().equals(Fase3ResultadoBD.getLS30S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getLS30S(), Fase3ResultadoBD.getLS30S(), cabecero[32]);}
								if (!Fase3ResultadoArchivoPlano.getLS34S().equals(Fase3ResultadoBD.getLS34S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getLS34S(), Fase3ResultadoBD.getLS34S(), cabecero[33]);}
								if (!Fase3ResultadoArchivoPlano.getOD34S().equals(Fase3ResultadoBD.getOD34S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getOD34S(), Fase3ResultadoBD.getOD34S(), cabecero[34]);}
								if (!Fase3ResultadoArchivoPlano.getOF06S().equals(Fase3ResultadoBD.getOF06S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getOF06S(), Fase3ResultadoBD.getOF06S(), cabecero[35]);}
								if (!Fase3ResultadoArchivoPlano.getOF09S().equals(Fase3ResultadoBD.getOF09S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getOF09S(), Fase3ResultadoBD.getOF09S(), cabecero[36]);}
								if (!Fase3ResultadoArchivoPlano.getPT09S().equals(Fase3ResultadoBD.getPT09S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getPT09S(), Fase3ResultadoBD.getPT09S(), cabecero[37]);}
								if (!Fase3ResultadoArchivoPlano.getPT30S().equals(Fase3ResultadoBD.getPT30S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getPT30S(), Fase3ResultadoBD.getPT30S(), cabecero[38]);}
								if (!Fase3ResultadoArchivoPlano.getRI06S().equals(Fase3ResultadoBD.getRI06S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getRI06S(), Fase3ResultadoBD.getRI06S(), cabecero[39]);}
								if (!Fase3ResultadoArchivoPlano.getRR21S().equals(Fase3ResultadoBD.getRR21S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getRR21S(), Fase3ResultadoBD.getRR21S(), cabecero[40]);}
								if (!Fase3ResultadoArchivoPlano.getRR24S().equals(Fase3ResultadoBD.getRR24S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getRR24S(), Fase3ResultadoBD.getRR24S(), cabecero[41]);}
								if (!Fase3ResultadoArchivoPlano.getRR25S().equals(Fase3ResultadoBD.getRR25S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getRR25S(), Fase3ResultadoBD.getRR25S(), cabecero[42]);}
								if (!Fase3ResultadoArchivoPlano.getRT21S().equals(Fase3ResultadoBD.getRT21S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getRT21S(), Fase3ResultadoBD.getRT21S(), cabecero[43]);}
								if (!Fase3ResultadoArchivoPlano.getRT24S().equals(Fase3ResultadoBD.getRT24S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getRT24S(), Fase3ResultadoBD.getRT24S(), cabecero[44]);}
								if (!Fase3ResultadoArchivoPlano.getSE09S().equals(Fase3ResultadoBD.getSE09S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getSE09S(), Fase3ResultadoBD.getSE09S(), cabecero[45]);}
								if (!Fase3ResultadoArchivoPlano.getTEL09S().equals(Fase3ResultadoBD.getTEL09S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getTEL09S(), Fase3ResultadoBD.getTEL09S(), cabecero[46]);}
								if (!Fase3ResultadoArchivoPlano.getTEL21S().equals(Fase3ResultadoBD.getTEL21S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getTEL21S(), Fase3ResultadoBD.getTEL21S(), cabecero[47]);}
								if (!Fase3ResultadoArchivoPlano.getTEL30S().equals(Fase3ResultadoBD.getTEL30S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getTEL30S(), Fase3ResultadoBD.getTEL30S(), cabecero[48]);}
								if (!Fase3ResultadoArchivoPlano.getUL29S().equals(Fase3ResultadoBD.getUL29S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getUL29S(), Fase3ResultadoBD.getUL29S(), cabecero[49]);}
								if (!Fase3ResultadoArchivoPlano.getUL34S().equals(Fase3ResultadoBD.getUL34S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getUL34S(), Fase3ResultadoBD.getUL34S(), cabecero[50]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2402().equals(Fase3ResultadoBD.getAGG2402())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2402(), Fase3ResultadoBD.getAGG2402(), cabecero[51]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2403().equals(Fase3ResultadoBD.getAGG2403())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2403(), Fase3ResultadoBD.getAGG2403(), cabecero[52]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2404().equals(Fase3ResultadoBD.getAGG2404())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2404(), Fase3ResultadoBD.getAGG2404(), cabecero[53]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2405().equals(Fase3ResultadoBD.getAGG2405())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2405(), Fase3ResultadoBD.getAGG2405(), cabecero[54]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2406().equals(Fase3ResultadoBD.getAGG2406())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2406(), Fase3ResultadoBD.getAGG2406(), cabecero[55]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2407().equals(Fase3ResultadoBD.getAGG2407())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2407(), Fase3ResultadoBD.getAGG2407(), cabecero[56]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2408().equals(Fase3ResultadoBD.getAGG2408())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2408(), Fase3ResultadoBD.getAGG2408(), cabecero[57]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2409().equals(Fase3ResultadoBD.getAGG2409())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2409(), Fase3ResultadoBD.getAGG2409(), cabecero[58]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2410().equals(Fase3ResultadoBD.getAGG2410())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2410(), Fase3ResultadoBD.getAGG2410(), cabecero[59]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2411().equals(Fase3ResultadoBD.getAGG2411())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2411(), Fase3ResultadoBD.getAGG2411(), cabecero[60]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2412().equals(Fase3ResultadoBD.getAGG2412())) {
									reportarError(Fase3ResultadoArchivoPlano.getAGG2412(), Fase3ResultadoBD.getAGG2412(), cabecero[61]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2413().equals(Fase3ResultadoBD.getAGG2413())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2413(), Fase3ResultadoBD.getAGG2413(), cabecero[62]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2414().equals(Fase3ResultadoBD.getAGG2414())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2414(), Fase3ResultadoBD.getAGG2414(), cabecero[63]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2415().equals(Fase3ResultadoBD.getAGG2415())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2415(), Fase3ResultadoBD.getAGG2415(), cabecero[64]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2416().equals(Fase3ResultadoBD.getAGG2416())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2416(), Fase3ResultadoBD.getAGG2416(), cabecero[65]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2417().equals(Fase3ResultadoBD.getAGG2417())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2417(), Fase3ResultadoBD.getAGG2417(), cabecero[66]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2418().equals(Fase3ResultadoBD.getAGG2418())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2418(), Fase3ResultadoBD.getAGG2418(), cabecero[67]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2419().equals(Fase3ResultadoBD.getAGG2419())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2419(), Fase3ResultadoBD.getAGG2419(), cabecero[68]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2420().equals(Fase3ResultadoBD.getAGG2420())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2420(), Fase3ResultadoBD.getAGG2420(), cabecero[69]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2421().equals(Fase3ResultadoBD.getAGG2421())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2421(), Fase3ResultadoBD.getAGG2421(), cabecero[70]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2422().equals(Fase3ResultadoBD.getAGG2422())) {
									reportarError(Fase3ResultadoArchivoPlano.getAGG2422(), Fase3ResultadoBD.getAGG2422(), cabecero[71]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2423().equals(Fase3ResultadoBD.getAGG2423())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2423(), Fase3ResultadoBD.getAGG2423(), cabecero[72]);}
								if (!Fase3ResultadoArchivoPlano.getAGG2424().equals(Fase3ResultadoBD.getAGG2424())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG2424(), Fase3ResultadoBD.getAGG2424(), cabecero[73]);}
								if (!Fase3ResultadoArchivoPlano.getAGG301().equals(Fase3ResultadoBD.getAGG301())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG301(), Fase3ResultadoBD.getAGG301(), cabecero[74]);}
								if (!Fase3ResultadoArchivoPlano.getAGG302().equals(Fase3ResultadoBD.getAGG302())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG302(), Fase3ResultadoBD.getAGG302(), cabecero[75]);}
								if (!Fase3ResultadoArchivoPlano.getAGG303().equals(Fase3ResultadoBD.getAGG303())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG303(), Fase3ResultadoBD.getAGG303(), cabecero[76]);}
								if (!Fase3ResultadoArchivoPlano.getAGG304().equals(Fase3ResultadoBD.getAGG304())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG304(), Fase3ResultadoBD.getAGG304(), cabecero[77]);}
								if (!Fase3ResultadoArchivoPlano.getAGG305().equals(Fase3ResultadoBD.getAGG305())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG305(), Fase3ResultadoBD.getAGG305(), cabecero[78]);}
								if (!Fase3ResultadoArchivoPlano.getAGG306().equals(Fase3ResultadoBD.getAGG306())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG306(), Fase3ResultadoBD.getAGG306(), cabecero[79]);}
								if (!Fase3ResultadoArchivoPlano.getAGG307().equals(Fase3ResultadoBD.getAGG307())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG307(), Fase3ResultadoBD.getAGG307(), cabecero[80]);}
								if (!Fase3ResultadoArchivoPlano.getAGG308().equals(Fase3ResultadoBD.getAGG308())) {
									reportarError(Fase3ResultadoArchivoPlano.getAGG308(), Fase3ResultadoBD.getAGG308(), cabecero[81]);}
								if (!Fase3ResultadoArchivoPlano.getAGG309().equals(Fase3ResultadoBD.getAGG309())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG309(), Fase3ResultadoBD.getAGG309(), cabecero[82]);}
								if (!Fase3ResultadoArchivoPlano.getAGG310().equals(Fase3ResultadoBD.getAGG310())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG310(), Fase3ResultadoBD.getAGG310(), cabecero[83]);}
								if (!Fase3ResultadoArchivoPlano.getAGG311().equals(Fase3ResultadoBD.getAGG311())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG311(), Fase3ResultadoBD.getAGG311(), cabecero[84]);}
								if (!Fase3ResultadoArchivoPlano.getAGG312().equals(Fase3ResultadoBD.getAGG312())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG312(), Fase3ResultadoBD.getAGG312(), cabecero[85]);}
								if (!Fase3ResultadoArchivoPlano.getAGG313().equals(Fase3ResultadoBD.getAGG313())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG313(), Fase3ResultadoBD.getAGG313(), cabecero[86]);}
								if (!Fase3ResultadoArchivoPlano.getAGG314().equals(Fase3ResultadoBD.getAGG314())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG314(), Fase3ResultadoBD.getAGG314(), cabecero[87]);}
								if (!Fase3ResultadoArchivoPlano.getAGG315().equals(Fase3ResultadoBD.getAGG315())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG315(), Fase3ResultadoBD.getAGG315(), cabecero[88]);}
								if (!Fase3ResultadoArchivoPlano.getAGG316().equals(Fase3ResultadoBD.getAGG316())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG316(), Fase3ResultadoBD.getAGG316(), cabecero[89]);}
								if (!Fase3ResultadoArchivoPlano.getAGG317().equals(Fase3ResultadoBD.getAGG317())) {
									reportarError(Fase3ResultadoArchivoPlano.getAGG317(), Fase3ResultadoBD.getAGG317(), cabecero[90]);}
								if (!Fase3ResultadoArchivoPlano.getAGG318().equals(Fase3ResultadoBD.getAGG318())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG318(), Fase3ResultadoBD.getAGG318(), cabecero[91]);}
								if (!Fase3ResultadoArchivoPlano.getAGG319().equals(Fase3ResultadoBD.getAGG319())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG319(), Fase3ResultadoBD.getAGG319(), cabecero[92]);}
								if (!Fase3ResultadoArchivoPlano.getAGG320().equals(Fase3ResultadoBD.getAGG320())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG320(), Fase3ResultadoBD.getAGG320(), cabecero[93]);}
								if (!Fase3ResultadoArchivoPlano.getAGG321().equals(Fase3ResultadoBD.getAGG321())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG321(), Fase3ResultadoBD.getAGG321(), cabecero[94]);}
								if (!Fase3ResultadoArchivoPlano.getAGG322().equals(Fase3ResultadoBD.getAGG322())) {
									reportarError(Fase3ResultadoArchivoPlano.getAGG322(), Fase3ResultadoBD.getAGG322(), cabecero[95]);}
								if (!Fase3ResultadoArchivoPlano.getAGG323().equals(Fase3ResultadoBD.getAGG323())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG323(), Fase3ResultadoBD.getAGG323(), cabecero[96]);}
								if (!Fase3ResultadoArchivoPlano.getAGG324().equals(Fase3ResultadoBD.getAGG324())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG324(), Fase3ResultadoBD.getAGG324(), cabecero[97]);}
								if (!Fase3ResultadoArchivoPlano.getBKC112().equals(Fase3ResultadoBD.getBKC112())) { 
									reportarError(Fase3ResultadoArchivoPlano.getBKC112(), Fase3ResultadoBD.getBKC112(), cabecero[98]);}
								//*	Prueba
								
								
								if (!Fase3ResultadoArchivoPlano.getAGG905().equals(Fase3ResultadoBD.getAGG905())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG905(), Fase3ResultadoBD.getAGG905(), cabecero[99]);}
							
								
							
								
								if (!Fase3ResultadoArchivoPlano.getAGG906().equals(Fase3ResultadoBD.getAGG906())) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG906(), Fase3ResultadoBD.getAGG906(), cabecero[100]);}
							
							
								
								
								
								
								//*	Prueba
								if(Fase3ResultadoArchivoPlano.getBKC225().contains(".")){
								
								if (!Fase3ResultadoArchivoPlano.getBKC225().equals(Fase3ResultadoBD.getBKC225())) { 
									reportarError(Fase3ResultadoArchivoPlano.getBKC225(), Fase3ResultadoBD.getBKC225(), cabecero[101]);}
								}
								else {
									String varBKC225 = Fase3ResultadoBD.getBKC225().substring(0,2).replace(".", "");
									if (!Fase3ResultadoArchivoPlano.getBKC225().equals(varBKC225)) { 
										reportarError(Fase3ResultadoArchivoPlano.getBKC225(), varBKC225, cabecero[101]);}
								}
								
								
								//* fin prueba
								
								
								if (!Fase3ResultadoArchivoPlano.getPAYMNT50().equals(Fase3ResultadoBD.getPAYMNT50())) { 
									reportarError(Fase3ResultadoArchivoPlano.getPAYMNT50(), Fase3ResultadoBD.getPAYMNT50(), cabecero[102]);}
								if (!Fase3ResultadoArchivoPlano.getPAYMNT65().equals(Fase3ResultadoBD.getPAYMNT65())) {
									reportarError(Fase3ResultadoArchivoPlano.getPAYMNT65(), Fase3ResultadoBD.getPAYMNT65(), cabecero[103]);}
								if (!Fase3ResultadoArchivoPlano.getPER201().equals(Fase3ResultadoBD.getPER201())) { 
									reportarError(Fase3ResultadoArchivoPlano.getPER201(), Fase3ResultadoBD.getPER201(), cabecero[104]);}
								
								//Prueba
								
								if (Fase3ResultadoArchivoPlano.getPER223().contains(".")){
								if (!Fase3ResultadoArchivoPlano.getPER223().equals(Fase3ResultadoBD.getPER223())) { 
									reportarError(Fase3ResultadoArchivoPlano.getPER223(), Fase3ResultadoBD.getPER223(), cabecero[105]);}
								}
								else {
									String VarPER223 = Fase3ResultadoBD.getPER223().substring(0,2).replace(".", "");
									if (!Fase3ResultadoArchivoPlano.getPER223().equals(VarPER223)) { 
										reportarError(Fase3ResultadoArchivoPlano.getPER223(), VarPER223, cabecero[105]);}	
								}
								//Fin prueba
								
								
								if (!Fase3ResultadoArchivoPlano.getPER233().equals(Fase3ResultadoBD.getPER233())) { 
									reportarError(Fase3ResultadoArchivoPlano.getPER233(), Fase3ResultadoBD.getPER233(), cabecero[106]);}
								if (!Fase3ResultadoArchivoPlano.getRET13().equals(Fase3ResultadoBD.getRET13())) {
									reportarError(Fase3ResultadoArchivoPlano.getRET13(), Fase3ResultadoBD.getRET13(), cabecero[107]);}
								if (!Fase3ResultadoArchivoPlano.getRET152().equals(Fase3ResultadoBD.getRET152())) { 
									reportarError(Fase3ResultadoArchivoPlano.getRET152(), Fase3ResultadoBD.getRET152(), cabecero[108]);}
								if (!Fase3ResultadoArchivoPlano.getRET201().equals(Fase3ResultadoBD.getRET201())) {
									reportarError(Fase3ResultadoArchivoPlano.getRET201(), Fase3ResultadoBD.getRET201(), cabecero[109]);}
								if (!Fase3ResultadoArchivoPlano.getRET81().equals(Fase3ResultadoBD.getRET81())) { 
									reportarError(Fase3ResultadoArchivoPlano.getRET81(), Fase3ResultadoBD.getRET81(), cabecero[110]);}
								if (!Fase3ResultadoArchivoPlano.getREV14().equals(Fase3ResultadoBD.getREV14())) { 
									reportarError(Fase3ResultadoArchivoPlano.getREV14(), Fase3ResultadoBD.getREV14(), cabecero[111]);}
								if (!Fase3ResultadoArchivoPlano.getREV253().equals(Fase3ResultadoBD.getREV253())) {
									reportarError(Fase3ResultadoArchivoPlano.getREV253(), Fase3ResultadoBD.getREV253(), cabecero[112]);}
								if (!Fase3ResultadoArchivoPlano.getRLE907().equals(Fase3ResultadoBD.getRLE907())) { 
									reportarError(Fase3ResultadoArchivoPlano.getRLE907(), Fase3ResultadoBD.getRLE907(), cabecero[113]);}
								if (!Fase3ResultadoArchivoPlano.getRVLR09().equals(Fase3ResultadoBD.getRVLR09())) { 
									reportarError(Fase3ResultadoArchivoPlano.getRVLR09(), Fase3ResultadoBD.getRVLR09(), cabecero[114]);}
								if (!Fase3ResultadoArchivoPlano.getTRD().equals(Fase3ResultadoBD.getTRD())) { 
									reportarError(Fase3ResultadoArchivoPlano.getTRD(), Fase3ResultadoBD.getTRD(), cabecero[115]);}
								if (!Fase3ResultadoArchivoPlano.getTRV03().equals(Fase3ResultadoBD.getTRV03())) {
									reportarError(Fase3ResultadoArchivoPlano.getTRV03(), Fase3ResultadoBD.getTRV03(), cabecero[116]);}
								if (!Fase3ResultadoArchivoPlano.getTRV12().equals(Fase3ResultadoBD.getTRV12())) { 
									reportarError(Fase3ResultadoArchivoPlano.getTRV12(), Fase3ResultadoBD.getTRV12(), cabecero[117]);}
								if (!Fase3ResultadoArchivoPlano.getUL_TRD().equals(Fase3ResultadoBD.getUL_TRD())) { 
									reportarError(Fase3ResultadoArchivoPlano.getUL_TRD(), Fase3ResultadoBD.getUL_TRD(), cabecero[118]);}
								
								//Prueba
								if (Fase3ResultadoArchivoPlano.getWD21().contains(".")) {
								
								if (!Fase3ResultadoArchivoPlano.getWD21().equals(Fase3ResultadoBD.getWD21())) {
									reportarError(Fase3ResultadoArchivoPlano.getWD21(), Fase3ResultadoBD.getWD21(), cabecero[119]);}
								
								}
								else {
									String varWD21= Fase3ResultadoBD.getWD21().substring(0,2).replace(".", "");
									if (!Fase3ResultadoArchivoPlano.getWD21().equals(varWD21)) {
										reportarError(Fase3ResultadoArchivoPlano.getWD21(), varWD21, cabecero[119]);}
								}
								
								if(Fase3ResultadoArchivoPlano.getWD31().contains(".")) {
								if (!Fase3ResultadoArchivoPlano.getWD31().equals(Fase3ResultadoBD.getWD31())) { 
									reportarError(Fase3ResultadoArchivoPlano.getWD31(), Fase3ResultadoBD.getWD31(), cabecero[120]);}
								
								}
								else {
									String varWD31= Fase3ResultadoBD.getWD31().substring(0,2).replace(".", "");
									if (!Fase3ResultadoArchivoPlano.getWD31().equals(varWD31)) { 
										reportarError(Fase3ResultadoArchivoPlano.getWD31(), varWD31, cabecero[120]);}
									
								}
								if(Fase3ResultadoArchivoPlano.getWD51().contains(".")) {
								if (!Fase3ResultadoArchivoPlano.getWD51().equals(Fase3ResultadoBD.getWD51())) { 
									reportarError(Fase3ResultadoArchivoPlano.getWD51(), Fase3ResultadoBD.getWD51(), cabecero[121]);}
								}
								else {
									String varWD51=Fase3ResultadoBD.getWD51().substring(0,2).replace(".", "");
									
									if (!Fase3ResultadoArchivoPlano.getWD51().equals(varWD51)) { 
										reportarError(Fase3ResultadoArchivoPlano.getWD51(), varWD51, cabecero[121]);}
								}
								
								if(Fase3ResultadoArchivoPlano.getWD61().contains(".")) {
								if (!Fase3ResultadoArchivoPlano.getWD61().equals(Fase3ResultadoBD.getWD61())) { 
									reportarError(Fase3ResultadoArchivoPlano.getWD61(), Fase3ResultadoBD.getWD61(), cabecero[122]);}
								
								}
								else {
									String varWD61 = Fase3ResultadoBD.getWD61().substring(0,2).replace(".", "");
									if (!Fase3ResultadoArchivoPlano.getWD61().equals(varWD61)) { 
										reportarError(Fase3ResultadoArchivoPlano.getWD61(), varWD61, cabecero[122]);}
									
								}
								if(Fase3ResultadoArchivoPlano.getWD81().contains(".")) {
								if (!Fase3ResultadoArchivoPlano.getWD81().equals(Fase3ResultadoBD.getWD81())) { 
									reportarError(Fase3ResultadoArchivoPlano.getWD81(), Fase3ResultadoBD.getWD81(), cabecero[123]);}
								
								}
								else {
									 String varWD81= Fase3ResultadoBD.getWD81().substring(0,2).replace(".", "");
									if (!Fase3ResultadoArchivoPlano.getWD81().equals(varWD81)) { 
										reportarError(Fase3ResultadoArchivoPlano.getWD81(), varWD81, cabecero[123]);}
									
								}
								
								//Fin prueba
								
								
								if (!Fase3ResultadoArchivoPlano.getRET225().equals(Fase3ResultadoBD.getRET225())) { 
									reportarError(Fase3ResultadoArchivoPlano.getRET225(), Fase3ResultadoBD.getRET225(), cabecero[124]);}
								if (!Fase3ResultadoArchivoPlano.getBR20S().equals(Fase3ResultadoBD.getBR20S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getBR20S(), Fase3ResultadoBD.getBR20S(), cabecero[125]);}
								if (!Fase3ResultadoArchivoPlano.getFU21S().equals(Fase3ResultadoBD.getFU21S())) {
									reportarError(Fase3ResultadoArchivoPlano.getFU21S(), Fase3ResultadoBD.getFU21S(), cabecero[126]);}
								if (!Fase3ResultadoArchivoPlano.getUS25S().equals(Fase3ResultadoBD.getUS25S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getUS25S(), Fase3ResultadoBD.getUS25S(), cabecero[127]);}
								if (!Fase3ResultadoArchivoPlano.getMF31S().equals(Fase3ResultadoBD.getMF31S())) { 
									reportarError(Fase3ResultadoArchivoPlano.getMF31S(), Fase3ResultadoBD.getMF31S(), cabecero[128]);}
								if (!Fase3ResultadoArchivoPlano.getTRV18().equals(Fase3ResultadoBD.getTRV18())) { 
									reportarError(Fase3ResultadoArchivoPlano.getTRV18(), Fase3ResultadoBD.getTRV18(), cabecero[129]);}
								if (!Fase3ResultadoArchivoPlano.getPOSITIVE_SF().equals(Fase3ResultadoBD.getPOSITIVE_SF())) { 
									reportarError(Fase3ResultadoArchivoPlano.getPOSITIVE_SF(), Fase3ResultadoBD.getPOSITIVE_SF(), cabecero[130]);}
								if (!Fase3ResultadoArchivoPlano.getNEGATIVE_SF().equals(Fase3ResultadoBD.getNEGATIVE_SF())) {
									reportarError(Fase3ResultadoArchivoPlano.getNEGATIVE_SF(), Fase3ResultadoBD.getNEGATIVE_SF(), cabecero[131]);}
								if (!Fase3ResultadoArchivoPlano.getSEGMENT_SF().equals(Fase3ResultadoBD.getSEGMENT_SF())) {
									reportarError(Fase3ResultadoArchivoPlano.getSEGMENT_SF(), Fase3ResultadoBD.getSEGMENT_SF(), cabecero[132]);}
								
								//Prueba
								
								if(Fase3ResultadoArchivoPlano.getTELCO_SF().contains(".")) {
								if (!Fase3ResultadoArchivoPlano.getTELCO_SF().equals(Fase3ResultadoBD.getTELCO_SF())) {
									reportarError(Fase3ResultadoArchivoPlano.getTELCO_SF(), Fase3ResultadoBD.getTELCO_SF(), cabecero[133]);}
								
								}
								else {
									String varTELCO_SF = Fase3ResultadoBD.getTELCO_SF().substring(0,2).replace(".", "");
									if (!Fase3ResultadoArchivoPlano.getTELCO_SF().equals(varTELCO_SF)) {
										reportarError(Fase3ResultadoArchivoPlano.getTELCO_SF(), varTELCO_SF, cabecero[133]);}
								}
								//*
								if(Fase3ResultadoArchivoPlano.getWGT_SCR_SF().contains(".")) {
									
								if (!Fase3ResultadoArchivoPlano.getWGT_SCR_SF().equals(Fase3ResultadoBD.getWGT_SCR_SF().replace(",", "."))) {
									reportarError(Fase3ResultadoArchivoPlano.getWGT_SCR_SF(), Fase3ResultadoBD.getWGT_SCR_SF().replace(",", "."), cabecero[134]);}
								}
								else {
									String varWGT_SCR_SF = Fase3ResultadoBD.getWGT_SCR_SF().substring(0,2).replace(".", "").replace(",", "");
									if (!Fase3ResultadoArchivoPlano.getWGT_SCR_SF().equals(varWGT_SCR_SF)) {
										reportarError(Fase3ResultadoArchivoPlano.getWGT_SCR_SF(), varWGT_SCR_SF, cabecero[134]);}
									
								}
								
								if(Fase3ResultadoArchivoPlano.getAGG_SCR_SF().contains(".")) {
								
								if (!Fase3ResultadoArchivoPlano.getAGG_SCR_SF().equals(Fase3ResultadoBD.getAGG_SCR_SF().replace(",", "."))) { 
									reportarError(Fase3ResultadoArchivoPlano.getAGG_SCR_SF(), Fase3ResultadoBD.getAGG_SCR_SF().replace(",", "."), cabecero[135]);}
								}
								else {
									String varAGG_SCR_SF = Fase3ResultadoBD.getAGG_SCR_SF().substring(0,2).replace(".", "").replace(",", "");
									if (!Fase3ResultadoArchivoPlano.getAGG_SCR_SF().equals(varAGG_SCR_SF)) { 
										reportarError(Fase3ResultadoArchivoPlano.getAGG_SCR_SF(), varAGG_SCR_SF, cabecero[135]);}
								}
								
								if (!Fase3ResultadoArchivoPlano.getPOSITIVE_SR().equals(Fase3ResultadoBD.getPOSITIVE_SR())) {
									reportarError(Fase3ResultadoArchivoPlano.getPOSITIVE_SR(), Fase3ResultadoBD.getPOSITIVE_SR(), cabecero[136]);}
								if (!Fase3ResultadoArchivoPlano.getNEGATIVE_SR().equals(Fase3ResultadoBD.getNEGATIVE_SR())) { 
									reportarError(Fase3ResultadoArchivoPlano.getNEGATIVE_SR(), Fase3ResultadoBD.getNEGATIVE_SR(), cabecero[137]);}
								if (!Fase3ResultadoArchivoPlano.getSEGMENT_SR().equals(Fase3ResultadoBD.getSEGMENT_SR())) { 
									reportarError(Fase3ResultadoArchivoPlano.getSEGMENT_SR(), Fase3ResultadoBD.getSEGMENT_SR(), cabecero[138]);}
								
								if(Fase3ResultadoArchivoPlano.getWGT_SCR_SR().contains(".")) {
								if (!Fase3ResultadoArchivoPlano.getWGT_SCR_SR().equals(Fase3ResultadoBD.getWGT_SCR_SR())) {
									reportarError(Fase3ResultadoArchivoPlano.getWGT_SCR_SR(), Fase3ResultadoBD.getWGT_SCR_SR(), cabecero[139]);}
								}
								else {
									String varWGT_SCR_SR = Fase3ResultadoBD.getWGT_SCR_SR().substring(0,2).replace(".", "");
									if (!Fase3ResultadoArchivoPlano.getWGT_SCR_SR().equals(varWGT_SCR_SR)) {
										reportarError(Fase3ResultadoArchivoPlano.getWGT_SCR_SR(), varWGT_SCR_SR, cabecero[139]);}
								
								}
								
								if(Fase3ResultadoArchivoPlano.getAGG_SCR_SR().contains(".")) {
								if (!Fase3ResultadoArchivoPlano.getAGG_SCR_SR().equals(Fase3ResultadoBD.getAGG_SCR_SR())) {
									reportarError(Fase3ResultadoArchivoPlano.getAGG_SCR_SR(), Fase3ResultadoBD.getAGG_SCR_SR(), cabecero[140]);}
								}
								else {
									String varAGG_SCR_SR = Fase3ResultadoBD.getAGG_SCR_SR().substring(0,2).replaceAll(".", "");
									if (!Fase3ResultadoArchivoPlano.getAGG_SCR_SR().equals(varAGG_SCR_SR)) {
										reportarError(Fase3ResultadoArchivoPlano.getAGG_SCR_SR(), varAGG_SCR_SR, cabecero[140]);}
							
								}
								
								
								if (!Fase3ResultadoArchivoPlano.getCREDITVISION().equals(Fase3ResultadoBD.getCREDITVISION())) { 
									reportarError(Fase3ResultadoArchivoPlano.getCREDITVISION(), Fase3ResultadoBD.getCREDITVISION(), cabecero[141]);}
								if (!Fase3ResultadoArchivoPlano.getCREDITVISION_LINK_SERVICIOS_FIN().equals(Fase3ResultadoBD.getCV_LINK_SERVICIOS_FIN())) { 
									reportarError(Fase3ResultadoArchivoPlano.getCREDITVISION_LINK_SERVICIOS_FIN(), Fase3ResultadoBD.getCV_LINK_SERVICIOS_FIN(), cabecero[142]);}
								if (!Fase3ResultadoArchivoPlano.getCREDITVISION_LINK().equals(Fase3ResultadoBD.getCREDITVISION_LINK())) { 
									reportarError(Fase3ResultadoArchivoPlano.getCREDITVISION_LINK(), Fase3ResultadoBD.getCREDITVISION_LINK(), cabecero[143]);}


	
								if (!test) {
									logger.error("Se encontraron errores en la comparacion de datos "
											+ " Consecutivo  " + idTerceroL);
									softAssert.fail("Se encontraron errores en la comparacion de datos  "
											 + " Consecutivo " + idTerceroL);

								}

								else {
									System.out
											.println(linea + " Consecutivo " + idTerceroL);
								}

							} else {

								imprimirReporte("Test_Archivo_",
										"Error en linea--> " + linea + " Consecutivo--> "
												+ Fase1ResultadoArchivoPlano.getConsecutivo() 
											
												+ " No se genero informacion a la consulta en BD\n",
										true);

							}
						
					} else {
						imprimirReporte("Test_Archivo_", "Error! Numero de campos es diferente al establecido, en la linea--> "
								+ linea + " el archivo tiene --> " + data.split("\\|").length + "\n", true);

						softAssert.fail("Numero de campos es diferente al establecido, en la linea--> " + linea
								+ " el archivo tiene --> " + data.split("\\|").length + "\n");
					}
				}
				
				DataBaseUtils.closeConnection();
				imprimirReporte("Test_Archivo_", "Numero de registros analizados "+(linea)
						+	" errores encontrados "+ Errores+"\n", true);
				softAssert.assertAll();
				imprimirReporte("Test_Archivo_", "Prueba fue ejecutada sin errores, movimientos analizados--> " + (linea - 1),
						true);
			}
		 
		}	else {
			DataBaseUtils.closeConnection();
			softAssert.fail("Test de estructura no fue aprobado");
			softAssert.assertAll();
		}
	}

	private void reportarError(String ArchivoResultados, String ArchivoResultadosDb, String parametro) {
		

		String data = linea + "\t"
				+ Fase3ResultadoArchivoPlano.getSECUENCIA_TERCERO()
				+ "\t" + parametro + "\t" + ArchivoResultados.replace(".", ",") + "\t"+ ArchivoResultadosDb.replace(".", ",") + "\n";
		
		imprimirReporte("Test_Archivo_", data, true);
		//imprimirReporte("Test_Roland_", data, true);
	
		logger.error("Error en la linea--> " + linea 
				+ " IdTercero--> " + Fase1ResultadoArchivoPlano.getConsecutivo() + " Variable " + parametro + " File--> " + ArchivoResultados
				+ " DB--> " + ArchivoResultadosDb);
		test = false;
		Errores++;
	
	}

	private void imprimirReporte(String prueba, String data, Boolean escribir) {
		BufferedWriter bw = null;
		FileWriter fw = null;

		try {

			File file = new File(origenFile + prueba+fileName);
			// Si el archivo no existe, se crea!
			if (!file.exists()) {
				file.createNewFile();
			}
			// flag true, indica adjuntar información al archivo.
			fw = new FileWriter(file.getAbsoluteFile(), escribir);
			bw = new BufferedWriter(fw);
			bw.write(data);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				// Cierra instancias de FileWriter y BufferedWriter
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	private void consultarBD(String secuencia) throws Exception {
		listaQueries = ReadSqlFile.getQueriesFromFileByTagName("common.sql", "@FaseTresCuartosCvBatch" );
		queriesResult1 = executedQueries(listaQueries, secuencia );

	}

	private static List<List<List<String>>> executedQueries(List<String> listaQueries, String secuencia ) throws Exception {
		List<List<List<String>>> queriesResult = new ArrayList<List<List<String>>>();
		List<List<String>> dataFromQueriesList = null;
		int queriesNumbers = listaQueries.size();
		for (int iteration = 0; iteration < queriesNumbers; iteration++) {
			DataBaseUtils.getResultSet(listaQueries.get(iteration).replace("[Secuencia]", secuencia));
			dataFromQueriesList = DataBaseUtils.getDataFromResultset();
			queriesResult.add(dataFromQueriesList);

		}
		return queriesResult;
	}

}