package transUnion.Skyfall.JavaUtils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.assertj.core.api.SoftAssertions;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import transUnion.Skyfall.javaUtils.DataBaseUtils;
import transUnion.Skyfall.javaUtils.ReadSqlFile;
import transUnion.Skyfall.models.Fase1ResultadoArchivoPlano;
import transUnion.Skyfall.models.Fase1ResultadoBD;
import transUnion.Skyfall.models.Fase2ResultadoArchivoPlano;
import transUnion.Skyfall.models.Fase2ResultadoBD;




@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PruebaFase2TradesHDComparacion {
	String origenFile = "C:\\Users\\romarti\\Automatizacion\\SkyFall\\Archivos_Txt\\test_skyfall\\";
	String fileName = "shape_co_Fase1_trades_hd_2020-11-07.txt";
	SoftAssertions softAssert = new SoftAssertions();
	static Logger logger = Logger.getLogger(PruebaFase2TradesHDComparacion.class);
	static boolean testEstructura;
	static boolean test = true;
	static String[] cabecero = {"CONSECUTIVO","AGG1101","AGG1102","AGG1103","AGG1104","AGG1105","AGG1106","AGG1107","AGG1108",
			"AGG1109","AGG1110","AGG1111","AGG1112","AGG1113","AGG1114","AGG1115","AGG1116","AGG1117","AGG1118","AGG1119","AGG1120",
			"AGG1121","AGG1122","AGG1123","AGG1124","AGG2401","AGG2402","AGG2403","AGG2404","AGG2405","AGG2406","AGG2407","AGG2408",
			"AGG2409","AGG2410","AGG2411","AGG2412","AGG2413","AGG2414","AGG2415","AGG2416","AGG2417","AGG2418","AGG2419","AGG2420",
			"AGG2421","AGG2422","AGG2423","AGG2424","AGG301","AGG302","AGG303","AGG304","AGG305","AGG306","AGG307","AGG308","AGG309",
			"AGG310","AGG311","AGG312","AGG313","AGG314","AGG315","AGG316","AGG317","AGG318","AGG319","AGG320","AGG321","AGG322","AGG323",
			"AGG324","AGG701","AGG702","AGG703","AGG704","AGG705","AGG706","AGG707","AGG708","AGG709","AGG710","AGG711","AGG712","AGG713",
			"AGG714","AGG715","AGG716","AGG717","AGG718","AGG719","AGG720","AGG721","AGG722","AGG723","AGG724","AGG904","AGG905","AGG906",
			"AGG909","AGG910","AGG911","AT31S","AT34A","AU21S","BC01S","BC20S","BC21S","BI20S","BI21S","BI29S","BI32S","BI34S","BKC112",
			"BKC225","BKC231","BKC232","BKC233","BKC235","BKC252","BKC253","BKC254","BKC255","BR12S","BR20S","BR27S","BR29S","BR34S","BU09S",
			"BU21S","BU32S","CA09S","CA70S","CO04S","CO04SF","COLLECTION_TRD","CT20S","CT24S","CT30S","CT31S","CT32S","CV25","DM211S","DM214S",
			"FI20S","FI21S","FI34S","FMD21S","FR21S","FR29S","FR32S","FR34S","FS20S","FU20S","FU21S","FU32S","FU34S","G103S","G209SF","G211S",
			"G212SF","G218BF","G220A","G221D","G306S","G410S","G417S","G500S","G540S","G547S","G960S","IN01S","IN06S","IN09S","IN21S","IN25S",
			"IN27S","IN31S","IN34S","LL09S","LL21S","LL30S","LL34S","LMD21S","LMD30S","LMD32S","LMD34S","LS29S","LS30S","LS34S","MF20S","MF24S",
			"MF31S","MF32S","MT24S","MT33S","MT34B","MT34S","NON_FINANCIAL_TRD","OD34S","OF06S","OF09S","OF32S","OF34S","PAYMNT03","PAYMNT50",
			"PAYMNT65","PER201","PER222","PER223","PER224","PER233","PT09S","PT20S","PT21S","PT30S","PT34S","PUBLIC_SERVICE_TRD","RE102S","RE12S",
			"RE30S","RE32S","RET11","RET13","RET132","RET14","RET142","RET152","RET201","RET222","RET223","RET224","RET225","RET315","RET320","RET51",
			"RET81","RET84","REV14","REV202","REV203","REV204","REV222","REV223","REV225","REV253","REV320","REVBAL01","REVBAL02","REVBAL03","REVBAL04",
			"REVBAL05","REVBAL06","REVBAL07","REVBAL08","REVBAL09","REVBAL10","REVBAL11","REVBAL12","REVBAL13","REVBAL14","REVBAL15","REVBAL16","REVBAL17",
			"REVBAL18","REVBAL19","REVBAL20","REVBAL21","REVBAL22","REVBAL23","REVBAL24","RI06S","RI20S","RI21S","RI24S","RI27S","RI29S","RI30S","RI31S",
			"RI32S","RLE904","RLE905","RLE907","RR102S","RR201S","RR21S","RR24S","RR25S","RT06S","RT201S","RT21S","RT24S","RT31S","RVLR03","RVLR06","RVLR09",
			"S064D","S209D","SE09S","SE21S","SE34S","TEL09S","TEL21S","TEL30S","TEL31S","TEL32S","TRANBAL01","TRANBAL02","TRANBAL03","TRANBAL04","TRANBAL05",
			"TRANBAL06","TRANBAL07","TRANBAL08","TRANBAL09","TRANBAL10","TRANBAL11","TRANBAL12","TRANBAL13","TRANBAL14","TRANBAL15","TRANBAL16","TRANBAL17",
			"TRANBAL18","TRANBAL19","TRANBAL20","TRANBAL21","TRANBAL22","TRANBAL23","TRANBAL24","TRD","TRV03","TRV05","TRV12","TRV14","TRV17","TRV18","UL_TRD",
			"UL01S","UL06S","UL21S","UL25S","UL29S","UL30S","UL32S","UL34S","US25S","WALSHR07","WD21","WD31","WD51","WD61","WD71","WD81","CV_SCORE"

};
	
	

	static List<String> listaQueries;
	static List<List<List<String>>> queriesResult1;

	private int linea = 0;
	int Errores=0;
	@Test
	public void test1Estructura() throws Exception {
		Errores = 0;
		System.out.println(origenFile+fileName);
		try (BufferedReader buffReader = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(new FileInputStream(origenFile + fileName)),
				"UTF-8"))) {
			String data;
			String dataReading = null;
			this.linea = 1;
			PruebaFase2TradesHDComparacion.testEstructura=true;
			imprimirReporte("Prueba_Estructura_", "DETALLE ERROR|"
					+ Arrays.toString(cabecero).replace(",", "|").replace("[", "").replace("]", "").replace(" ", "")
					+ "\n", false);
			while ((data = buffReader.readLine()) != null) {
				PruebaFase2TradesHDComparacion.test = true;

				dataReading = data;

				if (dataReading.endsWith("|")) {
					dataReading = dataReading.replace("|", "|-");
				}
				if (linea == 1 && (!dataReading.equals(Arrays.toString(cabecero).replace(",", "|").replace("[", "")
						.replace("]", "").replace(" ", "")))) {
					imprimirReporte("Prueba_Estructura_", "Error en el nombrado de campos\n", true);
					PruebaFase2TradesHDComparacion.testEstructura = false;
					test = false;
				}
				if (linea != 1 && (dataReading.split("\\|").length != 354)) {
					imprimirReporte("Prueba_Estructura_",
							"Numero de campos es diferente al establecido, en la linea--> " + linea
									+ " el archivo tiene --> " + dataReading.split("\\|").length + " campos|" + data + "\n",
							true);
					//PruebaFase1TradesComparacion.testEstructura = false;
					test=false;
				}
		


				if (!test) {
					logger.error("Se encontraron errores en la comparacion en la linea--> " + linea);
					softAssert.fail("Se encontraron errores en la comparacion en la linea--> " + linea);

Errores++;
				}
				else {
					logger.info("Linea --> " + linea + " ok");

				}
				this.linea++;
			}
			imprimirReporte("Prueba_Estructura_", "Numero de registros analizados "+(linea-1)
				+	" errores encontrados "+ Errores+"\n", true);
			softAssert.assertAll();
			imprimirReporte("Prueba_Estructura_", "Prueba ejecutada sin errores\n", true);
		}
	}

	@Test
	public void test2pruebaArchivo() throws Exception {
		
		String idTerceroL = "";	
		Errores=0;
		this.linea = 1;
		imprimirReporte("Test_Archivo_", "", false);
		if (true/*PruebaFase1TradesHDComparacion.testEstructura*/) {
			try (BufferedReader buffReader = new BufferedReader(new InputStreamReader(
					new BufferedInputStream(new FileInputStream(origenFile + fileName)),
					"UTF-8"))) {
				String data;
				buffReader.readLine();
		
				imprimirReporte("Test_Archivo_", "Linea\tSec_ter\t\tVariable\tInfo_Archivo\t\tInfo_BD\n", true);
				DataBaseUtils.getDefaultConnection();
				while ((data = buffReader.readLine()) != null) {
					this.linea++;
					if (data.endsWith("|")) {
						data = data + " |";
					}
					test = true;
					if (data.split("\\|").length == 354) {
						//Numero de variables a evaluar
						Fase1ResultadoArchivoPlano.setDatosArchivoPlano(data);
				
						consultarBD(Fase1ResultadoArchivoPlano.getConsecutivo());
						idTerceroL = Fase1ResultadoArchivoPlano.getConsecutivo();
						
							if (queriesResult1.get(0).size() != 0) {
										//query set
								Fase1ResultadoBD.setDatosBD(queriesResult1.get(0).get(0));

								
								
								
								if (!Fase2ResultadoArchivoPlano.getSECUENCIA().equals(Fase2ResultadoBD.getSECUENCIA())) {
									reportarError(Fase2ResultadoArchivoPlano.getSECUENCIA(),Fase2ResultadoBD.getSECUENCIA(), cabecero[0]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1101().equals(Fase2ResultadoBD.getAGG1101())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1101(),Fase2ResultadoBD.getAGG1101(), cabecero[1]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1102().equals(Fase2ResultadoBD.getAGG1102())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1102(),Fase2ResultadoBD.getAGG1102(), cabecero[2]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1103().equals(Fase2ResultadoBD.getAGG1103())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1103(),Fase2ResultadoBD.getAGG1103(), cabecero[3]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1104().equals(Fase2ResultadoBD.getAGG1104())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1104(),Fase2ResultadoBD.getAGG1104(), cabecero[4]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1105().equals(Fase2ResultadoBD.getAGG1105())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1105(),Fase2ResultadoBD.getAGG1105(), cabecero[5]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1106().equals(Fase2ResultadoBD.getAGG1106())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1106(),Fase2ResultadoBD.getAGG1106(), cabecero[6]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1107().equals(Fase2ResultadoBD.getAGG1107())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1107(),Fase2ResultadoBD.getAGG1107(), cabecero[7]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1108().equals(Fase2ResultadoBD.getAGG1108())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1108(),Fase2ResultadoBD.getAGG1108(), cabecero[8]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1109().equals(Fase2ResultadoBD.getAGG1109())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1109(),Fase2ResultadoBD.getAGG1109(), cabecero[9]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1110().equals(Fase2ResultadoBD.getAGG1110())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1110(),Fase2ResultadoBD.getAGG1110(), cabecero[10]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1111().equals(Fase2ResultadoBD.getAGG1111())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1111(),Fase2ResultadoBD.getAGG1111(), cabecero[11]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1112().equals(Fase2ResultadoBD.getAGG1112())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1112(),Fase2ResultadoBD.getAGG1112(), cabecero[12]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1113().equals(Fase2ResultadoBD.getAGG1113())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1113(),Fase2ResultadoBD.getAGG1113(), cabecero[13]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1114().equals(Fase2ResultadoBD.getAGG1114())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1114(),Fase2ResultadoBD.getAGG1114(), cabecero[14]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1115().equals(Fase2ResultadoBD.getAGG1115())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1115(),Fase2ResultadoBD.getAGG1115(), cabecero[15]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1116().equals(Fase2ResultadoBD.getAGG1116())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1116(),Fase2ResultadoBD.getAGG1116(), cabecero[16]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1117().equals(Fase2ResultadoBD.getAGG1117())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1117(),Fase2ResultadoBD.getAGG1117(), cabecero[17]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1118().equals(Fase2ResultadoBD.getAGG1118())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1118(),Fase2ResultadoBD.getAGG1118(), cabecero[18]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1119().equals(Fase2ResultadoBD.getAGG1119())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1119(),Fase2ResultadoBD.getAGG1119(), cabecero[19]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1120().equals(Fase2ResultadoBD.getAGG1120())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1120(),Fase2ResultadoBD.getAGG1120(), cabecero[20]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1121().equals(Fase2ResultadoBD.getAGG1121())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1121(),Fase2ResultadoBD.getAGG1121(), cabecero[21]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1122().equals(Fase2ResultadoBD.getAGG1122())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1122(),Fase2ResultadoBD.getAGG1122(), cabecero[22]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1123().equals(Fase2ResultadoBD.getAGG1123())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1123(),Fase2ResultadoBD.getAGG1123(), cabecero[23]);}
								if (!Fase2ResultadoArchivoPlano.getAGG1124().equals(Fase2ResultadoBD.getAGG1124())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG1124(),Fase2ResultadoBD.getAGG1124(), cabecero[24]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2401().equals(Fase2ResultadoBD.getAGG2401())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2401(),Fase2ResultadoBD.getAGG2401(), cabecero[25]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2402().equals(Fase2ResultadoBD.getAGG2402())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2402(),Fase2ResultadoBD.getAGG2402(), cabecero[26]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2403().equals(Fase2ResultadoBD.getAGG2403())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2403(),Fase2ResultadoBD.getAGG2403(), cabecero[27]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2404().equals(Fase2ResultadoBD.getAGG2404())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2404(),Fase2ResultadoBD.getAGG2404(), cabecero[28]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2405().equals(Fase2ResultadoBD.getAGG2405())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2405(),Fase2ResultadoBD.getAGG2405(), cabecero[29]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2406().equals(Fase2ResultadoBD.getAGG2406())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2406(),Fase2ResultadoBD.getAGG2406(), cabecero[30]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2407().equals(Fase2ResultadoBD.getAGG2407())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2407(),Fase2ResultadoBD.getAGG2407(), cabecero[31]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2408().equals(Fase2ResultadoBD.getAGG2408())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2408(),Fase2ResultadoBD.getAGG2408(), cabecero[32]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2409().equals(Fase2ResultadoBD.getAGG2409())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2409(),Fase2ResultadoBD.getAGG2409(), cabecero[33]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2410().equals(Fase2ResultadoBD.getAGG2410())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2410(),Fase2ResultadoBD.getAGG2410(), cabecero[34]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2411().equals(Fase2ResultadoBD.getAGG2411())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2411(),Fase2ResultadoBD.getAGG2411(), cabecero[35]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2412().equals(Fase2ResultadoBD.getAGG2412())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2412(),Fase2ResultadoBD.getAGG2412(), cabecero[36]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2413().equals(Fase2ResultadoBD.getAGG2413())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2413(),Fase2ResultadoBD.getAGG2413(), cabecero[37]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2414().equals(Fase2ResultadoBD.getAGG2414())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2414(),Fase2ResultadoBD.getAGG2414(), cabecero[38]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2415().equals(Fase2ResultadoBD.getAGG2415())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2415(),Fase2ResultadoBD.getAGG2415(), cabecero[39]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2416().equals(Fase2ResultadoBD.getAGG2416())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2416(),Fase2ResultadoBD.getAGG2416(), cabecero[40]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2417().equals(Fase2ResultadoBD.getAGG2417())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2417(),Fase2ResultadoBD.getAGG2417(), cabecero[41]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2418().equals(Fase2ResultadoBD.getAGG2418())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2418(),Fase2ResultadoBD.getAGG2418(), cabecero[42]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2419().equals(Fase2ResultadoBD.getAGG2419())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2419(),Fase2ResultadoBD.getAGG2419(), cabecero[43]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2420().equals(Fase2ResultadoBD.getAGG2420())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2420(),Fase2ResultadoBD.getAGG2420(), cabecero[44]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2421().equals(Fase2ResultadoBD.getAGG2421())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2421(),Fase2ResultadoBD.getAGG2421(), cabecero[45]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2422().equals(Fase2ResultadoBD.getAGG2422())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2422(),Fase2ResultadoBD.getAGG2422(), cabecero[46]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2423().equals(Fase2ResultadoBD.getAGG2423())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2423(),Fase2ResultadoBD.getAGG2423(), cabecero[47]);}
								if (!Fase2ResultadoArchivoPlano.getAGG2424().equals(Fase2ResultadoBD.getAGG2424())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG2424(),Fase2ResultadoBD.getAGG2424(), cabecero[48]);}
								if (!Fase2ResultadoArchivoPlano.getAGG301().equals(Fase2ResultadoBD.getAGG301())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG301(),Fase2ResultadoBD.getAGG301(), cabecero[49]);}
								if (!Fase2ResultadoArchivoPlano.getAGG302().equals(Fase2ResultadoBD.getAGG302())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG302(),Fase2ResultadoBD.getAGG302(), cabecero[50]);}
								if (!Fase2ResultadoArchivoPlano.getAGG303().equals(Fase2ResultadoBD.getAGG303())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG303(),Fase2ResultadoBD.getAGG303(), cabecero[51]);}
								if (!Fase2ResultadoArchivoPlano.getAGG304().equals(Fase2ResultadoBD.getAGG304())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG304(),Fase2ResultadoBD.getAGG304(), cabecero[52]);}
								if (!Fase2ResultadoArchivoPlano.getAGG305().equals(Fase2ResultadoBD.getAGG305())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG305(),Fase2ResultadoBD.getAGG305(), cabecero[53]);}
								if (!Fase2ResultadoArchivoPlano.getAGG306().equals(Fase2ResultadoBD.getAGG306())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG306(),Fase2ResultadoBD.getAGG306(), cabecero[54]);}
								if (!Fase2ResultadoArchivoPlano.getAGG307().equals(Fase2ResultadoBD.getAGG307())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG307(),Fase2ResultadoBD.getAGG307(), cabecero[55]);}
								if (!Fase2ResultadoArchivoPlano.getAGG308().equals(Fase2ResultadoBD.getAGG308())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG308(),Fase2ResultadoBD.getAGG308(), cabecero[56]);}
								if (!Fase2ResultadoArchivoPlano.getAGG309().equals(Fase2ResultadoBD.getAGG309())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG309(),Fase2ResultadoBD.getAGG309(), cabecero[57]);}
								if (!Fase2ResultadoArchivoPlano.getAGG310().equals(Fase2ResultadoBD.getAGG310())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG310(),Fase2ResultadoBD.getAGG310(), cabecero[58]);}
								if (!Fase2ResultadoArchivoPlano.getAGG311().equals(Fase2ResultadoBD.getAGG311())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG311(),Fase2ResultadoBD.getAGG311(), cabecero[59]);}
								if (!Fase2ResultadoArchivoPlano.getAGG312().equals(Fase2ResultadoBD.getAGG312())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG312(),Fase2ResultadoBD.getAGG312(), cabecero[60]);}
								if (!Fase2ResultadoArchivoPlano.getAGG313().equals(Fase2ResultadoBD.getAGG313())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG313(),Fase2ResultadoBD.getAGG313(), cabecero[61]);}
								if (!Fase2ResultadoArchivoPlano.getAGG314().equals(Fase2ResultadoBD.getAGG314())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG314(),Fase2ResultadoBD.getAGG314(), cabecero[62]);}
								if (!Fase2ResultadoArchivoPlano.getAGG315().equals(Fase2ResultadoBD.getAGG315())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG315(),Fase2ResultadoBD.getAGG315(), cabecero[63]);}
								if (!Fase2ResultadoArchivoPlano.getAGG316().equals(Fase2ResultadoBD.getAGG316())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG316(),Fase2ResultadoBD.getAGG316(), cabecero[64]);}
								if (!Fase2ResultadoArchivoPlano.getAGG317().equals(Fase2ResultadoBD.getAGG317())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG317(),Fase2ResultadoBD.getAGG317(), cabecero[65]);}
								if (!Fase2ResultadoArchivoPlano.getAGG318().equals(Fase2ResultadoBD.getAGG318())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG318(),Fase2ResultadoBD.getAGG318(), cabecero[66]);}
								if (!Fase2ResultadoArchivoPlano.getAGG319().equals(Fase2ResultadoBD.getAGG319())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG319(),Fase2ResultadoBD.getAGG319(), cabecero[67]);}
								if (!Fase2ResultadoArchivoPlano.getAGG320().equals(Fase2ResultadoBD.getAGG320())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG320(),Fase2ResultadoBD.getAGG320(), cabecero[68]);}
								if (!Fase2ResultadoArchivoPlano.getAGG321().equals(Fase2ResultadoBD.getAGG321())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG321(),Fase2ResultadoBD.getAGG321(), cabecero[69]);}
								if (!Fase2ResultadoArchivoPlano.getAGG322().equals(Fase2ResultadoBD.getAGG322())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG322(),Fase2ResultadoBD.getAGG322(), cabecero[70]);}
								if (!Fase2ResultadoArchivoPlano.getAGG323().equals(Fase2ResultadoBD.getAGG323())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG323(),Fase2ResultadoBD.getAGG323(), cabecero[71]);}
								if (!Fase2ResultadoArchivoPlano.getAGG324().equals(Fase2ResultadoBD.getAGG324())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG324(),Fase2ResultadoBD.getAGG324(), cabecero[72]);}
								if (!Fase2ResultadoArchivoPlano.getAGG701().equals(Fase2ResultadoBD.getAGG701())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG701(),Fase2ResultadoBD.getAGG701(), cabecero[73]);}
								if (!Fase2ResultadoArchivoPlano.getAGG702().equals(Fase2ResultadoBD.getAGG702())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG702(),Fase2ResultadoBD.getAGG702(), cabecero[74]);}
								if (!Fase2ResultadoArchivoPlano.getAGG703().equals(Fase2ResultadoBD.getAGG703())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG703(),Fase2ResultadoBD.getAGG703(), cabecero[75]);}
								if (!Fase2ResultadoArchivoPlano.getAGG704().equals(Fase2ResultadoBD.getAGG704())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG704(),Fase2ResultadoBD.getAGG704(), cabecero[76]);}
								if (!Fase2ResultadoArchivoPlano.getAGG705().equals(Fase2ResultadoBD.getAGG705())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG705(),Fase2ResultadoBD.getAGG705(), cabecero[77]);}
								if (!Fase2ResultadoArchivoPlano.getAGG706().equals(Fase2ResultadoBD.getAGG706())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG706(),Fase2ResultadoBD.getAGG706(), cabecero[78]);}
								if (!Fase2ResultadoArchivoPlano.getAGG707().equals(Fase2ResultadoBD.getAGG707())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG707(),Fase2ResultadoBD.getAGG707(), cabecero[79]);}
								if (!Fase2ResultadoArchivoPlano.getAGG708().equals(Fase2ResultadoBD.getAGG708())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG708(),Fase2ResultadoBD.getAGG708(), cabecero[80]);}
								if (!Fase2ResultadoArchivoPlano.getAGG709().equals(Fase2ResultadoBD.getAGG709())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG709(),Fase2ResultadoBD.getAGG709(), cabecero[81]);}
								if (!Fase2ResultadoArchivoPlano.getAGG710().equals(Fase2ResultadoBD.getAGG710())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG710(),Fase2ResultadoBD.getAGG710(), cabecero[82]);}
								if (!Fase2ResultadoArchivoPlano.getAGG711().equals(Fase2ResultadoBD.getAGG711())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG711(),Fase2ResultadoBD.getAGG711(), cabecero[83]);}
								if (!Fase2ResultadoArchivoPlano.getAGG712().equals(Fase2ResultadoBD.getAGG712())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG712(),Fase2ResultadoBD.getAGG712(), cabecero[84]);}
								if (!Fase2ResultadoArchivoPlano.getAGG713().equals(Fase2ResultadoBD.getAGG713())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG713(),Fase2ResultadoBD.getAGG713(), cabecero[85]);}
								if (!Fase2ResultadoArchivoPlano.getAGG714().equals(Fase2ResultadoBD.getAGG714())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG714(),Fase2ResultadoBD.getAGG714(), cabecero[86]);}
								if (!Fase2ResultadoArchivoPlano.getAGG715().equals(Fase2ResultadoBD.getAGG715())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG715(),Fase2ResultadoBD.getAGG715(), cabecero[87]);}
								if (!Fase2ResultadoArchivoPlano.getAGG716().equals(Fase2ResultadoBD.getAGG716())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG716(),Fase2ResultadoBD.getAGG716(), cabecero[88]);}
								if (!Fase2ResultadoArchivoPlano.getAGG717().equals(Fase2ResultadoBD.getAGG717())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG717(),Fase2ResultadoBD.getAGG717(), cabecero[89]);}
								if (!Fase2ResultadoArchivoPlano.getAGG718().equals(Fase2ResultadoBD.getAGG718())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG718(),Fase2ResultadoBD.getAGG718(), cabecero[90]);}
								if (!Fase2ResultadoArchivoPlano.getAGG719().equals(Fase2ResultadoBD.getAGG719())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG719(),Fase2ResultadoBD.getAGG719(), cabecero[91]);}
								if (!Fase2ResultadoArchivoPlano.getAGG720().equals(Fase2ResultadoBD.getAGG720())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG720(),Fase2ResultadoBD.getAGG720(), cabecero[92]);}
								if (!Fase2ResultadoArchivoPlano.getAGG721().equals(Fase2ResultadoBD.getAGG721())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG721(),Fase2ResultadoBD.getAGG721(), cabecero[93]);}
								if (!Fase2ResultadoArchivoPlano.getAGG722().equals(Fase2ResultadoBD.getAGG722())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG722(),Fase2ResultadoBD.getAGG722(), cabecero[94]);}
								if (!Fase2ResultadoArchivoPlano.getAGG723().equals(Fase2ResultadoBD.getAGG723())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG723(),Fase2ResultadoBD.getAGG723(), cabecero[95]);}
								if (!Fase2ResultadoArchivoPlano.getAGG724().equals(Fase2ResultadoBD.getAGG724())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG724(),Fase2ResultadoBD.getAGG724(), cabecero[96]);}
								if (!Fase2ResultadoArchivoPlano.getAGG904().equals(Fase2ResultadoBD.getAGG904())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG904(),Fase2ResultadoBD.getAGG904(), cabecero[97]);}
								if (!Fase2ResultadoArchivoPlano.getAGG905().equals(Fase2ResultadoBD.getAGG905())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG905(),Fase2ResultadoBD.getAGG905(), cabecero[98]);}
								if (!Fase2ResultadoArchivoPlano.getAGG906().equals(Fase2ResultadoBD.getAGG906())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG906(),Fase2ResultadoBD.getAGG906(), cabecero[99]);}
								if (!Fase2ResultadoArchivoPlano.getAGG909().equals(Fase2ResultadoBD.getAGG909())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG909(),Fase2ResultadoBD.getAGG909(), cabecero[100]);}
								if (!Fase2ResultadoArchivoPlano.getAGG910().equals(Fase2ResultadoBD.getAGG910())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG910(),Fase2ResultadoBD.getAGG910(), cabecero[101]);}
								if (!Fase2ResultadoArchivoPlano.getAGG911().equals(Fase2ResultadoBD.getAGG911())) {
									reportarError(Fase2ResultadoArchivoPlano.getAGG911(),Fase2ResultadoBD.getAGG911(), cabecero[102]);}
								if (!Fase2ResultadoArchivoPlano.getAT31S().equals(Fase2ResultadoBD.getAT31S())) {
									reportarError(Fase2ResultadoArchivoPlano.getAT31S(),Fase2ResultadoBD.getAT31S(), cabecero[103]);}
								if (!Fase2ResultadoArchivoPlano.getAT34A().equals(Fase2ResultadoBD.getAT34A())) {
									reportarError(Fase2ResultadoArchivoPlano.getAT34A(),Fase2ResultadoBD.getAT34A(), cabecero[104]);}
								if (!Fase2ResultadoArchivoPlano.getAU21S().equals(Fase2ResultadoBD.getAU21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getAU21S(),Fase2ResultadoBD.getAU21S(), cabecero[105]);}
								if (!Fase2ResultadoArchivoPlano.getBC01S().equals(Fase2ResultadoBD.getBC01S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBC01S(),Fase2ResultadoBD.getBC01S(), cabecero[106]);}
								if (!Fase2ResultadoArchivoPlano.getBC20S().equals(Fase2ResultadoBD.getBC20S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBC20S(),Fase2ResultadoBD.getBC20S(), cabecero[107]);}
								if (!Fase2ResultadoArchivoPlano.getBC21S().equals(Fase2ResultadoBD.getBC21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBC21S(),Fase2ResultadoBD.getBC21S(), cabecero[108]);}
								if (!Fase2ResultadoArchivoPlano.getBI20S().equals(Fase2ResultadoBD.getBI20S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBI20S(),Fase2ResultadoBD.getBI20S(), cabecero[109]);}
								if (!Fase2ResultadoArchivoPlano.getBI21S().equals(Fase2ResultadoBD.getBI21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBI21S(),Fase2ResultadoBD.getBI21S(), cabecero[110]);}
								if (!Fase2ResultadoArchivoPlano.getBI29S().equals(Fase2ResultadoBD.getBI29S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBI29S(),Fase2ResultadoBD.getBI29S(), cabecero[111]);}
								if (!Fase2ResultadoArchivoPlano.getBI32S().equals(Fase2ResultadoBD.getBI32S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBI32S(),Fase2ResultadoBD.getBI32S(), cabecero[112]);}
								if (!Fase2ResultadoArchivoPlano.getBI34S().equals(Fase2ResultadoBD.getBI34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBI34S(),Fase2ResultadoBD.getBI34S(), cabecero[113]);}
								if (!Fase2ResultadoArchivoPlano.getBKC112().equals(Fase2ResultadoBD.getBKC112())) {
									reportarError(Fase2ResultadoArchivoPlano.getBKC112(),Fase2ResultadoBD.getBKC112(), cabecero[114]);}
								if (!Fase2ResultadoArchivoPlano.getBKC225().equals(Fase2ResultadoBD.getBKC225())) {
									reportarError(Fase2ResultadoArchivoPlano.getBKC225(),Fase2ResultadoBD.getBKC225(), cabecero[115]);}
								if (!Fase2ResultadoArchivoPlano.getBKC231().equals(Fase2ResultadoBD.getBKC231())) {
									reportarError(Fase2ResultadoArchivoPlano.getBKC231(),Fase2ResultadoBD.getBKC231(), cabecero[116]);}
								if (!Fase2ResultadoArchivoPlano.getBKC232().equals(Fase2ResultadoBD.getBKC232())) {
									reportarError(Fase2ResultadoArchivoPlano.getBKC232(),Fase2ResultadoBD.getBKC232(), cabecero[117]);}
								if (!Fase2ResultadoArchivoPlano.getBKC233().equals(Fase2ResultadoBD.getBKC233())) {
									reportarError(Fase2ResultadoArchivoPlano.getBKC233(),Fase2ResultadoBD.getBKC233(), cabecero[118]);}
								if (!Fase2ResultadoArchivoPlano.getBKC235().equals(Fase2ResultadoBD.getBKC235())) {
									reportarError(Fase2ResultadoArchivoPlano.getBKC235(),Fase2ResultadoBD.getBKC235(), cabecero[119]);}
								if (!Fase2ResultadoArchivoPlano.getBKC252().equals(Fase2ResultadoBD.getBKC252())) {
									reportarError(Fase2ResultadoArchivoPlano.getBKC252(),Fase2ResultadoBD.getBKC252(), cabecero[120]);}
								if (!Fase2ResultadoArchivoPlano.getBKC253().equals(Fase2ResultadoBD.getBKC253())) {
									reportarError(Fase2ResultadoArchivoPlano.getBKC253(),Fase2ResultadoBD.getBKC253(), cabecero[121]);}
								if (!Fase2ResultadoArchivoPlano.getBKC254().equals(Fase2ResultadoBD.getBKC254())) {
									reportarError(Fase2ResultadoArchivoPlano.getBKC254(),Fase2ResultadoBD.getBKC254(), cabecero[122]);}
								if (!Fase2ResultadoArchivoPlano.getBKC255().equals(Fase2ResultadoBD.getBKC255())) {
									reportarError(Fase2ResultadoArchivoPlano.getBKC255(),Fase2ResultadoBD.getBKC255(), cabecero[123]);}
								if (!Fase2ResultadoArchivoPlano.getBR12S().equals(Fase2ResultadoBD.getBR12S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBR12S(),Fase2ResultadoBD.getBR12S(), cabecero[124]);}
								if (!Fase2ResultadoArchivoPlano.getBR20S().equals(Fase2ResultadoBD.getBR20S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBR20S(),Fase2ResultadoBD.getBR20S(), cabecero[125]);}
								if (!Fase2ResultadoArchivoPlano.getBR27S().equals(Fase2ResultadoBD.getBR27S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBR27S(),Fase2ResultadoBD.getBR27S(), cabecero[126]);}
								if (!Fase2ResultadoArchivoPlano.getBR29S().equals(Fase2ResultadoBD.getBR29S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBR29S(),Fase2ResultadoBD.getBR29S(), cabecero[127]);}
								if (!Fase2ResultadoArchivoPlano.getBR34S().equals(Fase2ResultadoBD.getBR34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBR34S(),Fase2ResultadoBD.getBR34S(), cabecero[128]);}
								if (!Fase2ResultadoArchivoPlano.getBU09S().equals(Fase2ResultadoBD.getBU09S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBU09S(),Fase2ResultadoBD.getBU09S(), cabecero[129]);}
								if (!Fase2ResultadoArchivoPlano.getBU21S().equals(Fase2ResultadoBD.getBU21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBU21S(),Fase2ResultadoBD.getBU21S(), cabecero[130]);}
								if (!Fase2ResultadoArchivoPlano.getBU32S().equals(Fase2ResultadoBD.getBU32S())) {
									reportarError(Fase2ResultadoArchivoPlano.getBU32S(),Fase2ResultadoBD.getBU32S(), cabecero[131]);}
								if (!Fase2ResultadoArchivoPlano.getCA09S().equals(Fase2ResultadoBD.getCA09S())) {
									reportarError(Fase2ResultadoArchivoPlano.getCA09S(),Fase2ResultadoBD.getCA09S(), cabecero[132]);}
								if (!Fase2ResultadoArchivoPlano.getCA70S().equals(Fase2ResultadoBD.getCA70S())) {
									reportarError(Fase2ResultadoArchivoPlano.getCA70S(),Fase2ResultadoBD.getCA70S(), cabecero[133]);}
								if (!Fase2ResultadoArchivoPlano.getCO04S().equals(Fase2ResultadoBD.getCO04S())) {
									reportarError(Fase2ResultadoArchivoPlano.getCO04S(),Fase2ResultadoBD.getCO04S(), cabecero[134]);}
								if (!Fase2ResultadoArchivoPlano.getCO04SF().equals(Fase2ResultadoBD.getCO04SF())) {
									reportarError(Fase2ResultadoArchivoPlano.getCO04SF(),Fase2ResultadoBD.getCO04SF(), cabecero[135]);}
								if (!Fase2ResultadoArchivoPlano.getCOLLECTION_TRD().equals(Fase2ResultadoBD.getCOLLECTION_TRD())) {
									reportarError(Fase2ResultadoArchivoPlano.getCOLLECTION_TRD(),Fase2ResultadoBD.getCOLLECTION_TRD(), cabecero[136]);}
								if (!Fase2ResultadoArchivoPlano.getCT20S().equals(Fase2ResultadoBD.getCT20S())) {
									reportarError(Fase2ResultadoArchivoPlano.getCT20S(),Fase2ResultadoBD.getCT20S(), cabecero[137]);}
								if (!Fase2ResultadoArchivoPlano.getCT24S().equals(Fase2ResultadoBD.getCT24S())) {
									reportarError(Fase2ResultadoArchivoPlano.getCT24S(),Fase2ResultadoBD.getCT24S(), cabecero[138]);}
								if (!Fase2ResultadoArchivoPlano.getCT30S().equals(Fase2ResultadoBD.getCT30S())) {
									reportarError(Fase2ResultadoArchivoPlano.getCT30S(),Fase2ResultadoBD.getCT30S(), cabecero[139]);}
								if (!Fase2ResultadoArchivoPlano.getCT31S().equals(Fase2ResultadoBD.getCT31S())) {
									reportarError(Fase2ResultadoArchivoPlano.getCT31S(),Fase2ResultadoBD.getCT31S(), cabecero[140]);}
								if (!Fase2ResultadoArchivoPlano.getCT32S().equals(Fase2ResultadoBD.getCT32S())) {
									reportarError(Fase2ResultadoArchivoPlano.getCT32S(),Fase2ResultadoBD.getCT32S(), cabecero[141]);}
								if (!Fase2ResultadoArchivoPlano.getCV_SCORE().equals(Fase2ResultadoBD.getCV_SCORE())) {
									reportarError(Fase2ResultadoArchivoPlano.getCV_SCORE(),Fase2ResultadoBD.getCV_SCORE(), cabecero[142]);}
								if (!Fase2ResultadoArchivoPlano.getCV25().equals(Fase2ResultadoBD.getCV25())) {
									reportarError(Fase2ResultadoArchivoPlano.getCV25(),Fase2ResultadoBD.getCV25(), cabecero[143]);}
								if (!Fase2ResultadoArchivoPlano.getDM211S().equals(Fase2ResultadoBD.getDM211S())) {
									reportarError(Fase2ResultadoArchivoPlano.getDM211S(),Fase2ResultadoBD.getDM211S(), cabecero[144]);}
								if (!Fase2ResultadoArchivoPlano.getDM214S().equals(Fase2ResultadoBD.getDM214S())) {
									reportarError(Fase2ResultadoArchivoPlano.getDM214S(),Fase2ResultadoBD.getDM214S(), cabecero[145]);}
								if (!Fase2ResultadoArchivoPlano.getFI20S().equals(Fase2ResultadoBD.getFI20S())) {
									reportarError(Fase2ResultadoArchivoPlano.getFI20S(),Fase2ResultadoBD.getFI20S(), cabecero[146]);}
								if (!Fase2ResultadoArchivoPlano.getFI21S().equals(Fase2ResultadoBD.getFI21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getFI21S(),Fase2ResultadoBD.getFI21S(), cabecero[147]);}
								if (!Fase2ResultadoArchivoPlano.getFI34S().equals(Fase2ResultadoBD.getFI34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getFI34S(),Fase2ResultadoBD.getFI34S(), cabecero[148]);}
								if (!Fase2ResultadoArchivoPlano.getFMD21S().equals(Fase2ResultadoBD.getFMD21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getFMD21S(),Fase2ResultadoBD.getFMD21S(), cabecero[149]);}
								if (!Fase2ResultadoArchivoPlano.getFR21S().equals(Fase2ResultadoBD.getFR21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getFR21S(),Fase2ResultadoBD.getFR21S(), cabecero[150]);}
								if (!Fase2ResultadoArchivoPlano.getFR29S().equals(Fase2ResultadoBD.getFR29S())) {
									reportarError(Fase2ResultadoArchivoPlano.getFR29S(),Fase2ResultadoBD.getFR29S(), cabecero[151]);}
								if (!Fase2ResultadoArchivoPlano.getFR32S().equals(Fase2ResultadoBD.getFR32S())) {
									reportarError(Fase2ResultadoArchivoPlano.getFR32S(),Fase2ResultadoBD.getFR32S(), cabecero[152]);}
								if (!Fase2ResultadoArchivoPlano.getFR34S().equals(Fase2ResultadoBD.getFR34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getFR34S(),Fase2ResultadoBD.getFR34S(), cabecero[153]);}
								if (!Fase2ResultadoArchivoPlano.getFS20S().equals(Fase2ResultadoBD.getFS20S())) {
									reportarError(Fase2ResultadoArchivoPlano.getFS20S(),Fase2ResultadoBD.getFS20S(), cabecero[154]);}
								if (!Fase2ResultadoArchivoPlano.getFU20S().equals(Fase2ResultadoBD.getFU20S())) {
									reportarError(Fase2ResultadoArchivoPlano.getFU20S(),Fase2ResultadoBD.getFU20S(), cabecero[155]);}
								if (!Fase2ResultadoArchivoPlano.getFU21S().equals(Fase2ResultadoBD.getFU21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getFU21S(),Fase2ResultadoBD.getFU21S(), cabecero[156]);}
								if (!Fase2ResultadoArchivoPlano.getFU32S().equals(Fase2ResultadoBD.getFU32S())) {
									reportarError(Fase2ResultadoArchivoPlano.getFU32S(),Fase2ResultadoBD.getFU32S(), cabecero[157]);}
								if (!Fase2ResultadoArchivoPlano.getFU34S().equals(Fase2ResultadoBD.getFU34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getFU34S(),Fase2ResultadoBD.getFU34S(), cabecero[158]);}
								if (!Fase2ResultadoArchivoPlano.getG103S().equals(Fase2ResultadoBD.getG103S())) {
									reportarError(Fase2ResultadoArchivoPlano.getG103S(),Fase2ResultadoBD.getG103S(), cabecero[159]);}
								if (!Fase2ResultadoArchivoPlano.getG209SF().equals(Fase2ResultadoBD.getG209SF())) {
									reportarError(Fase2ResultadoArchivoPlano.getG209SF(),Fase2ResultadoBD.getG209SF(), cabecero[160]);}
								if (!Fase2ResultadoArchivoPlano.getG211S().equals(Fase2ResultadoBD.getG211S())) {
									reportarError(Fase2ResultadoArchivoPlano.getG211S(),Fase2ResultadoBD.getG211S(), cabecero[161]);}
								if (!Fase2ResultadoArchivoPlano.getG212SF().equals(Fase2ResultadoBD.getG212SF())) {
									reportarError(Fase2ResultadoArchivoPlano.getG212SF(),Fase2ResultadoBD.getG212SF(), cabecero[162]);}
								if (!Fase2ResultadoArchivoPlano.getG218BF().equals(Fase2ResultadoBD.getG218BF())) {
									reportarError(Fase2ResultadoArchivoPlano.getG218BF(),Fase2ResultadoBD.getG218BF(), cabecero[163]);}
								if (!Fase2ResultadoArchivoPlano.getG220A().equals(Fase2ResultadoBD.getG220A())) {
									reportarError(Fase2ResultadoArchivoPlano.getG220A(),Fase2ResultadoBD.getG220A(), cabecero[164]);}
								if (!Fase2ResultadoArchivoPlano.getG221D().equals(Fase2ResultadoBD.getG221D())) {
									reportarError(Fase2ResultadoArchivoPlano.getG221D(),Fase2ResultadoBD.getG221D(), cabecero[165]);}
								if (!Fase2ResultadoArchivoPlano.getG306S().equals(Fase2ResultadoBD.getG306S())) {
									reportarError(Fase2ResultadoArchivoPlano.getG306S(),Fase2ResultadoBD.getG306S(), cabecero[166]);}
								if (!Fase2ResultadoArchivoPlano.getG410S().equals(Fase2ResultadoBD.getG410S())) {
									reportarError(Fase2ResultadoArchivoPlano.getG410S(),Fase2ResultadoBD.getG410S(), cabecero[167]);}
								if (!Fase2ResultadoArchivoPlano.getG417S().equals(Fase2ResultadoBD.getG417S())) {
									reportarError(Fase2ResultadoArchivoPlano.getG417S(),Fase2ResultadoBD.getG417S(), cabecero[168]);}
								if (!Fase2ResultadoArchivoPlano.getG500S().equals(Fase2ResultadoBD.getG500S())) {
									reportarError(Fase2ResultadoArchivoPlano.getG500S(),Fase2ResultadoBD.getG500S(), cabecero[169]);}
								if (!Fase2ResultadoArchivoPlano.getG540S().equals(Fase2ResultadoBD.getG540S())) {
									reportarError(Fase2ResultadoArchivoPlano.getG540S(),Fase2ResultadoBD.getG540S(), cabecero[170]);}
								if (!Fase2ResultadoArchivoPlano.getG547S().equals(Fase2ResultadoBD.getG547S())) {
									reportarError(Fase2ResultadoArchivoPlano.getG547S(),Fase2ResultadoBD.getG547S(), cabecero[171]);}
								if (!Fase2ResultadoArchivoPlano.getG960S().equals(Fase2ResultadoBD.getG960S())) {
									reportarError(Fase2ResultadoArchivoPlano.getG960S(),Fase2ResultadoBD.getG960S(), cabecero[172]);}
								if (!Fase2ResultadoArchivoPlano.getIN01S().equals(Fase2ResultadoBD.getIN01S())) {
									reportarError(Fase2ResultadoArchivoPlano.getIN01S(),Fase2ResultadoBD.getIN01S(), cabecero[173]);}
								if (!Fase2ResultadoArchivoPlano.getIN06S().equals(Fase2ResultadoBD.getIN06S())) {
									reportarError(Fase2ResultadoArchivoPlano.getIN06S(),Fase2ResultadoBD.getIN06S(), cabecero[174]);}
								if (!Fase2ResultadoArchivoPlano.getIN09S().equals(Fase2ResultadoBD.getIN09S())) {
									reportarError(Fase2ResultadoArchivoPlano.getIN09S(),Fase2ResultadoBD.getIN09S(), cabecero[175]);}
								if (!Fase2ResultadoArchivoPlano.getIN21S().equals(Fase2ResultadoBD.getIN21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getIN21S(),Fase2ResultadoBD.getIN21S(), cabecero[176]);}
								if (!Fase2ResultadoArchivoPlano.getIN25S().equals(Fase2ResultadoBD.getIN25S())) {
									reportarError(Fase2ResultadoArchivoPlano.getIN25S(),Fase2ResultadoBD.getIN25S(), cabecero[177]);}
								if (!Fase2ResultadoArchivoPlano.getIN27S().equals(Fase2ResultadoBD.getIN27S())) {
									reportarError(Fase2ResultadoArchivoPlano.getIN27S(),Fase2ResultadoBD.getIN27S(), cabecero[178]);}
								if (!Fase2ResultadoArchivoPlano.getIN31S().equals(Fase2ResultadoBD.getIN31S())) {
									reportarError(Fase2ResultadoArchivoPlano.getIN31S(),Fase2ResultadoBD.getIN31S(), cabecero[179]);}
								if (!Fase2ResultadoArchivoPlano.getIN34S().equals(Fase2ResultadoBD.getIN34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getIN34S(),Fase2ResultadoBD.getIN34S(), cabecero[180]);}
								if (!Fase2ResultadoArchivoPlano.getLL09S().equals(Fase2ResultadoBD.getLL09S())) {
									reportarError(Fase2ResultadoArchivoPlano.getLL09S(),Fase2ResultadoBD.getLL09S(), cabecero[181]);}
								if (!Fase2ResultadoArchivoPlano.getLL21S().equals(Fase2ResultadoBD.getLL21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getLL21S(),Fase2ResultadoBD.getLL21S(), cabecero[182]);}
								if (!Fase2ResultadoArchivoPlano.getLL30S().equals(Fase2ResultadoBD.getLL30S())) {
									reportarError(Fase2ResultadoArchivoPlano.getLL30S(),Fase2ResultadoBD.getLL30S(), cabecero[183]);}
								if (!Fase2ResultadoArchivoPlano.getLL34S().equals(Fase2ResultadoBD.getLL34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getLL34S(),Fase2ResultadoBD.getLL34S(), cabecero[184]);}
								if (!Fase2ResultadoArchivoPlano.getLMD21S().equals(Fase2ResultadoBD.getLMD21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getLMD21S(),Fase2ResultadoBD.getLMD21S(), cabecero[185]);}
								if (!Fase2ResultadoArchivoPlano.getLMD30S().equals(Fase2ResultadoBD.getLMD30S())) {
									reportarError(Fase2ResultadoArchivoPlano.getLMD30S(),Fase2ResultadoBD.getLMD30S(), cabecero[186]);}
								if (!Fase2ResultadoArchivoPlano.getLMD32S().equals(Fase2ResultadoBD.getLMD32S())) {
									reportarError(Fase2ResultadoArchivoPlano.getLMD32S(),Fase2ResultadoBD.getLMD32S(), cabecero[187]);}
								if (!Fase2ResultadoArchivoPlano.getLMD34S().equals(Fase2ResultadoBD.getLMD34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getLMD34S(),Fase2ResultadoBD.getLMD34S(), cabecero[188]);}
								if (!Fase2ResultadoArchivoPlano.getLS29S().equals(Fase2ResultadoBD.getLS29S())) {
									reportarError(Fase2ResultadoArchivoPlano.getLS29S(),Fase2ResultadoBD.getLS29S(), cabecero[189]);}
								if (!Fase2ResultadoArchivoPlano.getLS30S().equals(Fase2ResultadoBD.getLS30S())) {
									reportarError(Fase2ResultadoArchivoPlano.getLS30S(),Fase2ResultadoBD.getLS30S(), cabecero[190]);}
								if (!Fase2ResultadoArchivoPlano.getLS34S().equals(Fase2ResultadoBD.getLS34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getLS34S(),Fase2ResultadoBD.getLS34S(), cabecero[191]);}
								if (!Fase2ResultadoArchivoPlano.getMF20S().equals(Fase2ResultadoBD.getMF20S())) {
									reportarError(Fase2ResultadoArchivoPlano.getMF20S(),Fase2ResultadoBD.getMF20S(), cabecero[192]);}
								if (!Fase2ResultadoArchivoPlano.getMF24S().equals(Fase2ResultadoBD.getMF24S())) {
									reportarError(Fase2ResultadoArchivoPlano.getMF24S(),Fase2ResultadoBD.getMF24S(), cabecero[193]);}
								if (!Fase2ResultadoArchivoPlano.getMF31S().equals(Fase2ResultadoBD.getMF31S())) {
									reportarError(Fase2ResultadoArchivoPlano.getMF31S(),Fase2ResultadoBD.getMF31S(), cabecero[194]);}
								if (!Fase2ResultadoArchivoPlano.getMF32S().equals(Fase2ResultadoBD.getMF32S())) {
									reportarError(Fase2ResultadoArchivoPlano.getMF32S(),Fase2ResultadoBD.getMF32S(), cabecero[195]);}
								if (!Fase2ResultadoArchivoPlano.getMT24S().equals(Fase2ResultadoBD.getMT24S())) {
									reportarError(Fase2ResultadoArchivoPlano.getMT24S(),Fase2ResultadoBD.getMT24S(), cabecero[196]);}
								if (!Fase2ResultadoArchivoPlano.getMT33S().equals(Fase2ResultadoBD.getMT33S())) {
									reportarError(Fase2ResultadoArchivoPlano.getMT33S(),Fase2ResultadoBD.getMT33S(), cabecero[197]);}
								if (!Fase2ResultadoArchivoPlano.getMT34B().equals(Fase2ResultadoBD.getMT34B())) {
									reportarError(Fase2ResultadoArchivoPlano.getMT34B(),Fase2ResultadoBD.getMT34B(), cabecero[198]);}
								if (!Fase2ResultadoArchivoPlano.getMT34S().equals(Fase2ResultadoBD.getMT34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getMT34S(),Fase2ResultadoBD.getMT34S(), cabecero[199]);}
								if (!Fase2ResultadoArchivoPlano.getNON_FINANCIAL_TRD().equals(Fase2ResultadoBD.getNON_FINANCIAL_TRD())) {
									reportarError(Fase2ResultadoArchivoPlano.getNON_FINANCIAL_TRD(),Fase2ResultadoBD.getNON_FINANCIAL_TRD(), cabecero[200]);}
								if (!Fase2ResultadoArchivoPlano.getOD34S().equals(Fase2ResultadoBD.getOD34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getOD34S(),Fase2ResultadoBD.getOD34S(), cabecero[201]);}
								if (!Fase2ResultadoArchivoPlano.getOF06S().equals(Fase2ResultadoBD.getOF06S())) {
									reportarError(Fase2ResultadoArchivoPlano.getOF06S(),Fase2ResultadoBD.getOF06S(), cabecero[202]);}
								if (!Fase2ResultadoArchivoPlano.getOF09S().equals(Fase2ResultadoBD.getOF09S())) {
									reportarError(Fase2ResultadoArchivoPlano.getOF09S(),Fase2ResultadoBD.getOF09S(), cabecero[203]);}
								if (!Fase2ResultadoArchivoPlano.getOF32S().equals(Fase2ResultadoBD.getOF32S())) {
									reportarError(Fase2ResultadoArchivoPlano.getOF32S(),Fase2ResultadoBD.getOF32S(), cabecero[204]);}
								if (!Fase2ResultadoArchivoPlano.getOF34S().equals(Fase2ResultadoBD.getOF34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getOF34S(),Fase2ResultadoBD.getOF34S(), cabecero[205]);}
								if (!Fase2ResultadoArchivoPlano.getPAYMNT03().equals(Fase2ResultadoBD.getPAYMNT03())) {
									reportarError(Fase2ResultadoArchivoPlano.getPAYMNT03(),Fase2ResultadoBD.getPAYMNT03(), cabecero[206]);}
								if (!Fase2ResultadoArchivoPlano.getPAYMNT50().equals(Fase2ResultadoBD.getPAYMNT50())) {
									reportarError(Fase2ResultadoArchivoPlano.getPAYMNT50(),Fase2ResultadoBD.getPAYMNT50(), cabecero[207]);}
								if (!Fase2ResultadoArchivoPlano.getPAYMNT65().equals(Fase2ResultadoBD.getPAYMNT65())) {
									reportarError(Fase2ResultadoArchivoPlano.getPAYMNT65(),Fase2ResultadoBD.getPAYMNT65(), cabecero[208]);}
								if (!Fase2ResultadoArchivoPlano.getPER201().equals(Fase2ResultadoBD.getPER201())) {
									reportarError(Fase2ResultadoArchivoPlano.getPER201(),Fase2ResultadoBD.getPER201(), cabecero[209]);}
								if (!Fase2ResultadoArchivoPlano.getPER222().equals(Fase2ResultadoBD.getPER222())) {
									reportarError(Fase2ResultadoArchivoPlano.getPER222(),Fase2ResultadoBD.getPER222(), cabecero[210]);}
								if (!Fase2ResultadoArchivoPlano.getPER223().equals(Fase2ResultadoBD.getPER223())) {
									reportarError(Fase2ResultadoArchivoPlano.getPER223(),Fase2ResultadoBD.getPER223(), cabecero[211]);}
								if (!Fase2ResultadoArchivoPlano.getPER224().equals(Fase2ResultadoBD.getPER224())) {
									reportarError(Fase2ResultadoArchivoPlano.getPER224(),Fase2ResultadoBD.getPER224(), cabecero[212]);}
								if (!Fase2ResultadoArchivoPlano.getPER233().equals(Fase2ResultadoBD.getPER233())) {
									reportarError(Fase2ResultadoArchivoPlano.getPER233(),Fase2ResultadoBD.getPER233(), cabecero[213]);}
								if (!Fase2ResultadoArchivoPlano.getPT09S().equals(Fase2ResultadoBD.getPT09S())) {
									reportarError(Fase2ResultadoArchivoPlano.getPT09S(),Fase2ResultadoBD.getPT09S(), cabecero[214]);}
								if (!Fase2ResultadoArchivoPlano.getPT20S().equals(Fase2ResultadoBD.getPT20S())) {
									reportarError(Fase2ResultadoArchivoPlano.getPT20S(),Fase2ResultadoBD.getPT20S(), cabecero[215]);}
								if (!Fase2ResultadoArchivoPlano.getPT21S().equals(Fase2ResultadoBD.getPT21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getPT21S(),Fase2ResultadoBD.getPT21S(), cabecero[216]);}
								if (!Fase2ResultadoArchivoPlano.getPT30S().equals(Fase2ResultadoBD.getPT30S())) {
									reportarError(Fase2ResultadoArchivoPlano.getPT30S(),Fase2ResultadoBD.getPT30S(), cabecero[217]);}
								if (!Fase2ResultadoArchivoPlano.getPT34S().equals(Fase2ResultadoBD.getPT34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getPT34S(),Fase2ResultadoBD.getPT34S(), cabecero[218]);}
								if (!Fase2ResultadoArchivoPlano.getPUBLIC_SERVICE_TRD().equals(Fase2ResultadoBD.getPUBLIC_SERVICE_TRD())) {
									reportarError(Fase2ResultadoArchivoPlano.getPUBLIC_SERVICE_TRD(),Fase2ResultadoBD.getPUBLIC_SERVICE_TRD(), cabecero[219]);}
								if (!Fase2ResultadoArchivoPlano.getRE102S().equals(Fase2ResultadoBD.getRE102S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRE102S(),Fase2ResultadoBD.getRE102S(), cabecero[220]);}
								if (!Fase2ResultadoArchivoPlano.getRE12S().equals(Fase2ResultadoBD.getRE12S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRE12S(),Fase2ResultadoBD.getRE12S(), cabecero[221]);}
								if (!Fase2ResultadoArchivoPlano.getRE30S().equals(Fase2ResultadoBD.getRE30S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRE30S(),Fase2ResultadoBD.getRE30S(), cabecero[222]);}
								if (!Fase2ResultadoArchivoPlano.getRE32S().equals(Fase2ResultadoBD.getRE32S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRE32S(),Fase2ResultadoBD.getRE32S(), cabecero[223]);}
								if (!Fase2ResultadoArchivoPlano.getRET11().equals(Fase2ResultadoBD.getRET11())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET11(),Fase2ResultadoBD.getRET11(), cabecero[224]);}
								if (!Fase2ResultadoArchivoPlano.getRET13().equals(Fase2ResultadoBD.getRET13())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET13(),Fase2ResultadoBD.getRET13(), cabecero[225]);}
								if (!Fase2ResultadoArchivoPlano.getRET132().equals(Fase2ResultadoBD.getRET132())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET132(),Fase2ResultadoBD.getRET132(), cabecero[226]);}
								if (!Fase2ResultadoArchivoPlano.getRET14().equals(Fase2ResultadoBD.getRET14())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET14(),Fase2ResultadoBD.getRET14(), cabecero[227]);}
								if (!Fase2ResultadoArchivoPlano.getRET142().equals(Fase2ResultadoBD.getRET142())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET142(),Fase2ResultadoBD.getRET142(), cabecero[228]);}
								if (!Fase2ResultadoArchivoPlano.getRET152().equals(Fase2ResultadoBD.getRET152())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET152(),Fase2ResultadoBD.getRET152(), cabecero[229]);}
								if (!Fase2ResultadoArchivoPlano.getRET201().equals(Fase2ResultadoBD.getRET201())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET201(),Fase2ResultadoBD.getRET201(), cabecero[230]);}
								if (!Fase2ResultadoArchivoPlano.getRET222().equals(Fase2ResultadoBD.getRET222())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET222(),Fase2ResultadoBD.getRET222(), cabecero[231]);}
								if (!Fase2ResultadoArchivoPlano.getRET223().equals(Fase2ResultadoBD.getRET223())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET223(),Fase2ResultadoBD.getRET223(), cabecero[232]);}
								if (!Fase2ResultadoArchivoPlano.getRET224().equals(Fase2ResultadoBD.getRET224())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET224(),Fase2ResultadoBD.getRET224(), cabecero[233]);}
								if (!Fase2ResultadoArchivoPlano.getRET225().equals(Fase2ResultadoBD.getRET225())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET225(),Fase2ResultadoBD.getRET225(), cabecero[234]);}
								if (!Fase2ResultadoArchivoPlano.getRET315().equals(Fase2ResultadoBD.getRET315())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET315(),Fase2ResultadoBD.getRET315(), cabecero[235]);}
								if (!Fase2ResultadoArchivoPlano.getRET320().equals(Fase2ResultadoBD.getRET320())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET320(),Fase2ResultadoBD.getRET320(), cabecero[236]);}
								if (!Fase2ResultadoArchivoPlano.getRET51().equals(Fase2ResultadoBD.getRET51())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET51(),Fase2ResultadoBD.getRET51(), cabecero[237]);}
								if (!Fase2ResultadoArchivoPlano.getRET81().equals(Fase2ResultadoBD.getRET81())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET81(),Fase2ResultadoBD.getRET81(), cabecero[238]);}
								if (!Fase2ResultadoArchivoPlano.getRET84().equals(Fase2ResultadoBD.getRET84())) {
									reportarError(Fase2ResultadoArchivoPlano.getRET84(),Fase2ResultadoBD.getRET84(), cabecero[239]);}
								if (!Fase2ResultadoArchivoPlano.getREV14().equals(Fase2ResultadoBD.getREV14())) {
									reportarError(Fase2ResultadoArchivoPlano.getREV14(),Fase2ResultadoBD.getREV14(), cabecero[240]);}
								if (!Fase2ResultadoArchivoPlano.getREV202().equals(Fase2ResultadoBD.getREV202())) {
									reportarError(Fase2ResultadoArchivoPlano.getREV202(),Fase2ResultadoBD.getREV202(), cabecero[241]);}
								if (!Fase2ResultadoArchivoPlano.getREV203().equals(Fase2ResultadoBD.getREV203())) {
									reportarError(Fase2ResultadoArchivoPlano.getREV203(),Fase2ResultadoBD.getREV203(), cabecero[242]);}
								if (!Fase2ResultadoArchivoPlano.getREV204().equals(Fase2ResultadoBD.getREV204())) {
									reportarError(Fase2ResultadoArchivoPlano.getREV204(),Fase2ResultadoBD.getREV204(), cabecero[243]);}
								if (!Fase2ResultadoArchivoPlano.getREV222().equals(Fase2ResultadoBD.getREV222())) {
									reportarError(Fase2ResultadoArchivoPlano.getREV222(),Fase2ResultadoBD.getREV222(), cabecero[244]);}
								if (!Fase2ResultadoArchivoPlano.getREV223().equals(Fase2ResultadoBD.getREV223())) {
									reportarError(Fase2ResultadoArchivoPlano.getREV223(),Fase2ResultadoBD.getREV223(), cabecero[245]);}
								if (!Fase2ResultadoArchivoPlano.getREV225().equals(Fase2ResultadoBD.getREV225())) {
									reportarError(Fase2ResultadoArchivoPlano.getREV225(),Fase2ResultadoBD.getREV225(), cabecero[246]);}
								if (!Fase2ResultadoArchivoPlano.getREV253().equals(Fase2ResultadoBD.getREV253())) {
									reportarError(Fase2ResultadoArchivoPlano.getREV253(),Fase2ResultadoBD.getREV253(), cabecero[247]);}
								if (!Fase2ResultadoArchivoPlano.getREV320().equals(Fase2ResultadoBD.getREV320())) {
									reportarError(Fase2ResultadoArchivoPlano.getREV320(),Fase2ResultadoBD.getREV320(), cabecero[248]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL01().equals(Fase2ResultadoBD.getREVBAL01())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL01(),Fase2ResultadoBD.getREVBAL01(), cabecero[249]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL02().equals(Fase2ResultadoBD.getREVBAL02())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL02(),Fase2ResultadoBD.getREVBAL02(), cabecero[250]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL03().equals(Fase2ResultadoBD.getREVBAL03())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL03(),Fase2ResultadoBD.getREVBAL03(), cabecero[251]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL04().equals(Fase2ResultadoBD.getREVBAL04())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL04(),Fase2ResultadoBD.getREVBAL04(), cabecero[252]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL05().equals(Fase2ResultadoBD.getREVBAL05())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL05(),Fase2ResultadoBD.getREVBAL05(), cabecero[253]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL06().equals(Fase2ResultadoBD.getREVBAL06())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL06(),Fase2ResultadoBD.getREVBAL06(), cabecero[254]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL07().equals(Fase2ResultadoBD.getREVBAL07())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL07(),Fase2ResultadoBD.getREVBAL07(), cabecero[255]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL08().equals(Fase2ResultadoBD.getREVBAL08())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL08(),Fase2ResultadoBD.getREVBAL08(), cabecero[256]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL09().equals(Fase2ResultadoBD.getREVBAL09())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL09(),Fase2ResultadoBD.getREVBAL09(), cabecero[257]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL10().equals(Fase2ResultadoBD.getREVBAL10())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL10(),Fase2ResultadoBD.getREVBAL10(), cabecero[258]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL11().equals(Fase2ResultadoBD.getREVBAL11())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL11(),Fase2ResultadoBD.getREVBAL11(), cabecero[259]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL12().equals(Fase2ResultadoBD.getREVBAL12())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL12(),Fase2ResultadoBD.getREVBAL12(), cabecero[260]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL13().equals(Fase2ResultadoBD.getREVBAL13())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL13(),Fase2ResultadoBD.getREVBAL13(), cabecero[261]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL14().equals(Fase2ResultadoBD.getREVBAL14())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL14(),Fase2ResultadoBD.getREVBAL14(), cabecero[262]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL15().equals(Fase2ResultadoBD.getREVBAL15())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL15(),Fase2ResultadoBD.getREVBAL15(), cabecero[263]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL16().equals(Fase2ResultadoBD.getREVBAL16())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL16(),Fase2ResultadoBD.getREVBAL16(), cabecero[264]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL17().equals(Fase2ResultadoBD.getREVBAL17())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL17(),Fase2ResultadoBD.getREVBAL17(), cabecero[265]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL18().equals(Fase2ResultadoBD.getREVBAL18())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL18(),Fase2ResultadoBD.getREVBAL18(), cabecero[266]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL19().equals(Fase2ResultadoBD.getREVBAL19())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL19(),Fase2ResultadoBD.getREVBAL19(), cabecero[267]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL20().equals(Fase2ResultadoBD.getREVBAL20())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL20(),Fase2ResultadoBD.getREVBAL20(), cabecero[268]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL21().equals(Fase2ResultadoBD.getREVBAL21())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL21(),Fase2ResultadoBD.getREVBAL21(), cabecero[269]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL22().equals(Fase2ResultadoBD.getREVBAL22())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL22(),Fase2ResultadoBD.getREVBAL22(), cabecero[270]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL23().equals(Fase2ResultadoBD.getREVBAL23())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL23(),Fase2ResultadoBD.getREVBAL23(), cabecero[271]);}
								if (!Fase2ResultadoArchivoPlano.getREVBAL24().equals(Fase2ResultadoBD.getREVBAL24())) {
									reportarError(Fase2ResultadoArchivoPlano.getREVBAL24(),Fase2ResultadoBD.getREVBAL24(), cabecero[272]);}
								if (!Fase2ResultadoArchivoPlano.getRI06S().equals(Fase2ResultadoBD.getRI06S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRI06S(),Fase2ResultadoBD.getRI06S(), cabecero[273]);}
								if (!Fase2ResultadoArchivoPlano.getRI20S().equals(Fase2ResultadoBD.getRI20S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRI20S(),Fase2ResultadoBD.getRI20S(), cabecero[274]);}
								if (!Fase2ResultadoArchivoPlano.getRI21S().equals(Fase2ResultadoBD.getRI21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRI21S(),Fase2ResultadoBD.getRI21S(), cabecero[275]);}
								if (!Fase2ResultadoArchivoPlano.getRI24S().equals(Fase2ResultadoBD.getRI24S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRI24S(),Fase2ResultadoBD.getRI24S(), cabecero[276]);}
								if (!Fase2ResultadoArchivoPlano.getRI27S().equals(Fase2ResultadoBD.getRI27S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRI27S(),Fase2ResultadoBD.getRI27S(), cabecero[277]);}
								if (!Fase2ResultadoArchivoPlano.getRI29S().equals(Fase2ResultadoBD.getRI29S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRI29S(),Fase2ResultadoBD.getRI29S(), cabecero[278]);}
								if (!Fase2ResultadoArchivoPlano.getRI30S().equals(Fase2ResultadoBD.getRI30S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRI30S(),Fase2ResultadoBD.getRI30S(), cabecero[279]);}
								if (!Fase2ResultadoArchivoPlano.getRI31S().equals(Fase2ResultadoBD.getRI31S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRI31S(),Fase2ResultadoBD.getRI31S(), cabecero[280]);}
								if (!Fase2ResultadoArchivoPlano.getRI32S().equals(Fase2ResultadoBD.getRI32S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRI32S(),Fase2ResultadoBD.getRI32S(), cabecero[281]);}
								if (!Fase2ResultadoArchivoPlano.getRLE904().equals(Fase2ResultadoBD.getRLE904())) {
									reportarError(Fase2ResultadoArchivoPlano.getRLE904(),Fase2ResultadoBD.getRLE904(), cabecero[282]);}
								if (!Fase2ResultadoArchivoPlano.getRLE905().equals(Fase2ResultadoBD.getRLE905())) {
									reportarError(Fase2ResultadoArchivoPlano.getRLE905(),Fase2ResultadoBD.getRLE905(), cabecero[283]);}
								if (!Fase2ResultadoArchivoPlano.getRLE907().equals(Fase2ResultadoBD.getRLE907())) {
									reportarError(Fase2ResultadoArchivoPlano.getRLE907(),Fase2ResultadoBD.getRLE907(), cabecero[284]);}
								if (!Fase2ResultadoArchivoPlano.getRR102S().equals(Fase2ResultadoBD.getRR102S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRR102S(),Fase2ResultadoBD.getRR102S(), cabecero[285]);}
								if (!Fase2ResultadoArchivoPlano.getRR201S().equals(Fase2ResultadoBD.getRR201S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRR201S(),Fase2ResultadoBD.getRR201S(), cabecero[286]);}
								if (!Fase2ResultadoArchivoPlano.getRR21S().equals(Fase2ResultadoBD.getRR21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRR21S(),Fase2ResultadoBD.getRR21S(), cabecero[287]);}
								if (!Fase2ResultadoArchivoPlano.getRR24S().equals(Fase2ResultadoBD.getRR24S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRR24S(),Fase2ResultadoBD.getRR24S(), cabecero[288]);}
								if (!Fase2ResultadoArchivoPlano.getRR25S().equals(Fase2ResultadoBD.getRR25S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRR25S(),Fase2ResultadoBD.getRR25S(), cabecero[289]);}
								if (!Fase2ResultadoArchivoPlano.getRT06S().equals(Fase2ResultadoBD.getRT06S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRT06S(),Fase2ResultadoBD.getRT06S(), cabecero[290]);}
								if (!Fase2ResultadoArchivoPlano.getRT201S().equals(Fase2ResultadoBD.getRT201S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRT201S(),Fase2ResultadoBD.getRT201S(), cabecero[291]);}
								if (!Fase2ResultadoArchivoPlano.getRT21S().equals(Fase2ResultadoBD.getRT21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRT21S(),Fase2ResultadoBD.getRT21S(), cabecero[292]);}
								if (!Fase2ResultadoArchivoPlano.getRT24S().equals(Fase2ResultadoBD.getRT24S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRT24S(),Fase2ResultadoBD.getRT24S(), cabecero[293]);}
								if (!Fase2ResultadoArchivoPlano.getRT31S().equals(Fase2ResultadoBD.getRT31S())) {
									reportarError(Fase2ResultadoArchivoPlano.getRT31S(),Fase2ResultadoBD.getRT31S(), cabecero[294]);}
								if (!Fase2ResultadoArchivoPlano.getRVLR03().equals(Fase2ResultadoBD.getRVLR03())) {
									reportarError(Fase2ResultadoArchivoPlano.getRVLR03(),Fase2ResultadoBD.getRVLR03(), cabecero[295]);}
								if (!Fase2ResultadoArchivoPlano.getRVLR06().equals(Fase2ResultadoBD.getRVLR06())) {
									reportarError(Fase2ResultadoArchivoPlano.getRVLR06(),Fase2ResultadoBD.getRVLR06(), cabecero[296]);}
								if (!Fase2ResultadoArchivoPlano.getRVLR09().equals(Fase2ResultadoBD.getRVLR09())) {
									reportarError(Fase2ResultadoArchivoPlano.getRVLR09(),Fase2ResultadoBD.getRVLR09(), cabecero[297]);}
								if (!Fase2ResultadoArchivoPlano.getS064D().equals(Fase2ResultadoBD.getS064D())) {
									reportarError(Fase2ResultadoArchivoPlano.getS064D(),Fase2ResultadoBD.getS064D(), cabecero[298]);}
								if (!Fase2ResultadoArchivoPlano.getS209D().equals(Fase2ResultadoBD.getS209D())) {
									reportarError(Fase2ResultadoArchivoPlano.getS209D(),Fase2ResultadoBD.getS209D(), cabecero[299]);}
								if (!Fase2ResultadoArchivoPlano.getSE09S().equals(Fase2ResultadoBD.getSE09S())) {
									reportarError(Fase2ResultadoArchivoPlano.getSE09S(),Fase2ResultadoBD.getSE09S(), cabecero[300]);}
								if (!Fase2ResultadoArchivoPlano.getSE21S().equals(Fase2ResultadoBD.getSE21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getSE21S(),Fase2ResultadoBD.getSE21S(), cabecero[301]);}
								if (!Fase2ResultadoArchivoPlano.getSE34S().equals(Fase2ResultadoBD.getSE34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getSE34S(),Fase2ResultadoBD.getSE34S(), cabecero[302]);}
								if (!Fase2ResultadoArchivoPlano.getTEL09S().equals(Fase2ResultadoBD.getTEL09S())) {
									reportarError(Fase2ResultadoArchivoPlano.getTEL09S(),Fase2ResultadoBD.getTEL09S(), cabecero[303]);}
								if (!Fase2ResultadoArchivoPlano.getTEL21S().equals(Fase2ResultadoBD.getTEL21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getTEL21S(),Fase2ResultadoBD.getTEL21S(), cabecero[304]);}
								if (!Fase2ResultadoArchivoPlano.getTEL30S().equals(Fase2ResultadoBD.getTEL30S())) {
									reportarError(Fase2ResultadoArchivoPlano.getTEL30S(),Fase2ResultadoBD.getTEL30S(), cabecero[305]);}
								if (!Fase2ResultadoArchivoPlano.getTEL31S().equals(Fase2ResultadoBD.getTEL31S())) {
									reportarError(Fase2ResultadoArchivoPlano.getTEL31S(),Fase2ResultadoBD.getTEL31S(), cabecero[306]);}
								if (!Fase2ResultadoArchivoPlano.getTEL32S().equals(Fase2ResultadoBD.getTEL32S())) {
									reportarError(Fase2ResultadoArchivoPlano.getTEL32S(),Fase2ResultadoBD.getTEL32S(), cabecero[307]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL01().equals(Fase2ResultadoBD.getTRANBAL01())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL01(),Fase2ResultadoBD.getTRANBAL01(), cabecero[308]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL02().equals(Fase2ResultadoBD.getTRANBAL02())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL02(),Fase2ResultadoBD.getTRANBAL02(), cabecero[309]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL03().equals(Fase2ResultadoBD.getTRANBAL03())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL03(),Fase2ResultadoBD.getTRANBAL03(), cabecero[310]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL04().equals(Fase2ResultadoBD.getTRANBAL04())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL04(),Fase2ResultadoBD.getTRANBAL04(), cabecero[311]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL05().equals(Fase2ResultadoBD.getTRANBAL05())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL05(),Fase2ResultadoBD.getTRANBAL05(), cabecero[312]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL06().equals(Fase2ResultadoBD.getTRANBAL06())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL06(),Fase2ResultadoBD.getTRANBAL06(), cabecero[313]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL07().equals(Fase2ResultadoBD.getTRANBAL07())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL07(),Fase2ResultadoBD.getTRANBAL07(), cabecero[314]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL08().equals(Fase2ResultadoBD.getTRANBAL08())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL08(),Fase2ResultadoBD.getTRANBAL08(), cabecero[315]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL09().equals(Fase2ResultadoBD.getTRANBAL09())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL09(),Fase2ResultadoBD.getTRANBAL09(), cabecero[316]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL10().equals(Fase2ResultadoBD.getTRANBAL10())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL10(),Fase2ResultadoBD.getTRANBAL10(), cabecero[317]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL11().equals(Fase2ResultadoBD.getTRANBAL11())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL11(),Fase2ResultadoBD.getTRANBAL11(), cabecero[318]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL12().equals(Fase2ResultadoBD.getTRANBAL12())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL12(),Fase2ResultadoBD.getTRANBAL12(), cabecero[319]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL13().equals(Fase2ResultadoBD.getTRANBAL13())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL13(),Fase2ResultadoBD.getTRANBAL13(), cabecero[320]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL14().equals(Fase2ResultadoBD.getTRANBAL14())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL14(),Fase2ResultadoBD.getTRANBAL14(), cabecero[321]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL15().equals(Fase2ResultadoBD.getTRANBAL15())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL15(),Fase2ResultadoBD.getTRANBAL15(), cabecero[322]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL16().equals(Fase2ResultadoBD.getTRANBAL16())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL16(),Fase2ResultadoBD.getTRANBAL16(), cabecero[323]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL17().equals(Fase2ResultadoBD.getTRANBAL17())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL17(),Fase2ResultadoBD.getTRANBAL17(), cabecero[324]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL18().equals(Fase2ResultadoBD.getTRANBAL18())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL18(),Fase2ResultadoBD.getTRANBAL18(), cabecero[325]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL19().equals(Fase2ResultadoBD.getTRANBAL19())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL19(),Fase2ResultadoBD.getTRANBAL19(), cabecero[326]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL20().equals(Fase2ResultadoBD.getTRANBAL20())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL20(),Fase2ResultadoBD.getTRANBAL20(), cabecero[327]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL21().equals(Fase2ResultadoBD.getTRANBAL21())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL21(),Fase2ResultadoBD.getTRANBAL21(), cabecero[328]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL22().equals(Fase2ResultadoBD.getTRANBAL22())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL22(),Fase2ResultadoBD.getTRANBAL22(), cabecero[329]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL23().equals(Fase2ResultadoBD.getTRANBAL23())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL23(),Fase2ResultadoBD.getTRANBAL23(), cabecero[330]);}
								if (!Fase2ResultadoArchivoPlano.getTRANBAL24().equals(Fase2ResultadoBD.getTRANBAL24())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRANBAL24(),Fase2ResultadoBD.getTRANBAL24(), cabecero[331]);}
								if (!Fase2ResultadoArchivoPlano.getTRD().equals(Fase2ResultadoBD.getTRD())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRD(),Fase2ResultadoBD.getTRD(), cabecero[332]);}
								if (!Fase2ResultadoArchivoPlano.getTRV03().equals(Fase2ResultadoBD.getTRV03())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRV03(),Fase2ResultadoBD.getTRV03(), cabecero[333]);}
								if (!Fase2ResultadoArchivoPlano.getTRV05().equals(Fase2ResultadoBD.getTRV05())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRV05(),Fase2ResultadoBD.getTRV05(), cabecero[334]);}
								if (!Fase2ResultadoArchivoPlano.getTRV12().equals(Fase2ResultadoBD.getTRV12())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRV12(),Fase2ResultadoBD.getTRV12(), cabecero[335]);}
								if (!Fase2ResultadoArchivoPlano.getTRV14().equals(Fase2ResultadoBD.getTRV14())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRV14(),Fase2ResultadoBD.getTRV14(), cabecero[336]);}
								if (!Fase2ResultadoArchivoPlano.getTRV17().equals(Fase2ResultadoBD.getTRV17())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRV17(),Fase2ResultadoBD.getTRV17(), cabecero[337]);}
								if (!Fase2ResultadoArchivoPlano.getTRV18().equals(Fase2ResultadoBD.getTRV18())) {
									reportarError(Fase2ResultadoArchivoPlano.getTRV18(),Fase2ResultadoBD.getTRV18(), cabecero[338]);}
								if (!Fase2ResultadoArchivoPlano.getUL_TRD().equals(Fase2ResultadoBD.getUL_TRD())) {
									reportarError(Fase2ResultadoArchivoPlano.getUL_TRD(),Fase2ResultadoBD.getUL_TRD(), cabecero[339]);}
								if (!Fase2ResultadoArchivoPlano.getUL01S().equals(Fase2ResultadoBD.getUL01S())) {
									reportarError(Fase2ResultadoArchivoPlano.getUL01S(),Fase2ResultadoBD.getUL01S(), cabecero[340]);}
								if (!Fase2ResultadoArchivoPlano.getUL06S().equals(Fase2ResultadoBD.getUL06S())) {
									reportarError(Fase2ResultadoArchivoPlano.getUL06S(),Fase2ResultadoBD.getUL06S(), cabecero[341]);}
								if (!Fase2ResultadoArchivoPlano.getUL21S().equals(Fase2ResultadoBD.getUL21S())) {
									reportarError(Fase2ResultadoArchivoPlano.getUL21S(),Fase2ResultadoBD.getUL21S(), cabecero[342]);}
								if (!Fase2ResultadoArchivoPlano.getUL25S().equals(Fase2ResultadoBD.getUL25S())) {
									reportarError(Fase2ResultadoArchivoPlano.getUL25S(),Fase2ResultadoBD.getUL25S(), cabecero[343]);}
								if (!Fase2ResultadoArchivoPlano.getUL29S().equals(Fase2ResultadoBD.getUL29S())) {
									reportarError(Fase2ResultadoArchivoPlano.getUL29S(),Fase2ResultadoBD.getUL29S(), cabecero[344]);}
								if (!Fase2ResultadoArchivoPlano.getUL30S().equals(Fase2ResultadoBD.getUL30S())) {
									reportarError(Fase2ResultadoArchivoPlano.getUL30S(),Fase2ResultadoBD.getUL30S(), cabecero[345]);}
								if (!Fase2ResultadoArchivoPlano.getUL32S().equals(Fase2ResultadoBD.getUL32S())) {
									reportarError(Fase2ResultadoArchivoPlano.getUL32S(),Fase2ResultadoBD.getUL32S(), cabecero[346]);}
								if (!Fase2ResultadoArchivoPlano.getUL34S().equals(Fase2ResultadoBD.getUL34S())) {
									reportarError(Fase2ResultadoArchivoPlano.getUL34S(),Fase2ResultadoBD.getUL34S(), cabecero[347]);}
								if (!Fase2ResultadoArchivoPlano.getUS25S().equals(Fase2ResultadoBD.getUS25S())) {
									reportarError(Fase2ResultadoArchivoPlano.getUS25S(),Fase2ResultadoBD.getUS25S(), cabecero[348]);}
								if (!Fase2ResultadoArchivoPlano.getWALSHR07().equals(Fase2ResultadoBD.getWALSHR07())) {
									reportarError(Fase2ResultadoArchivoPlano.getWALSHR07(),Fase2ResultadoBD.getWALSHR07(), cabecero[349]);}
								if (!Fase2ResultadoArchivoPlano.getWD21().equals(Fase2ResultadoBD.getWD21())) {
									reportarError(Fase2ResultadoArchivoPlano.getWD21(),Fase2ResultadoBD.getWD21(), cabecero[350]);}
								if (!Fase2ResultadoArchivoPlano.getWD31().equals(Fase2ResultadoBD.getWD31())) {
									reportarError(Fase2ResultadoArchivoPlano.getWD31(),Fase2ResultadoBD.getWD31(), cabecero[351]);}
								if (!Fase2ResultadoArchivoPlano.getWD51().equals(Fase2ResultadoBD.getWD51())) {
									reportarError(Fase2ResultadoArchivoPlano.getWD51(),Fase2ResultadoBD.getWD51(), cabecero[352]);}
								if (!Fase2ResultadoArchivoPlano.getWD61().equals(Fase2ResultadoBD.getWD61())) {
									reportarError(Fase2ResultadoArchivoPlano.getWD61(),Fase2ResultadoBD.getWD61(), cabecero[353]);}
								if (!Fase2ResultadoArchivoPlano.getWD71().equals(Fase2ResultadoBD.getWD71())) {
									reportarError(Fase2ResultadoArchivoPlano.getWD71(),Fase2ResultadoBD.getWD71(), cabecero[354]);}
								if (!Fase2ResultadoArchivoPlano.getWD81().equals(Fase2ResultadoBD.getWD81())) {
									reportarError(Fase2ResultadoArchivoPlano.getWD81(),Fase2ResultadoBD.getWD81(), cabecero[355]);}
								if (!Fase2ResultadoArchivoPlano.getCV_SCORE().equals(Fase2ResultadoBD.getCV_SCORE())) {
									reportarError(Fase2ResultadoArchivoPlano.getCV_SCORE(),Fase2ResultadoBD.getCV_SCORE(), cabecero[356]);}

	
								if (!test) {
									logger.error("Se encontraron errores en la comparacion de datos "
											+ " Consecutivo  " + idTerceroL);
									softAssert.fail("Se encontraron errores en la comparacion de datos  "
											 + " Consecutivo " + idTerceroL);

								}

								else {
									System.out
											.println(linea + " Consecutivo " + idTerceroL);
								}

							} else {

								imprimirReporte("Test_Archivo_",
										"Error en linea--> " + linea + " Consecutivo--> "
												+ Fase1ResultadoArchivoPlano.getConsecutivo() 
											
												+ " No se genero informacion a la consulta en BD\n",
										true);

							}
						
					} else {
						imprimirReporte("Test_Archivo_", "Error! Numero de campos es diferente al establecido, en la linea--> "
								+ linea + " el archivo tiene --> " + data.split("\\|").length + "\n", true);

						softAssert.fail("Numero de campos es diferente al establecido, en la linea--> " + linea
								+ " el archivo tiene --> " + data.split("\\|").length + "\n");
					}
				}
				
				DataBaseUtils.closeConnection();
				imprimirReporte("Test_Archivo_", "Numero de registros analizados "+(linea-1)
						+	" errores encontrados "+ Errores+"\n", true);
				softAssert.assertAll();
				imprimirReporte("Test_Archivo_", "Prueba fue ejecutada sin errores, movimientos analizados--> " + (linea - 1),
						true);
			}
		 
		}	else {
			DataBaseUtils.closeConnection();
			softAssert.fail("Test de estructura no fue aprobado");
			softAssert.assertAll();
		}
	}

	private void reportarError(String ArchivoResultados, String ArchivoResultadosDb, String parametro) {
		String data = linea + "\t"
				+ Fase1ResultadoArchivoPlano.getConsecutivo()
				+ "\t"+"\t" + parametro + "\t"+"\t"+"\t" + ArchivoResultados + "\t"+"\t"+ ArchivoResultadosDb + "\n";
		
		imprimirReporte("Test_Archivo_", data, true);
		//imprimirReporte("Test_Roland_", data, true);
		
		logger.error("Error en la linea--> " + linea 
				+ " IdTercero--> " + Fase1ResultadoArchivoPlano.getConsecutivo() + " Variable " + parametro + " File--> " + ArchivoResultados
				+ " DB--> " + ArchivoResultadosDb);
		test = false;
		Errores++;
	}


	private void imprimirReporte(String prueba, String data, Boolean escribir) {
		BufferedWriter bw = null;
		FileWriter fw = null;

		try {

			File file = new File(origenFile + prueba+fileName);
			// Si el archivo no existe, se crea!
			if (!file.exists()) {
				file.createNewFile();
			}
			// flag true, indica adjuntar información al archivo.
			fw = new FileWriter(file.getAbsoluteFile(), escribir);
			bw = new BufferedWriter(fw);
			bw.write(data);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				// Cierra instancias de FileWriter y BufferedWriter
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	private void consultarBD(String secuencia) throws Exception {
		listaQueries = ReadSqlFile.getQueriesFromFileByTagName("common.sql", "@FaseDosCvBatch" );
		queriesResult1 = executedQueries(listaQueries, secuencia );

	}

	private static List<List<List<String>>> executedQueries(List<String> listaQueries, String secuencia ) throws Exception {
		List<List<List<String>>> queriesResult = new ArrayList<List<List<String>>>();
		List<List<String>> dataFromQueriesList = null;
		int queriesNumbers = listaQueries.size();
		for (int iteration = 0; iteration < queriesNumbers; iteration++) {
			DataBaseUtils.getResultSet(listaQueries.get(iteration).replace("[Secuencia]", secuencia));
			dataFromQueriesList = DataBaseUtils.getDataFromResultset();
			queriesResult.add(dataFromQueriesList);

		}
		return queriesResult;
	}

}