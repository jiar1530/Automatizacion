package transUnion.Skyfall.JavaUtils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.assertj.core.api.SoftAssertions;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import transUnion.Skyfall.javaUtils.DataBaseUtils;

import transUnion.Skyfall.javaUtils.ReadSqlFile;
import transUnion.Skyfall.models.Fase1ResultadoArchivoPlano;
import transUnion.Skyfall.models.Fase1ResultadoBD;




@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PruebaFase1TradesHDComparacion {
	String origenFile = "C:\\Users\\romarti.UNIVERSO\\Automatizacion\\SkyFall\\Archivos_Txt\\test_skyfall\\";
	String fileName = "shape_co_Fase1_trades_hd_2020-11-07.txt";
	SoftAssertions softAssert = new SoftAssertions();
	static Logger logger = Logger.getLogger(PruebaFase1TradesHDComparacion.class);
	static boolean testEstructura;
	static boolean test = true;
	static String[] cabecero = { "SECUENCIA","AGG2401",  "AGG2402",  "AGG2403",  "AGG2404",  "AGG2405",  "AGG2406",  "AGG2407",  "AGG2408",  "AGG2409 ","AGG2410",  "AGG2411",
			"AGG2412",  "AGG2413",  "AGG2414",  "AGG2415",  "AGG2416",  "AGG2417",  "AGG2418",  "AGG2419",  "AGG2420",  "AGG2421", 
			"AGG2422",  "AGG2423",  "AGG2424",  "AGG301",  "AGG302",  "AGG303",  "AGG304",  "AGG305",  "AGG306",  "AGG307",  "AGG308",  "AGG309",
			"AGG310",  "AGG311",  "AGG312",  "AGG313",  "AGG314",  "AGG315",  "AGG316",  "AGG317",  "AGG318",  "AGG319",  "AGG320",  "AGG321",  
			"AGG322",  "AGG323",  "AGG324",  "AGG905",  "AGG906",  "AT34A",    "BI34S",  "BKC112",  "BKC225",    "BR27S",  "BR29S",
			"BR34S",  "BU09S",  "CA09S",  "CA70S",  "CO04SF",  "CT24S",  "CT30S",  "CT31S",  "DM211S",  "DM214S",  "FR29S",  "FR34S",  "FS20S", 
			"G212SF",  "G218BF",  "G220A",  "G221D",  "G306S",  "G410S",  "IN01S",  "IN34S",  "LL09S",  "LL30S",  "LMD30S",  "LS29S",  "LS30S",
			"LS34S",  "OD34S",  "OF06S",  "OF09S",  "PAYMNT50",  "PAYMNT65",  "PER201",  "PER223",  "PER233",  "PT09S",  "PT30S",  "RET13",  "RET152",  
			"RET201",  "RET81",  "REV14",  "REV253",  "RI06S",  "RLE907",  "RR21S",  "RR24S",  "RR25S",  "RT21S",  "RT24S",  "RVLR09",  "SE09S",  "TEL09S",  "TEL21S", 
			"TEL30S",  "TRD",  "TRV03",  "TRV12",  "UL_TRD",  "UL29S",  "UL34S",   "WD21",  "WD31",  "WD51",  "WD61",  "WD81","CV_SCORE"   
};
	static List<String> listaQueries;
	static List<List<List<String>>> queriesResult1;

	private int linea = 0;
	int Errores=0;
	@Test
	public void test1Estructura() throws Exception {
		Errores = 0;
		System.out.println(origenFile+fileName);
		try (BufferedReader buffReader = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(new FileInputStream(origenFile + fileName)),
				"UTF-8"))) {
			String data;
			String dataReading = null;
			this.linea = 1;
			PruebaFase1TradesHDComparacion.testEstructura=true;
			imprimirReporte("Prueba_Estructura_", "DETALLE ERROR|"
					+ Arrays.toString(cabecero).replace(",", "|").replace("[", "").replace("]", "").replace(" ", "")
					+ "\n", false);
			while ((data = buffReader.readLine()) != null) {
				PruebaFase1TradesHDComparacion.test = true;

				dataReading = data;

				if (dataReading.endsWith("|")) {
					dataReading = dataReading.replace("|", "|-");
				}
				if (linea == 1 && (!dataReading.equals(Arrays.toString(cabecero).replace(",", "|").replace("[", "")
						.replace("]", "").replace(" ", "")))) {
					imprimirReporte("Prueba_Estructura_", "Error en el nombrado de campos\n", true);
					PruebaFase1TradesHDComparacion.testEstructura = false;
					test = false;
				}
				if (linea != 1 && (dataReading.split("\\|").length != 124)) {
					imprimirReporte("Prueba_Estructura_",
							"Numero de campos es diferente al establecido, en la linea--> " + linea
									+ " el archivo tiene --> " + dataReading.split("\\|").length + " campos|" + data + "\n",
							true);
					//PruebaFase1TradesComparacion.testEstructura = false;
					test=false;
				}
		


				if (!test) {
					logger.error("Se encontraron errores en la comparacion en la linea--> " + linea);
					softAssert.fail("Se encontraron errores en la comparacion en la linea--> " + linea);

Errores++;
				}
				else {
					logger.info("Linea --> " + linea + " ok");

				}
				this.linea++;
			}
			imprimirReporte("Prueba_Estructura_", "Numero de registros analizados "+(linea-1)
				+	" errores encontrados "+ Errores+"\n", true);
			softAssert.assertAll();
			imprimirReporte("Prueba_Estructura_", "Prueba ejecutada sin errores\n", true);
		}
	}

	@Test
	public void test2pruebaArchivo() throws Exception {
		
		String idTerceroL = "";	
		Errores=0;
		this.linea = 1;
		imprimirReporte("Test_Archivo_", "", false);
		if (true/*PruebaFase1TradesHDComparacion.testEstructura*/) {
			try (BufferedReader buffReader = new BufferedReader(new InputStreamReader(
					new BufferedInputStream(new FileInputStream(origenFile + fileName)),
					"UTF-8"))) {
				String data;
				buffReader.readLine();
		
				imprimirReporte("Test_Archivo_", "Linea\tSec_ter\t\tVariable\tInfo_Archivo\t\tInfo_BD\n", true);
				DataBaseUtils.getDefaultConnection();
				while ((data = buffReader.readLine()) != null) {
					this.linea++;
					if (data.endsWith("|")) {
						data = data + " |";
					}
					test = true;
					if (data.split("\\|").length == 124) {
						//archivo plano set
						Fase1ResultadoArchivoPlano.setDatosArchivoPlano(data);
				
						consultarBD(Fase1ResultadoArchivoPlano.getConsecutivo());
						idTerceroL = Fase1ResultadoArchivoPlano.getConsecutivo();
						
							if (queriesResult1.get(0).size() != 0) {
										//query set
								Fase1ResultadoBD.setDatosBD(queriesResult1.get(0).get(0));

								if (!Fase1ResultadoArchivoPlano.getAGG2401()
										.equals(Fase1ResultadoBD.getAGG2401())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2401(),
											Fase1ResultadoBD.getAGG2401(), cabecero[1]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2402()
										.equals(Fase1ResultadoBD.getAGG2402())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2402(),
											Fase1ResultadoBD.getAGG2402(), cabecero[2]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2403()
										.equals(Fase1ResultadoBD.getAGG2403())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2403(),
											Fase1ResultadoBD.getAGG2403(), cabecero[3]);

								}
							
										if (!Fase1ResultadoArchivoPlano.getAGG2404()
										.equals(Fase1ResultadoBD.getAGG2404())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2404(),
											Fase1ResultadoBD.getAGG2404(), cabecero[4]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2405()
										.equals(Fase1ResultadoBD.getAGG2405())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2405(),
											Fase1ResultadoBD.getAGG2405(), cabecero[5]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2406()
										.equals(Fase1ResultadoBD.getAGG2406())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2406(),
											Fase1ResultadoBD.getAGG2406(), cabecero[6]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2407()
										.equals(Fase1ResultadoBD.getAGG2407())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2407(),
											Fase1ResultadoBD.getAGG2407(), cabecero[7]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2408()
										.equals(Fase1ResultadoBD.getAGG2408())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2408(),
											Fase1ResultadoBD.getAGG2408(), cabecero[8]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2409()
										.equals(Fase1ResultadoBD.getAGG2409())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2409(),
											Fase1ResultadoBD.getAGG2409(), cabecero[9]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2410()
										.equals(Fase1ResultadoBD.getAGG2410())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2410(),
											Fase1ResultadoBD.getAGG2410(), cabecero[10]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2411()
										.equals(Fase1ResultadoBD.getAGG2411())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2411(),
											Fase1ResultadoBD.getAGG2411(), cabecero[11]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2412()
										.equals(Fase1ResultadoBD.getAGG2412())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2412(),
											Fase1ResultadoBD.getAGG2412(), cabecero[12]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2413()
										.equals(Fase1ResultadoBD.getAGG2413())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2413(),
											Fase1ResultadoBD.getAGG2413(), cabecero[13]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2414()
										.equals(Fase1ResultadoBD.getAGG2414())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2414(),
											Fase1ResultadoBD.getAGG2414(), cabecero[14]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2415()
										.equals(Fase1ResultadoBD.getAGG2415())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2415(),
											Fase1ResultadoBD.getAGG2415(), cabecero[15]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2416()
										.equals(Fase1ResultadoBD.getAGG2416())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2416(),
											Fase1ResultadoBD.getAGG2416(), cabecero[16]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2417()
										.equals(Fase1ResultadoBD.getAGG2417())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2417(),
											Fase1ResultadoBD.getAGG2417(), cabecero[17]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2418()
										.equals(Fase1ResultadoBD.getAGG2418())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2418(),
											Fase1ResultadoBD.getAGG2418(), cabecero[18]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2419()
										.equals(Fase1ResultadoBD.getAGG2419())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2419(),
											Fase1ResultadoBD.getAGG2419(), cabecero[19]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2420()
										.equals(Fase1ResultadoBD.getAGG2420())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2420(),
											Fase1ResultadoBD.getAGG2420(), cabecero[20]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2421()
										.equals(Fase1ResultadoBD.getAGG2421())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2421(),
											Fase1ResultadoBD.getAGG2421(), cabecero[21]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2422()
										.equals(Fase1ResultadoBD.getAGG2422())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2422(),
											Fase1ResultadoBD.getAGG2422(), cabecero[22]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2423()
										.equals(Fase1ResultadoBD.getAGG2423())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2423(),
											Fase1ResultadoBD.getAGG2423(), cabecero[23]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG2424()
										.equals(Fase1ResultadoBD.getAGG2424())) {
									reportarError(Fase1ResultadoArchivoPlano.getAGG2424(),
											Fase1ResultadoBD.getAGG2424(), cabecero[24]);

								}
										if (!Fase1ResultadoArchivoPlano.getAGG301()
												.equals(Fase1ResultadoBD.getAGG301())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG301(),
													Fase1ResultadoBD.getAGG301(), cabecero[25]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG302()
												.equals(Fase1ResultadoBD.getAGG302())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG302(),
													Fase1ResultadoBD.getAGG302(), cabecero[26]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG303()
												.equals(Fase1ResultadoBD.getAGG303())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG303(),
													Fase1ResultadoBD.getAGG303(), cabecero[27]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG304()
												.equals(Fase1ResultadoBD.getAGG304())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG304(),
													Fase1ResultadoBD.getAGG304(), cabecero[28]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG305()
												.equals(Fase1ResultadoBD.getAGG305())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG305(),
													Fase1ResultadoBD.getAGG305(), cabecero[29]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG306()
												.equals(Fase1ResultadoBD.getAGG306())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG306(),
													Fase1ResultadoBD.getAGG306(), cabecero[30]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG307()
												.equals(Fase1ResultadoBD.getAGG307())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG307(),
													Fase1ResultadoBD.getAGG307(), cabecero[31]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG308()
												.equals(Fase1ResultadoBD.getAGG308())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG308(),
													Fase1ResultadoBD.getAGG308(), cabecero[32]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG309()
												.equals(Fase1ResultadoBD.getAGG309())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG309(),
													Fase1ResultadoBD.getAGG309(), cabecero[33]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG310()
												.equals(Fase1ResultadoBD.getAGG310())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG310(),
													Fase1ResultadoBD.getAGG310(), cabecero[34]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG311()
												.equals(Fase1ResultadoBD.getAGG311())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG311(),
													Fase1ResultadoBD.getAGG311(), cabecero[35]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG312()
												.equals(Fase1ResultadoBD.getAGG312())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG312(),
													Fase1ResultadoBD.getAGG312(), cabecero[36]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG313()
												.equals(Fase1ResultadoBD.getAGG313())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG313(),
													Fase1ResultadoBD.getAGG313(), cabecero[37]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG314()
												.equals(Fase1ResultadoBD.getAGG314())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG314(),
													Fase1ResultadoBD.getAGG314(), cabecero[38]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG315()
												.equals(Fase1ResultadoBD.getAGG315())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG315(),
													Fase1ResultadoBD.getAGG315(), cabecero[39]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG316()
												.equals(Fase1ResultadoBD.getAGG316())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG316(),
													Fase1ResultadoBD.getAGG316(), cabecero[40]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG317()
												.equals(Fase1ResultadoBD.getAGG317())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG317(),
													Fase1ResultadoBD.getAGG317(), cabecero[41]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG318()
												.equals(Fase1ResultadoBD.getAGG318())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG318(),
													Fase1ResultadoBD.getAGG318(), cabecero[42]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG319()
												.equals(Fase1ResultadoBD.getAGG319())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG319(),
													Fase1ResultadoBD.getAGG319(), cabecero[43]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG320()
												.equals(Fase1ResultadoBD.getAGG320())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG320(),
													Fase1ResultadoBD.getAGG320(), cabecero[44]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG321()
												.equals(Fase1ResultadoBD.getAGG321())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG321(),
													Fase1ResultadoBD.getAGG321(), cabecero[45]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG322()
												.equals(Fase1ResultadoBD.getAGG322())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG322(),
													Fase1ResultadoBD.getAGG322(), cabecero[46]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG323()
												.equals(Fase1ResultadoBD.getAGG323())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG323(),
													Fase1ResultadoBD.getAGG323(), cabecero[47]);

										}
												if (!Fase1ResultadoArchivoPlano.getAGG324()
												.equals(Fase1ResultadoBD.getAGG324())) {
											reportarError(Fase1ResultadoArchivoPlano.getAGG324(),
													Fase1ResultadoBD.getAGG324(), cabecero[48]);

										}
												
											if (!Fase1ResultadoArchivoPlano.getAGG905()
														.equals(Fase1ResultadoBD.getAGG905())) {
													reportarError(Fase1ResultadoArchivoPlano.getAGG905(),
															Fase1ResultadoBD.getAGG905(), cabecero[49]);

												}
											if (!Fase1ResultadoArchivoPlano.getAGG906()
														.equals(Fase1ResultadoBD.getAGG906())) {
													reportarError(Fase1ResultadoArchivoPlano.getAGG906(),
															Fase1ResultadoBD.getAGG906(), cabecero[50]);

												}	
												
											if (!Fase1ResultadoArchivoPlano.getAT34A()
													.equals(Fase1ResultadoBD.getAT34A())) {
												reportarError(Fase1ResultadoArchivoPlano.getAT34A(),
														Fase1ResultadoBD.getAT34A(), cabecero[51]);

											}
	
											if (!Fase1ResultadoArchivoPlano.getBI34S()
													.equals(Fase1ResultadoBD.getBI34S())) {
												reportarError(Fase1ResultadoArchivoPlano.getBI34S(),
														Fase1ResultadoBD.getBI34S(), cabecero[52]);

											}
											
											if (!Fase1ResultadoArchivoPlano.getBKC112()
													.equals(Fase1ResultadoBD.getBKC112())) {
												reportarError(Fase1ResultadoArchivoPlano.getBKC112(),
														Fase1ResultadoBD.getBKC112(), cabecero[53]);

											}
											if (!Fase1ResultadoArchivoPlano.getBKC225()
													.equals(Fase1ResultadoBD.getBKC225())) {
												reportarError(Fase1ResultadoArchivoPlano.getBKC225(),
														Fase1ResultadoBD.getBKC225(), cabecero[54]);

											}

										
											if (!Fase1ResultadoArchivoPlano.getBR27S()
													.equals(Fase1ResultadoBD.getBR27S())) {
												reportarError(Fase1ResultadoArchivoPlano.getBR27S(),
														Fase1ResultadoBD.getBR27S(), cabecero[55]);

											}
										
											if (!Fase1ResultadoArchivoPlano.getBR29S()
													.equals(Fase1ResultadoBD.getBR29S())) {
												reportarError(Fase1ResultadoArchivoPlano.getBR29S(),
														Fase1ResultadoBD.getBR29S(), cabecero[56]);

											}
											if (!Fase1ResultadoArchivoPlano.getBR34S()
													.equals(Fase1ResultadoBD.getBR34S())) {
												reportarError(Fase1ResultadoArchivoPlano.getBR34S(),
														Fase1ResultadoBD.getBR34S(), cabecero[57]);

											}
											if (!Fase1ResultadoArchivoPlano.getBU09S()
													.equals(Fase1ResultadoBD.getBU09S())) {
												reportarError(Fase1ResultadoArchivoPlano.getBU09S(),
														Fase1ResultadoBD.getBU09S(), cabecero[58]);

											}
											if (!Fase1ResultadoArchivoPlano.getCA09S()
													.equals(Fase1ResultadoBD.getCA09S())) {
												reportarError(Fase1ResultadoArchivoPlano.getCA09S(),
														Fase1ResultadoBD.getCA09S(), cabecero[59]);

											}
											if (!Fase1ResultadoArchivoPlano.getCA70S()
													.equals(Fase1ResultadoBD.getCA70S())) {
												reportarError(Fase1ResultadoArchivoPlano.getCA70S(),
														Fase1ResultadoBD.getCA70S(), cabecero[60]);

											}
											
											if (!Fase1ResultadoArchivoPlano.getCO04SF()
													.equals(Fase1ResultadoBD.getCO04SF())) {
												reportarError(Fase1ResultadoArchivoPlano.getCO04SF(),
														Fase1ResultadoBD.getCO04SF(), cabecero[61]);

											}
											
											if (!Fase1ResultadoArchivoPlano.getCT24S()
													.equals(Fase1ResultadoBD.getCT24S())) {
												reportarError(Fase1ResultadoArchivoPlano.getCT24S(),
														Fase1ResultadoBD.getCT24S(), cabecero[62]);

											}
											
											if (!Fase1ResultadoArchivoPlano.getCT30S()
													.equals(Fase1ResultadoBD.getCT30S())) {
												reportarError(Fase1ResultadoArchivoPlano.getCT30S(),
														Fase1ResultadoBD.getCT30S(), cabecero[63]);

											}
											
											if (!Fase1ResultadoArchivoPlano.getCT31S()
													.equals(Fase1ResultadoBD.getCT31S())) {
												reportarError(Fase1ResultadoArchivoPlano.getCT31S(),
														Fase1ResultadoBD.getCT31S(), cabecero[64]);

											}
											if (!Fase1ResultadoArchivoPlano.getDM211S()
													.equals(Fase1ResultadoBD.getDM211S())) {
												reportarError(Fase1ResultadoArchivoPlano.getDM211S(),
														Fase1ResultadoBD.getDM211S(), cabecero[65]);

											}
											if (!Fase1ResultadoArchivoPlano.getDM214S()
													.equals(Fase1ResultadoBD.getDM214S())) {
												reportarError(Fase1ResultadoArchivoPlano.getDM214S(),
														Fase1ResultadoBD.getDM214S(), cabecero[66]);

											}
												
											if (!Fase1ResultadoArchivoPlano.getFR29S()
													.equals(Fase1ResultadoBD.getFR29S())) {
												reportarError(Fase1ResultadoArchivoPlano.getFR29S(),
														Fase1ResultadoBD.getFR29S(), cabecero[67]);

											}
											
											if (!Fase1ResultadoArchivoPlano.getFR34S()
													.equals(Fase1ResultadoBD.getFR34S())) {
												reportarError(Fase1ResultadoArchivoPlano.getFR34S(),
														Fase1ResultadoBD.getFR34S(), cabecero[68]);

											}
													
											if (!Fase1ResultadoArchivoPlano.getFS20S()
													.equals(Fase1ResultadoBD.getFS20S())) {
												reportarError(Fase1ResultadoArchivoPlano.getFS20S(),
														Fase1ResultadoBD.getFS20S(), cabecero[69]);

											}		
											if (!Fase1ResultadoArchivoPlano.getG212SF()
													.equals(Fase1ResultadoBD.getG212SF())) {
												reportarError(Fase1ResultadoArchivoPlano.getG212SF(),
														Fase1ResultadoBD.getG212SF(), cabecero[70]);

											}
													if (!Fase1ResultadoArchivoPlano.getG218BF()
													.equals(Fase1ResultadoBD.getG218BF())) {
												reportarError(Fase1ResultadoArchivoPlano.getG218BF(),
														Fase1ResultadoBD.getG218BF(), cabecero[71]);

											}
											
											if (!Fase1ResultadoArchivoPlano.getG220A()
															.equals(Fase1ResultadoBD.getG220A())) {
														reportarError(Fase1ResultadoArchivoPlano.getG220A(),
																Fase1ResultadoBD.getG220A(), cabecero[72]);

													}		
													
											if (!Fase1ResultadoArchivoPlano.getG221D()
															.equals(Fase1ResultadoBD.getG221D())) {
														reportarError(Fase1ResultadoArchivoPlano.getG221D(),
																Fase1ResultadoBD.getG221D(), cabecero[73]);

													}									
													
											if (!Fase1ResultadoArchivoPlano.getG306S()
													.equals(Fase1ResultadoBD.getG306S())) {
												reportarError(Fase1ResultadoArchivoPlano.getG306S(),
														Fase1ResultadoBD.getG306S(), cabecero[74]);

											}		
													
											if (!Fase1ResultadoArchivoPlano.getG410S()
													.equals(Fase1ResultadoBD.getG410S())) {
												reportarError(Fase1ResultadoArchivoPlano.getG410S(),
														Fase1ResultadoBD.getG410S(), cabecero[75]);

											}		
											
											if (!Fase1ResultadoArchivoPlano.getIN01S()
													.equals(Fase1ResultadoBD.getIN01S())) {
												reportarError(Fase1ResultadoArchivoPlano.getIN01S(),
														Fase1ResultadoBD.getIN01S(), cabecero[76]);

											}
											if (!Fase1ResultadoArchivoPlano.getIN34S()
													.equals(Fase1ResultadoBD.getIN34S())) {
												reportarError(Fase1ResultadoArchivoPlano.getIN34S(),
														Fase1ResultadoBD.getIN34S(), cabecero[77]);

											}
											if (!Fase1ResultadoArchivoPlano.getLL09S()
													.equals(Fase1ResultadoBD.getLL09S())) {
												reportarError(Fase1ResultadoArchivoPlano.getLL09S(),
														Fase1ResultadoBD.getLL09S(), cabecero[78]);

											}
													if (!Fase1ResultadoArchivoPlano.getLL30S()
													.equals(Fase1ResultadoBD.getLL30S())) {
												reportarError(Fase1ResultadoArchivoPlano.getLL30S(),
														Fase1ResultadoBD.getLL30S(), cabecero[79]);

											}
													if (!Fase1ResultadoArchivoPlano.getLMD30S()
													.equals(Fase1ResultadoBD.getLMD30S())) {
												reportarError(Fase1ResultadoArchivoPlano.getLMD30S(),
														Fase1ResultadoBD.getLMD30S(), cabecero[80]);

											}
											
													if (!Fase1ResultadoArchivoPlano.getLS29S()
															.equals(Fase1ResultadoBD.getLS29S())) {
														reportarError(Fase1ResultadoArchivoPlano.getLS29S(),
																Fase1ResultadoBD.getLS29S(), cabecero[81]);

													}
												
															if (!Fase1ResultadoArchivoPlano.getLS30S()
															.equals(Fase1ResultadoBD.getLS30S())) {
														reportarError(Fase1ResultadoArchivoPlano.getLS30S(),
																Fase1ResultadoBD.getLS30S(), cabecero[82]);

													}		

													
													if (!Fase1ResultadoArchivoPlano.getLS34S()
													.equals(Fase1ResultadoBD.getLS34S())) {
												reportarError(Fase1ResultadoArchivoPlano.getLS34S(),
														Fase1ResultadoBD.getLS34S(), cabecero[83]);

											}
											if (!Fase1ResultadoArchivoPlano.getOD34S()
															.equals(Fase1ResultadoBD.getOD34S())) {
														reportarError(Fase1ResultadoArchivoPlano.getOD34S(),
																Fase1ResultadoBD.getOD34S(), cabecero[84]);

													}		
													
											if (!Fase1ResultadoArchivoPlano.getOF06S()
													.equals(Fase1ResultadoBD.getOF06S())) {
												reportarError(Fase1ResultadoArchivoPlano.getOF06S(),
														Fase1ResultadoBD.getOF06S(), cabecero[85]);

											}	
											if (!Fase1ResultadoArchivoPlano.getOF09S()
													.equals(Fase1ResultadoBD.getOF09S())) {
												reportarError(Fase1ResultadoArchivoPlano.getOF09S(),
														Fase1ResultadoBD.getOF09S(), cabecero[86]);

											}			
											if (!Fase1ResultadoArchivoPlano.getPAYMNT50()
													.equals(Fase1ResultadoBD.getPAYMNT50())) {
												reportarError(Fase1ResultadoArchivoPlano.getPAYMNT50(),
														Fase1ResultadoBD.getPAYMNT50(), cabecero[87]);

											}
													if (!Fase1ResultadoArchivoPlano.getPAYMNT65()
													.equals(Fase1ResultadoBD.getPAYMNT65())) {
												reportarError(Fase1ResultadoArchivoPlano.getPAYMNT65(),
														Fase1ResultadoBD.getPAYMNT65(), cabecero[88]);

											}
													if (!Fase1ResultadoArchivoPlano.getPER201()
															.equals(Fase1ResultadoBD.getPER201())) {
														reportarError(Fase1ResultadoArchivoPlano.getPER201(),
																Fase1ResultadoBD.getPER201(), cabecero[89]);

													}
													
													if (!Fase1ResultadoArchivoPlano.getPER223()
															.equals(Fase1ResultadoBD.getPER223())) {
														reportarError(Fase1ResultadoArchivoPlano.getPER223(),
																Fase1ResultadoBD.getPER223(), cabecero[90]);

													}
		
													if (!Fase1ResultadoArchivoPlano.getPER233()
													.equals(Fase1ResultadoBD.getPER233())) {
												reportarError(Fase1ResultadoArchivoPlano.getPER233(),
														Fase1ResultadoBD.getPER233(), cabecero[91]);

											}		
											
													if (!Fase1ResultadoArchivoPlano.getPT09S()
															.equals(Fase1ResultadoBD.getPT09S())) {
														reportarError(Fase1ResultadoArchivoPlano.getPT09S(),
																Fase1ResultadoBD.getPT09S(), cabecero[92]);

													}
															if (!Fase1ResultadoArchivoPlano.getPT30S()
															.equals(Fase1ResultadoBD.getPT30S())) {
														reportarError(Fase1ResultadoArchivoPlano.getPT30S(),
																Fase1ResultadoBD.getPT30S(), cabecero[93]);

													}
													
															if (!Fase1ResultadoArchivoPlano.getRET13()
																	.equals(Fase1ResultadoBD.getRET13())) {
																reportarError(Fase1ResultadoArchivoPlano.getRET13(),
																		Fase1ResultadoBD.getRET13(), cabecero[94]);

															}
															if (!Fase1ResultadoArchivoPlano.getRET152()
																	.equals(Fase1ResultadoBD.getRET152())) {
																reportarError(Fase1ResultadoArchivoPlano.getRET152(),
																		Fase1ResultadoBD.getRET152(), cabecero[95]);

															}
																	if (!Fase1ResultadoArchivoPlano.getRET201()
																	.equals(Fase1ResultadoBD.getRET201())) {
																reportarError(Fase1ResultadoArchivoPlano.getRET201(),
																		Fase1ResultadoBD.getRET201(), cabecero[96]);

															}
																	if (!Fase1ResultadoArchivoPlano.getRET81()
																	.equals(Fase1ResultadoBD.getRET81())) {
																reportarError(Fase1ResultadoArchivoPlano.getRET81(),
																		Fase1ResultadoBD.getRET81(), cabecero[97]);

															}
															
																	if (!Fase1ResultadoArchivoPlano.getREV14()
																			.equals(Fase1ResultadoBD.getREV14())) {
																		reportarError(Fase1ResultadoArchivoPlano.getREV14(),
																				Fase1ResultadoBD.getREV14(), cabecero[98]);

																	}
																	if (!Fase1ResultadoArchivoPlano.getREV253()
																	.equals(Fase1ResultadoBD.getREV253())) {
																reportarError(Fase1ResultadoArchivoPlano.getREV253(),
																		Fase1ResultadoBD.getREV253(), cabecero[99]);

																	}

																if (!Fase1ResultadoArchivoPlano.getRI06S()
																			.equals(Fase1ResultadoBD.getRI06S())) {
																		reportarError(Fase1ResultadoArchivoPlano.getRI06S(),
																				Fase1ResultadoBD.getRI06S(), cabecero[100]);

																	}
													
																if (!Fase1ResultadoArchivoPlano.getRLE907()
																		.equals(Fase1ResultadoBD.getRLE907())) {
																	reportarError(Fase1ResultadoArchivoPlano.getRLE907(),
																			Fase1ResultadoBD.getRLE907(), cabecero[101]);

																}
																if (!Fase1ResultadoArchivoPlano.getRR21S()
																		.equals(Fase1ResultadoBD.getRR21S())) {
																	reportarError(Fase1ResultadoArchivoPlano.getRR21S(),
																			Fase1ResultadoBD.getRR21S(), cabecero[102]);

																}
																if (!Fase1ResultadoArchivoPlano.getRR24S()
																		.equals(Fase1ResultadoBD.getRR24S())) {
																	reportarError(Fase1ResultadoArchivoPlano.getRR24S(),
																			Fase1ResultadoBD.getRR24S(), cabecero[103]);

																}
																if (!Fase1ResultadoArchivoPlano.getRR25S()
																		.equals(Fase1ResultadoBD.getRR25S())) {
																	reportarError(Fase1ResultadoArchivoPlano.getRR25S(),
																			Fase1ResultadoBD.getRR25S(), cabecero[104]);

																}
																if (!Fase1ResultadoArchivoPlano.getRT21S()
																		.equals(Fase1ResultadoBD.getRT21S())) {
																	reportarError(Fase1ResultadoArchivoPlano.getRT21S(),
																			Fase1ResultadoBD.getRT21S(), cabecero[105]);

																}
																if (!Fase1ResultadoArchivoPlano.getRT24S()
																		.equals(Fase1ResultadoBD.getRT24S())) {
																	reportarError(Fase1ResultadoArchivoPlano.getRT24S(),
																			Fase1ResultadoBD.getRT24S(), cabecero[106]);

																}
																if (!Fase1ResultadoArchivoPlano.getRVLR09()
																		.equals(Fase1ResultadoBD.getRVLR09())) {
																	reportarError(Fase1ResultadoArchivoPlano.getRVLR09(),
																			Fase1ResultadoBD.getRVLR09(), cabecero[107]);

																}
																if (!Fase1ResultadoArchivoPlano.getSE09S()
																		.equals(Fase1ResultadoBD.getSE09S())) {
																	reportarError(Fase1ResultadoArchivoPlano.getSE09S(),
																			Fase1ResultadoBD.getSE09S(), cabecero[108]);

																}
																if (!Fase1ResultadoArchivoPlano.getTEL09S()
																		.equals(Fase1ResultadoBD.getTEL09S())) {
																	reportarError(Fase1ResultadoArchivoPlano.getTEL09S(),
																			Fase1ResultadoBD.getTEL09S(), cabecero[109]);

																}
																if (!Fase1ResultadoArchivoPlano.getTEL21S()
																		.equals(Fase1ResultadoBD.getTEL21S())) {
																	reportarError(Fase1ResultadoArchivoPlano.getTEL21S(),
																			Fase1ResultadoBD.getTEL21S(), cabecero[110]);

																}
																if (!Fase1ResultadoArchivoPlano.getTEL30S()
																		.equals(Fase1ResultadoBD.getTEL30S())) {
																	reportarError(Fase1ResultadoArchivoPlano.getTEL30S(),
																			Fase1ResultadoBD.getTEL30S(), cabecero[111]);

																}
																if (!Fase1ResultadoArchivoPlano.getTRD()
																		.equals(Fase1ResultadoBD.getTRD())) {
																	reportarError(Fase1ResultadoArchivoPlano.getTRD(),
																			Fase1ResultadoBD.getTRD(), cabecero[112]);

																}
																if (!Fase1ResultadoArchivoPlano.getTRV03()
																		.equals(Fase1ResultadoBD.getTRV03())) {
																	reportarError(Fase1ResultadoArchivoPlano.getTRV03(),
																			Fase1ResultadoBD.getTRV03(), cabecero[113]);

																}
																if (!Fase1ResultadoArchivoPlano.getTRV12()
																		.equals(Fase1ResultadoBD.getTRV12())) {
																	reportarError(Fase1ResultadoArchivoPlano.getTRV12(),
																			Fase1ResultadoBD.getTRV12(), cabecero[114]);

																}
																if (!Fase1ResultadoArchivoPlano.getUL_TRD()
																		.equals(Fase1ResultadoBD.getUL_TRD())) {
																	reportarError(Fase1ResultadoArchivoPlano.getUL_TRD(),
																			Fase1ResultadoBD.getUL_TRD(), cabecero[115]);

																}
																if (!Fase1ResultadoArchivoPlano.getUL29S()
																		.equals(Fase1ResultadoBD.getUL29S())) {
																	reportarError(Fase1ResultadoArchivoPlano.getUL29S(),
																			Fase1ResultadoBD.getUL29S(), cabecero[116]);

																}
																if (!Fase1ResultadoArchivoPlano.getUL34S()
																		.equals(Fase1ResultadoBD.getUL34S())) {
																	reportarError(Fase1ResultadoArchivoPlano.getUL34S(),
																			Fase1ResultadoBD.getUL34S(), cabecero[117]);

																}
																if (!Fase1ResultadoArchivoPlano.getWD21()
																		.equals(Fase1ResultadoBD.getWD21())) {
																	reportarError(Fase1ResultadoArchivoPlano.getWD21(),
																			Fase1ResultadoBD.getWD21(), cabecero[118]);

																}
																if (!Fase1ResultadoArchivoPlano.getWD31()
																		.equals(Fase1ResultadoBD.getWD31())) {
																	reportarError(Fase1ResultadoArchivoPlano.getWD31(),
																			Fase1ResultadoBD.getWD31(), cabecero[119]);

																}
															
																		if (!Fase1ResultadoArchivoPlano.getWD51()
																		.equals(Fase1ResultadoBD.getWD51())) {
																	reportarError(Fase1ResultadoArchivoPlano.getWD51(),
																			Fase1ResultadoBD.getWD51(), cabecero[120]);

																}
																		if (!Fase1ResultadoArchivoPlano.getWD61()
																				.equals(Fase1ResultadoBD.getWD61())) {
																			reportarError(Fase1ResultadoArchivoPlano.getWD61(),
																					Fase1ResultadoBD.getWD61(), cabecero[121]);

																		}
																				if (!Fase1ResultadoArchivoPlano.getWD81()
																				.equals(Fase1ResultadoBD.getWD81())) {
																			reportarError(Fase1ResultadoArchivoPlano.getWD81(),
																					Fase1ResultadoBD.getWD81(), cabecero[122]);

																		}
																				
																				if (!Fase1ResultadoArchivoPlano.getCV_Score()
																						.equals(Fase1ResultadoBD.getCV_Score())) {
																					reportarError(Fase1ResultadoArchivoPlano.getCV_Score(),
																							Fase1ResultadoBD.getCV_Score(), cabecero[123]);

																				}


	
								if (!test) {
									logger.error("Se encontraron errores en la comparacion de datos "
											+ " Consecutivo  " + idTerceroL);
									softAssert.fail("Se encontraron errores en la comparacion de datos  "
											 + " Consecutivo " + idTerceroL);

								}

								else {
									System.out
											.println(linea + " Consecutivo " + idTerceroL);
								}

							} else {

								imprimirReporte("Test_Archivo_",
										"Error en linea--> " + linea + " Consecutivo--> "
												+ Fase1ResultadoArchivoPlano.getConsecutivo() 
											
												+ " No se genero informacion a la consulta en BD\n",
										true);

							}
						
					} else {
						imprimirReporte("Test_Archivo_", "Error! Numero de campos es diferente al establecido, en la linea--> "
								+ linea + " el archivo tiene --> " + data.split("\\|").length + "\n", true);

						softAssert.fail("Numero de campos es diferente al establecido, en la linea--> " + linea
								+ " el archivo tiene --> " + data.split("\\|").length + "\n");
					}
				}
				
				DataBaseUtils.closeConnection();
				imprimirReporte("Test_Archivo_", "Numero de registros analizados "+(linea-1)
						+	" errores encontrados "+ Errores+"\n", true);
				softAssert.assertAll();
				imprimirReporte("Test_Archivo_", "Prueba fue ejecutada sin errores, movimientos analizados--> " + (linea - 1),
						true);
			}
		 
		}	else {
			DataBaseUtils.closeConnection();
			softAssert.fail("Test de estructura no fue aprobado");
			softAssert.assertAll();
		}
	}

	private void reportarError(String ArchivoResultados, String ArchivoResultadosDb, String parametro) {
		String data = linea + "\t"
				+ Fase1ResultadoArchivoPlano.getConsecutivo()
				+ "\t"+"\t" + parametro + "\t"+"\t"+"\t" + ArchivoResultados + "\t"+"\t"+ ArchivoResultadosDb + "\n";
		
		imprimirReporte("Test_Archivo_", data, true);
		//imprimirReporte("Test_Roland_", data, true);
		
		logger.error("Error en la linea--> " + linea 
				+ " IdTercero--> " + Fase1ResultadoArchivoPlano.getConsecutivo() + " Variable " + parametro + " File--> " + ArchivoResultados
				+ " DB--> " + ArchivoResultadosDb);
		test = false;
		Errores++;
	}


	private void imprimirReporte(String prueba, String data, Boolean escribir) {
		BufferedWriter bw = null;
		FileWriter fw = null;

		try {

			File file = new File(origenFile + prueba+fileName);
			// Si el archivo no existe, se crea!
			if (!file.exists()) {
				file.createNewFile();
			}
			// flag true, indica adjuntar información al archivo.
			fw = new FileWriter(file.getAbsoluteFile(), escribir);
			bw = new BufferedWriter(fw);
			bw.write(data);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				// Cierra instancias de FileWriter y BufferedWriter
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	private void consultarBD(String secuencia) throws Exception {
		listaQueries = ReadSqlFile.getQueriesFromFileByTagName("common.sql", "@FaseUnoCvBatch" );
		queriesResult1 = executedQueries(listaQueries, secuencia );

	}

	private static List<List<List<String>>> executedQueries(List<String> listaQueries, String secuencia ) throws Exception {
		List<List<List<String>>> queriesResult = new ArrayList<List<List<String>>>();
		List<List<String>> dataFromQueriesList = null;
		int queriesNumbers = listaQueries.size();
		for (int iteration = 0; iteration < queriesNumbers; iteration++) {
			DataBaseUtils.getResultSet(listaQueries.get(iteration).replace("[Secuencia]", secuencia));
			dataFromQueriesList = DataBaseUtils.getDataFromResultset();
			queriesResult.add(dataFromQueriesList);

		}
		return queriesResult;
	}

}