package transUnion.Skyfall.JavaUtils;

import static org.junit.Assert.fail;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.assertj.core.api.SoftAssertions;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import transUnion.Skyfall.javaUtils.DataBaseUtils;
import transUnion.Skyfall.javaUtils.ReadSqlFile;
import transUnion.Skyfall.models.Fase1ResultadoArchivoPlano;
import transUnion.Skyfall.models.Fase1ResultadoBD;
import transUnion.Skyfall.models.Fase2ResultadoArchivoPlano;
import transUnion.Skyfall.models.Fase2ResultadoBD;
import transUnion.Skyfall.models.Fase4ResultadoArchivoPlanoUNO;
import transUnion.Skyfall.models.Fase5ResultadoBD;
import transUnion.Skyfall.models.Fase5ResultadoArchivoPlano;
import transUnion.Skyfall.models.Fase5ResultadoBD;
import transUnion.Skyfall.models.Fase5ResultadoArchivoPlano;
import transUnion.Skyfall.models.Fase5ResultadoArchivoPlano;
import transUnion.Skyfall.models.Fase5ResultadoBD;




@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PruebaFase5TradesHDComparacion {
	String origenFile = "C:\\Users\\romarti.UNIVERSO\\Automatizacion\\SkyFall\\Archivos_Txt\\test_historicos\\";
	String fileName =  "Mapeo_DATA1.txt";
	SoftAssertions softAssert = new SoftAssertions();
	static Logger logger = Logger.getLogger(PruebaFase5TradesHDComparacion.class);
	static boolean testEstructura;
	static boolean test = true;
	static String[] cabecero = {"SECUENCIA_TERCERO", "FECHA_CALIFICACION", "FECHA_CORTE_INFO", "AGG1101", "AGG1102",
			"AGG1103", "AGG1104", "AGG1105", "AGG1106", "AGG1107", "AGG1108", "AGG1109", "AGG1110", "AGG1111",
			"AGG1112", "AGG1113", "AGG1114", "AGG1115", "AGG1116", "AGG1117", "AGG1118", "AGG1119", "AGG1120",
			"AGG1121", "AGG1122", "AGG1123", "AGG1124", "AGG701", "AGG702", "AGG703", "AGG704", "AGG705", "AGG706",
			"AGG707", "AGG708", "AGG709", "AGG710", "AGG711", "AGG712", "AGG713", "AGG714", "AGG715", "AGG716",
			"AGG717", "AGG718", "AGG719", "AGG720", "AGG721", "AGG722", "AGG723", "AGG724", "AGG904", "AGG909",
			"AGG910", "AGG911", "AT27SF", "AT31S", "AU21S", "AU51A", "BC01S", "BC20S", "BC21S", "BI20S", "BI21S",
			"BI29S", "BI32S", "BKC231", "BKC232", "BKC233", "BKC235", "BKC252", "BKC253", "BKC254", "BKC255", "BR12S",
			"BR20S", "BU21S", "BU32S", "CO04S", "COLLECTION_TRD", "CT20S", "CT32S", "CV25", "FI20S", "FI21S", "FI34S",
			"FMD21S", "FR21S", "FR32S", "FU20S", "FU21S", "FU32S", "FU34S", "G103S", "G209SF", "G211S", "G218C",
			"G417S", "G500S", "G540S", "G547S", "G960S", "IN06S", "IN09S", "IN21S", "IN25S", "IN27S", "IN31S", "LL21S",
			"LL34S", "LMD21S", "LMD32S", "LMD34S", "MF20S", "MF24S", "MF31S", "MF32S", "MT24S", "MT33S", "MT34B",
			"MT34S", "NON_FINANCIAL_TRD", "OF32S", "OF34S", "PAYMNT03", "PER222", "PER224", "PT20S", "PT21S", "PT34S",
			"PUBLIC_SERVICE_TRD", "RE102S", "RE12S", "RE30S", "RE32S", "RET11", "RET132", "RET14", "RET142", "RET222",
			"RET223", "RET224", "RET225", "RET315", "RET320", "RET51", "RET84", "REV202", "REV203", "REV204", "REV222",
			"REV223", "REV225", "REV320", "REV92", "REVBAL01", "REVBAL02", "REVBAL03", "REVBAL04", "REVBAL05",
			"REVBAL06", "REVBAL07", "REVBAL08", "REVBAL09", "REVBAL10", "REVBAL11", "REVBAL12", "REVBAL13", "REVBAL14",
			"REVBAL15", "REVBAL16", "REVBAL17", "REVBAL18", "REVBAL19", "REVBAL20", "REVBAL21", "REVBAL22", "REVBAL23",
			"REVBAL24", "RI20S", "RI21S", "RI24S", "RI27S", "RI29S", "RI30S", "RI31S", "RI32S", "RLE904", "RLE905",
			"RR102S", "RR201S", "RT06S", "RT201S", "RT31S", "RVLR03", "RVLR06", "S043S", "S064D", "S209D", "SE21S",
			"SE34S", "TEL31S", "TEL32S", "TRANBAL01", "TRANBAL02", "TRANBAL03", "TRANBAL04", "TRANBAL05", "TRANBAL06",
			"TRANBAL07", "TRANBAL08", "TRANBAL09", "TRANBAL10", "TRANBAL11", "TRANBAL12", "TRANBAL13", "TRANBAL14",
			"TRANBAL15", "TRANBAL16", "TRANBAL17", "TRANBAL18", "TRANBAL19", "TRANBAL20", "TRANBAL21", "TRANBAL22",
			"TRANBAL23", "TRANBAL24", "TRV05", "TRV14", "TRV17", "TRV18", "UL01S", "UL06S", "UL21S", "UL25S", "UL30S",
			"UL32S", "US20S", "US25S", "WALSHR07", "WD71"
};
	
	

	static List<String> listaQueries;
	static List<List<List<String>>> queriesResult1;

	private int linea = 0;
	int Errores=0;
	@Test
	public void test1Estructura() throws Exception {
		Errores = 0;
		
		try (BufferedReader buffReader = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(new FileInputStream(origenFile + fileName)),
				"UTF-8"))) {
			String data;
			String dataReading = null;
			this.linea = 1;
			PruebaFase5TradesHDComparacion.testEstructura=true;
			imprimirReporte("Prueba_Estructura_", "DETALLE ERROR|"
					+ Arrays.toString(cabecero).replace(",", "|").replace("[", "").replace("]", "").replace(" ", "")
					+ "\n", false);
			while ((data = buffReader.readLine()) != null) {
				PruebaFase5TradesHDComparacion.test = true;

				dataReading = data;

				if (dataReading.endsWith("|")) {
					dataReading = dataReading.replace("|", "|-");
				}
				if (linea == 1 && (!dataReading.equals(Arrays.toString(cabecero).replace(",", "|").replace("[", "")
						.replace("]", "").replace(" ", "")))) {
					imprimirReporte("Prueba_Estructura_", "Error en el nombrado de campos\n", true);
					PruebaFase5TradesHDComparacion.testEstructura = false;
					test = false;
				}
				if (linea != 1 && (dataReading.split("\\|").length != 241)) {
					imprimirReporte("Prueba_Estructura_",
							"Numero de campos es diferente al establecido, en la linea--> " + linea
									+ " el archivo tiene --> " + dataReading.split("\\|").length + " campos|" + data + "\n",
							true);
					//PruebaFase1TradesComparacion.testEstructura = false;
					test=false;
				}
		


				if (!test) {
					logger.error("Se encontraron errores en la comparacion en la linea--> " + linea);
					softAssert.fail("Se encontraron errores en la comparacion en la linea--> " + linea);

Errores++;
				}
				else {
					logger.info("Linea --> " + linea + " ok");

				}
				this.linea++;
			}
			imprimirReporte("Prueba_Estructura_", "Numero de registros analizados "+(linea-1)
				+	" errores encontrados "+ Errores+"\n", true);
			softAssert.assertAll();
			imprimirReporte("Prueba_Estructura_", "Prueba ejecutada sin errores\n", true);
		}
	}

	@Test
	public void test2pruebaArchivo() throws Exception {
		
		String idTerceroL = "";	
		Errores=0;
		this.linea = 1;
		imprimirReporte("Test_Archivo_", "", false);
		if (true/*PruebaFase1TradesHDComparacion.testEstructura*/) {
			try (BufferedReader buffReader = new BufferedReader(new InputStreamReader(
					new BufferedInputStream(new FileInputStream(origenFile + fileName)),
					"UTF-8"))) {
				String data;
				buffReader.readLine();
		
				imprimirReporte("Test_Archivo_", "Linea\tSec_ter\t\tVariable\tSAS_Valor\tDATA_Valor\tPatron\n", true);
				DataBaseUtils.getDefaultConnection();
				while ((data = buffReader.readLine()) != null) {
					this.linea++;
					if (data.endsWith("|")) {
						data = data + " |";
					}
					test = true;
					if (data.split("\\|").length == 354) {
						//Numero de variables a evaluar
						Fase5ResultadoArchivoPlano.setDatosArchivoPlano(data);
					
						consultarBD(Fase5ResultadoArchivoPlano.getSECUENCIA_TERCERO());
						idTerceroL = Fase5ResultadoArchivoPlano.getSECUENCIA_TERCERO();
						
							if (queriesResult1.get(0).size() != 0) {
										//query set
								Fase5ResultadoBD.setDatosBD(queriesResult1.get(0).get(0));

								
								
								
								if (!Fase5ResultadoArchivoPlano.getSECUENCIA_TERCERO().equals(Fase5ResultadoBD.getSECUENCIA_TERCERO())) { 
									reportarError(Fase5ResultadoArchivoPlano.getSECUENCIA_TERCERO(), Fase5ResultadoBD.getSECUENCIA_TERCERO(), cabecero[0]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1101().equals(Fase5ResultadoBD.getAGG1101())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1101(), Fase5ResultadoBD.getAGG1101(), cabecero[1]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1102().equals(Fase5ResultadoBD.getAGG1102())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1102(), Fase5ResultadoBD.getAGG1102(), cabecero[2]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1103().equals(Fase5ResultadoBD.getAGG1103())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG1103(), Fase5ResultadoBD.getAGG1103(), cabecero[3]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1104().equals(Fase5ResultadoBD.getAGG1104())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1104(), Fase5ResultadoBD.getAGG1104(), cabecero[4]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1105().equals(Fase5ResultadoBD.getAGG1105())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG1105(), Fase5ResultadoBD.getAGG1105(), cabecero[5]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1106().equals(Fase5ResultadoBD.getAGG1106())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1106(), Fase5ResultadoBD.getAGG1106(), cabecero[6]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1107().equals(Fase5ResultadoBD.getAGG1107())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1107(), Fase5ResultadoBD.getAGG1107(), cabecero[7]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1108().equals(Fase5ResultadoBD.getAGG1108())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1108(), Fase5ResultadoBD.getAGG1108(), cabecero[8]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1109().equals(Fase5ResultadoBD.getAGG1109())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1109(), Fase5ResultadoBD.getAGG1109(), cabecero[9]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1110().equals(Fase5ResultadoBD.getAGG1110())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG1110(), Fase5ResultadoBD.getAGG1110(), cabecero[10]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1111().equals(Fase5ResultadoBD.getAGG1111())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1111(), Fase5ResultadoBD.getAGG1111(), cabecero[11]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1112().equals(Fase5ResultadoBD.getAGG1112())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG1112(), Fase5ResultadoBD.getAGG1112(), cabecero[12]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1113().equals(Fase5ResultadoBD.getAGG1113())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1113(), Fase5ResultadoBD.getAGG1113(), cabecero[13]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1114().equals(Fase5ResultadoBD.getAGG1114())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1114(), Fase5ResultadoBD.getAGG1114(), cabecero[14]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1115().equals(Fase5ResultadoBD.getAGG1115())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG1115(), Fase5ResultadoBD.getAGG1115(), cabecero[15]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1116().equals(Fase5ResultadoBD.getAGG1116())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG1116(), Fase5ResultadoBD.getAGG1116(), cabecero[16]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1117().equals(Fase5ResultadoBD.getAGG1117())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1117(), Fase5ResultadoBD.getAGG1117(), cabecero[17]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1118().equals(Fase5ResultadoBD.getAGG1118())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1118(), Fase5ResultadoBD.getAGG1118(), cabecero[18]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1119().equals(Fase5ResultadoBD.getAGG1119())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG1119(), Fase5ResultadoBD.getAGG1119(), cabecero[19]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1120().equals(Fase5ResultadoBD.getAGG1120())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG1120(), Fase5ResultadoBD.getAGG1120(), cabecero[20]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1121().equals(Fase5ResultadoBD.getAGG1121())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1121(), Fase5ResultadoBD.getAGG1121(), cabecero[21]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1122().equals(Fase5ResultadoBD.getAGG1122())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1122(), Fase5ResultadoBD.getAGG1122(), cabecero[22]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1123().equals(Fase5ResultadoBD.getAGG1123())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG1123(), Fase5ResultadoBD.getAGG1123(), cabecero[23]);}
								if (!Fase5ResultadoArchivoPlano.getAGG1124().equals(Fase5ResultadoBD.getAGG1124())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG1124(), Fase5ResultadoBD.getAGG1124(), cabecero[24]);}
								if (!Fase5ResultadoArchivoPlano.getAGG701().equals(Fase5ResultadoBD.getAGG701())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG701(), Fase5ResultadoBD.getAGG701(), cabecero[25]);}
								if (!Fase5ResultadoArchivoPlano.getAGG702().equals(Fase5ResultadoBD.getAGG702())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG702(), Fase5ResultadoBD.getAGG702(), cabecero[26]);}
								if (!Fase5ResultadoArchivoPlano.getAGG703().equals(Fase5ResultadoBD.getAGG703())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG703(), Fase5ResultadoBD.getAGG703(), cabecero[27]);}
								if (!Fase5ResultadoArchivoPlano.getAGG704().equals(Fase5ResultadoBD.getAGG704())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG704(), Fase5ResultadoBD.getAGG704(), cabecero[28]);}
								if (!Fase5ResultadoArchivoPlano.getAGG705().equals(Fase5ResultadoBD.getAGG705())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG705(), Fase5ResultadoBD.getAGG705(), cabecero[29]);}
								if (!Fase5ResultadoArchivoPlano.getAGG706().equals(Fase5ResultadoBD.getAGG706())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG706(), Fase5ResultadoBD.getAGG706(), cabecero[30]);}
								if (!Fase5ResultadoArchivoPlano.getAGG707().equals(Fase5ResultadoBD.getAGG707())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG707(), Fase5ResultadoBD.getAGG707(), cabecero[31]);}
								if (!Fase5ResultadoArchivoPlano.getAGG708().equals(Fase5ResultadoBD.getAGG708())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG708(), Fase5ResultadoBD.getAGG708(), cabecero[32]);}
								if (!Fase5ResultadoArchivoPlano.getAGG709().equals(Fase5ResultadoBD.getAGG709())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG709(), Fase5ResultadoBD.getAGG709(), cabecero[33]);}
								if (!Fase5ResultadoArchivoPlano.getAGG710().equals(Fase5ResultadoBD.getAGG710())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG710(), Fase5ResultadoBD.getAGG710(), cabecero[34]);}
								if (!Fase5ResultadoArchivoPlano.getAGG711().equals(Fase5ResultadoBD.getAGG711())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG711(), Fase5ResultadoBD.getAGG711(), cabecero[35]);}
								if (!Fase5ResultadoArchivoPlano.getAGG712().equals(Fase5ResultadoBD.getAGG712())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG712(), Fase5ResultadoBD.getAGG712(), cabecero[36]);}
								if (!Fase5ResultadoArchivoPlano.getAGG713().equals(Fase5ResultadoBD.getAGG713())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG713(), Fase5ResultadoBD.getAGG713(), cabecero[37]);}
								if (!Fase5ResultadoArchivoPlano.getAGG714().equals(Fase5ResultadoBD.getAGG714())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG714(), Fase5ResultadoBD.getAGG714(), cabecero[38]);}
								if (!Fase5ResultadoArchivoPlano.getAGG715().equals(Fase5ResultadoBD.getAGG715())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG715(), Fase5ResultadoBD.getAGG715(), cabecero[39]);}
								if (!Fase5ResultadoArchivoPlano.getAGG716().equals(Fase5ResultadoBD.getAGG716())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG716(), Fase5ResultadoBD.getAGG716(), cabecero[40]);}
								if (!Fase5ResultadoArchivoPlano.getAGG717().equals(Fase5ResultadoBD.getAGG717())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG717(), Fase5ResultadoBD.getAGG717(), cabecero[41]);}
								if (!Fase5ResultadoArchivoPlano.getAGG718().equals(Fase5ResultadoBD.getAGG718())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG718(), Fase5ResultadoBD.getAGG718(), cabecero[42]);}
								if (!Fase5ResultadoArchivoPlano.getAGG719().equals(Fase5ResultadoBD.getAGG719())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG719(), Fase5ResultadoBD.getAGG719(), cabecero[43]);}
								if (!Fase5ResultadoArchivoPlano.getAGG720().equals(Fase5ResultadoBD.getAGG720())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG720(), Fase5ResultadoBD.getAGG720(), cabecero[44]);}
								if (!Fase5ResultadoArchivoPlano.getAGG721().equals(Fase5ResultadoBD.getAGG721())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG721(), Fase5ResultadoBD.getAGG721(), cabecero[45]);}
								if (!Fase5ResultadoArchivoPlano.getAGG722().equals(Fase5ResultadoBD.getAGG722())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG722(), Fase5ResultadoBD.getAGG722(), cabecero[46]);}
								if (!Fase5ResultadoArchivoPlano.getAGG723().equals(Fase5ResultadoBD.getAGG723())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG723(), Fase5ResultadoBD.getAGG723(), cabecero[47]);}
								if (!Fase5ResultadoArchivoPlano.getAGG724().equals(Fase5ResultadoBD.getAGG724())) {
									reportarError(Fase5ResultadoArchivoPlano.getAGG724(), Fase5ResultadoBD.getAGG724(), cabecero[48]);}
								if (!Fase5ResultadoArchivoPlano.getAGG904().equals(Fase5ResultadoBD.getAGG904())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG904(), Fase5ResultadoBD.getAGG904(), cabecero[49]);}
								if (!Fase5ResultadoArchivoPlano.getAGG909().equals(Fase5ResultadoBD.getAGG909())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG909(), Fase5ResultadoBD.getAGG909(), cabecero[50]);}
								if (!Fase5ResultadoArchivoPlano.getAGG910().equals(Fase5ResultadoBD.getAGG910())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG910(), Fase5ResultadoBD.getAGG910(), cabecero[51]);}
								if (!Fase5ResultadoArchivoPlano.getAGG911().equals(Fase5ResultadoBD.getAGG911())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAGG911(), Fase5ResultadoBD.getAGG911(), cabecero[52]);}
								if (!Fase5ResultadoArchivoPlano.getAT27SF().equals(Fase5ResultadoBD.getAT27SF())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAT27SF(), Fase5ResultadoBD.getAT27SF(), cabecero[53]);}
								if (!Fase5ResultadoArchivoPlano.getAT31S().equals(Fase5ResultadoBD.getAT31S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAT31S(), Fase5ResultadoBD.getAT31S(), cabecero[54]);}
								if (!Fase5ResultadoArchivoPlano.getAU21S().equals(Fase5ResultadoBD.getAU21S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAU21S(), Fase5ResultadoBD.getAU21S(), cabecero[55]);}
								if (!Fase5ResultadoArchivoPlano.getAU51A().equals(Fase5ResultadoBD.getAU51A())) { 
									reportarError(Fase5ResultadoArchivoPlano.getAU51A(), Fase5ResultadoBD.getAU51A(), cabecero[56]);}
								if (!Fase5ResultadoArchivoPlano.getBC01S().equals(Fase5ResultadoBD.getBC01S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBC01S(), Fase5ResultadoBD.getBC01S(), cabecero[57]);}
								if (!Fase5ResultadoArchivoPlano.getBC20S().equals(Fase5ResultadoBD.getBC20S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBC20S(), Fase5ResultadoBD.getBC20S(), cabecero[58]);}
								if (!Fase5ResultadoArchivoPlano.getBC21S().equals(Fase5ResultadoBD.getBC21S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBC21S(), Fase5ResultadoBD.getBC21S(), cabecero[59]);}
								if (!Fase5ResultadoArchivoPlano.getBI20S().equals(Fase5ResultadoBD.getBI20S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBI20S(), Fase5ResultadoBD.getBI20S(), cabecero[60]);}
								if (!Fase5ResultadoArchivoPlano.getBI21S().equals(Fase5ResultadoBD.getBI21S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBI21S(), Fase5ResultadoBD.getBI21S(), cabecero[61]);}
								if (!Fase5ResultadoArchivoPlano.getBI29S().equals(Fase5ResultadoBD.getBI29S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBI29S(), Fase5ResultadoBD.getBI29S(), cabecero[62]);}
								if (!Fase5ResultadoArchivoPlano.getBI32S().equals(Fase5ResultadoBD.getBI32S())) {
									reportarError(Fase5ResultadoArchivoPlano.getBI32S(), Fase5ResultadoBD.getBI32S(), cabecero[63]);}
								if (!Fase5ResultadoArchivoPlano.getBKC231().equals(Fase5ResultadoBD.getBKC231())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBKC231(), Fase5ResultadoBD.getBKC231(), cabecero[64]);}
								if (!Fase5ResultadoArchivoPlano.getBKC232().equals(Fase5ResultadoBD.getBKC232())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBKC232(), Fase5ResultadoBD.getBKC232(), cabecero[65]);}
								if (!Fase5ResultadoArchivoPlano.getBKC233().equals(Fase5ResultadoBD.getBKC233())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBKC233(), Fase5ResultadoBD.getBKC233(), cabecero[66]);}
								if (!Fase5ResultadoArchivoPlano.getBKC235().equals(Fase5ResultadoBD.getBKC235())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBKC235(), Fase5ResultadoBD.getBKC235(), cabecero[67]);}
								if (!Fase5ResultadoArchivoPlano.getBKC252().equals(Fase5ResultadoBD.getBKC252())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBKC252(), Fase5ResultadoBD.getBKC252(), cabecero[68]);}
								if (!Fase5ResultadoArchivoPlano.getBKC253().equals(Fase5ResultadoBD.getBKC253())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBKC253(), Fase5ResultadoBD.getBKC253(), cabecero[69]);}
								if (!Fase5ResultadoArchivoPlano.getBKC254().equals(Fase5ResultadoBD.getBKC254())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBKC254(), Fase5ResultadoBD.getBKC254(), cabecero[70]);}
								if (!Fase5ResultadoArchivoPlano.getBKC255().equals(Fase5ResultadoBD.getBKC255())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBKC255(), Fase5ResultadoBD.getBKC255(), cabecero[71]);}
								if (!Fase5ResultadoArchivoPlano.getBR12S().equals(Fase5ResultadoBD.getBR12S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBR12S(), Fase5ResultadoBD.getBR12S(), cabecero[72]);}
								if (!Fase5ResultadoArchivoPlano.getBR20S().equals(Fase5ResultadoBD.getBR20S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBR20S(), Fase5ResultadoBD.getBR20S(), cabecero[73]);}
								if (!Fase5ResultadoArchivoPlano.getBU21S().equals(Fase5ResultadoBD.getBU21S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBU21S(), Fase5ResultadoBD.getBU21S(), cabecero[74]);}
								if (!Fase5ResultadoArchivoPlano.getBU32S().equals(Fase5ResultadoBD.getBU32S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getBU32S(), Fase5ResultadoBD.getBU32S(), cabecero[75]);}
								if (!Fase5ResultadoArchivoPlano.getCO04S().equals(Fase5ResultadoBD.getCO04S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getCO04S(), Fase5ResultadoBD.getCO04S(), cabecero[76]);}
								if (!Fase5ResultadoArchivoPlano.getCOLLECTION_TRD().equals(Fase5ResultadoBD.getCOLLECTION_TRD())) { 
									reportarError(Fase5ResultadoArchivoPlano.getCOLLECTION_TRD(), Fase5ResultadoBD.getCOLLECTION_TRD(), cabecero[77]);}
								if (!Fase5ResultadoArchivoPlano.getCT20S().equals(Fase5ResultadoBD.getCT20S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getCT20S(), Fase5ResultadoBD.getCT20S(), cabecero[78]);}
								if (!Fase5ResultadoArchivoPlano.getCT32S().equals(Fase5ResultadoBD.getCT32S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getCT32S(), Fase5ResultadoBD.getCT32S(), cabecero[79]);}
								if (!Fase5ResultadoArchivoPlano.getCV25().equals(Fase5ResultadoBD.getCV25())) { 
									reportarError(Fase5ResultadoArchivoPlano.getCV25(), Fase5ResultadoBD.getCV25(), cabecero[80]);}
								if (!Fase5ResultadoArchivoPlano.getFI20S().equals(Fase5ResultadoBD.getFI20S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getFI20S(), Fase5ResultadoBD.getFI20S(), cabecero[81]);}
								if (!Fase5ResultadoArchivoPlano.getFI21S().equals(Fase5ResultadoBD.getFI21S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getFI21S(), Fase5ResultadoBD.getFI21S(), cabecero[82]);}
								if (!Fase5ResultadoArchivoPlano.getFI34S().equals(Fase5ResultadoBD.getFI34S())) {
									reportarError(Fase5ResultadoArchivoPlano.getFI34S(), Fase5ResultadoBD.getFI34S(), cabecero[83]);}
								if (!Fase5ResultadoArchivoPlano.getFMD21S().equals(Fase5ResultadoBD.getFMD21S())) {
									reportarError(Fase5ResultadoArchivoPlano.getFMD21S(), Fase5ResultadoBD.getFMD21S(), cabecero[84]);}
								if (!Fase5ResultadoArchivoPlano.getFR21S().equals(Fase5ResultadoBD.getFR21S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getFR21S(), Fase5ResultadoBD.getFR21S(), cabecero[85]);}
								if (!Fase5ResultadoArchivoPlano.getFR32S().equals(Fase5ResultadoBD.getFR32S())) {
									reportarError(Fase5ResultadoArchivoPlano.getFR32S(), Fase5ResultadoBD.getFR32S(), cabecero[86]);}
								if (!Fase5ResultadoArchivoPlano.getFU20S().equals(Fase5ResultadoBD.getFU20S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getFU20S(), Fase5ResultadoBD.getFU20S(), cabecero[87]);}
								if (!Fase5ResultadoArchivoPlano.getFU21S().equals(Fase5ResultadoBD.getFU21S())) {
									reportarError(Fase5ResultadoArchivoPlano.getFU21S(), Fase5ResultadoBD.getFU21S(), cabecero[88]);}
								if (!Fase5ResultadoArchivoPlano.getFU32S().equals(Fase5ResultadoBD.getFU32S())) {
									reportarError(Fase5ResultadoArchivoPlano.getFU32S(), Fase5ResultadoBD.getFU32S(), cabecero[89]);}
								if (!Fase5ResultadoArchivoPlano.getFU34S().equals(Fase5ResultadoBD.getFU34S())) {
									reportarError(Fase5ResultadoArchivoPlano.getFU34S(), Fase5ResultadoBD.getFU34S(), cabecero[90]);}
								if (!Fase5ResultadoArchivoPlano.getG103S().equals(Fase5ResultadoBD.getG103S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getG103S(), Fase5ResultadoBD.getG103S(), cabecero[91]);}
								if (!Fase5ResultadoArchivoPlano.getG209SF().equals(Fase5ResultadoBD.getG209SF())) { 
									reportarError(Fase5ResultadoArchivoPlano.getG209SF(), Fase5ResultadoBD.getG209SF(), cabecero[92]);}
								if (!Fase5ResultadoArchivoPlano.getG211S().equals(Fase5ResultadoBD.getG211S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getG211S(), Fase5ResultadoBD.getG211S(), cabecero[93]);}
								if (!Fase5ResultadoArchivoPlano.getG218C().equals(Fase5ResultadoBD.getG218C())) {
									reportarError(Fase5ResultadoArchivoPlano.getG218C(), Fase5ResultadoBD.getG218C(), cabecero[94]);}
								if (!Fase5ResultadoArchivoPlano.getG417S().equals(Fase5ResultadoBD.getG417S())) {
									reportarError(Fase5ResultadoArchivoPlano.getG417S(), Fase5ResultadoBD.getG417S(), cabecero[95]);}
								if (!Fase5ResultadoArchivoPlano.getG500S().equals(Fase5ResultadoBD.getG500S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getG500S(), Fase5ResultadoBD.getG500S(), cabecero[96]);}
								if (!Fase5ResultadoArchivoPlano.getG540S().equals(Fase5ResultadoBD.getG540S())) {
									reportarError(Fase5ResultadoArchivoPlano.getG540S(), Fase5ResultadoBD.getG540S(), cabecero[97]);}
								if (!Fase5ResultadoArchivoPlano.getG547S().equals(Fase5ResultadoBD.getG547S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getG547S(), Fase5ResultadoBD.getG547S(), cabecero[98]);}
								if (!Fase5ResultadoArchivoPlano.getG960S().equals(Fase5ResultadoBD.getG960S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getG960S(), Fase5ResultadoBD.getG960S(), cabecero[99]);}
								if (!Fase5ResultadoArchivoPlano.getIN06S().equals(Fase5ResultadoBD.getIN06S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getIN06S(), Fase5ResultadoBD.getIN06S(), cabecero[100]);}
								if (!Fase5ResultadoArchivoPlano.getIN09S().equals(Fase5ResultadoBD.getIN09S())) {
									reportarError(Fase5ResultadoArchivoPlano.getIN09S(), Fase5ResultadoBD.getIN09S(), cabecero[101]);}
								if (!Fase5ResultadoArchivoPlano.getIN21S().equals(Fase5ResultadoBD.getIN21S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getIN21S(), Fase5ResultadoBD.getIN21S(), cabecero[102]);}
								if (!Fase5ResultadoArchivoPlano.getIN25S().equals(Fase5ResultadoBD.getIN25S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getIN25S(), Fase5ResultadoBD.getIN25S(), cabecero[103]);}
								if (!Fase5ResultadoArchivoPlano.getIN27S().equals(Fase5ResultadoBD.getIN27S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getIN27S(), Fase5ResultadoBD.getIN27S(), cabecero[104]);}
								if (!Fase5ResultadoArchivoPlano.getIN31S().equals(Fase5ResultadoBD.getIN31S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getIN31S(), Fase5ResultadoBD.getIN31S(), cabecero[105]);}
								if (!Fase5ResultadoArchivoPlano.getLL21S().equals(Fase5ResultadoBD.getLL21S())) {
									reportarError(Fase5ResultadoArchivoPlano.getLL21S(), Fase5ResultadoBD.getLL21S(), cabecero[106]);}
								if (!Fase5ResultadoArchivoPlano.getLL34S().equals(Fase5ResultadoBD.getLL34S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getLL34S(), Fase5ResultadoBD.getLL34S(), cabecero[107]);}
								if (!Fase5ResultadoArchivoPlano.getLMD21S().equals(Fase5ResultadoBD.getLMD21S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getLMD21S(), Fase5ResultadoBD.getLMD21S(), cabecero[108]);}
								if (!Fase5ResultadoArchivoPlano.getLMD32S().equals(Fase5ResultadoBD.getLMD32S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getLMD32S(), Fase5ResultadoBD.getLMD32S(), cabecero[109]);}
								if (!Fase5ResultadoArchivoPlano.getLMD34S().equals(Fase5ResultadoBD.getLMD34S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getLMD34S(), Fase5ResultadoBD.getLMD34S(), cabecero[110]);}
								if (!Fase5ResultadoArchivoPlano.getMF20S().equals(Fase5ResultadoBD.getMF20S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getMF20S(), Fase5ResultadoBD.getMF20S(), cabecero[111]);}
								if (!Fase5ResultadoArchivoPlano.getMF24S().equals(Fase5ResultadoBD.getMF24S())) {
									reportarError(Fase5ResultadoArchivoPlano.getMF24S(), Fase5ResultadoBD.getMF24S(), cabecero[112]);}
								if (!Fase5ResultadoArchivoPlano.getMF31S().equals(Fase5ResultadoBD.getMF31S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getMF31S(), Fase5ResultadoBD.getMF31S(), cabecero[113]);}
								if (!Fase5ResultadoArchivoPlano.getMF32S().equals(Fase5ResultadoBD.getMF32S())) {
									reportarError(Fase5ResultadoArchivoPlano.getMF32S(), Fase5ResultadoBD.getMF32S(), cabecero[114]);}
								if (!Fase5ResultadoArchivoPlano.getMT24S().equals(Fase5ResultadoBD.getMT24S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getMT24S(), Fase5ResultadoBD.getMT24S(), cabecero[115]);}
								if (!Fase5ResultadoArchivoPlano.getMT33S().equals(Fase5ResultadoBD.getMT33S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getMT33S(), Fase5ResultadoBD.getMT33S(), cabecero[116]);}
								if (!Fase5ResultadoArchivoPlano.getMT34B().equals(Fase5ResultadoBD.getMT34B())) { 
									reportarError(Fase5ResultadoArchivoPlano.getMT34B(), Fase5ResultadoBD.getMT34B(), cabecero[117]);}
								if (!Fase5ResultadoArchivoPlano.getMT34S().equals(Fase5ResultadoBD.getMT34S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getMT34S(), Fase5ResultadoBD.getMT34S(), cabecero[118]);}
								if (!Fase5ResultadoArchivoPlano.getNON_FINANCIAL_TRD().equals(Fase5ResultadoBD.getNON_FINANCIAL_TRD())) { 
									reportarError(Fase5ResultadoArchivoPlano.getNON_FINANCIAL_TRD(), Fase5ResultadoBD.getNON_FINANCIAL_TRD(), cabecero[119]);}
								if (!Fase5ResultadoArchivoPlano.getOF32S().equals(Fase5ResultadoBD.getOF32S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getOF32S(), Fase5ResultadoBD.getOF32S(), cabecero[120]);}
								if (!Fase5ResultadoArchivoPlano.getOF34S().equals(Fase5ResultadoBD.getOF34S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getOF34S(), Fase5ResultadoBD.getOF34S(), cabecero[121]);}
								if (!Fase5ResultadoArchivoPlano.getPAYMNT03().equals(Fase5ResultadoBD.getPAYMNT03())) { 
									reportarError(Fase5ResultadoArchivoPlano.getPAYMNT03(), Fase5ResultadoBD.getPAYMNT03(), cabecero[122]);}
								if (!Fase5ResultadoArchivoPlano.getPER222().equals(Fase5ResultadoBD.getPER222())) { 
									reportarError(Fase5ResultadoArchivoPlano.getPER222(), Fase5ResultadoBD.getPER222(), cabecero[123]);}
								if (!Fase5ResultadoArchivoPlano.getPER224().equals(Fase5ResultadoBD.getPER224())) { 
									reportarError(Fase5ResultadoArchivoPlano.getPER224(), Fase5ResultadoBD.getPER224(), cabecero[124]);}
								if (!Fase5ResultadoArchivoPlano.getPT20S().equals(Fase5ResultadoBD.getPT20S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getPT20S(), Fase5ResultadoBD.getPT20S(), cabecero[125]);}
								if (!Fase5ResultadoArchivoPlano.getPT21S().equals(Fase5ResultadoBD.getPT21S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getPT21S(), Fase5ResultadoBD.getPT21S(), cabecero[126]);}
								if (!Fase5ResultadoArchivoPlano.getPT34S().equals(Fase5ResultadoBD.getPT34S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getPT34S(), Fase5ResultadoBD.getPT34S(), cabecero[127]);}
								if (!Fase5ResultadoArchivoPlano.getPUBLIC_SERVICE_TRD().equals(Fase5ResultadoBD.getPUBLIC_SERVICE_TRD())) { 
									reportarError(Fase5ResultadoArchivoPlano.getPUBLIC_SERVICE_TRD(), Fase5ResultadoBD.getPUBLIC_SERVICE_TRD(), cabecero[128]);}
								if (!Fase5ResultadoArchivoPlano.getRE102S().equals(Fase5ResultadoBD.getRE102S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRE102S(), Fase5ResultadoBD.getRE102S(), cabecero[129]);}
								if (!Fase5ResultadoArchivoPlano.getRE12S().equals(Fase5ResultadoBD.getRE12S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRE12S(), Fase5ResultadoBD.getRE12S(), cabecero[130]);}
								if (!Fase5ResultadoArchivoPlano.getRE30S().equals(Fase5ResultadoBD.getRE30S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRE30S(), Fase5ResultadoBD.getRE30S(), cabecero[131]);}
								if (!Fase5ResultadoArchivoPlano.getRE32S().equals(Fase5ResultadoBD.getRE32S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRE32S(), Fase5ResultadoBD.getRE32S(), cabecero[132]);}
								if (!Fase5ResultadoArchivoPlano.getRET11().equals(Fase5ResultadoBD.getRET11())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRET11(), Fase5ResultadoBD.getRET11(), cabecero[133]);}
								if (!Fase5ResultadoArchivoPlano.getRET132().equals(Fase5ResultadoBD.getRET132())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRET132(), Fase5ResultadoBD.getRET132(), cabecero[134]);}
								if (!Fase5ResultadoArchivoPlano.getRET14().equals(Fase5ResultadoBD.getRET14())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRET14(), Fase5ResultadoBD.getRET14(), cabecero[135]);}
								if (!Fase5ResultadoArchivoPlano.getRET142().equals(Fase5ResultadoBD.getRET142())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRET142(), Fase5ResultadoBD.getRET142(), cabecero[136]);}
								if (!Fase5ResultadoArchivoPlano.getRET222().equals(Fase5ResultadoBD.getRET222())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRET222(), Fase5ResultadoBD.getRET222(), cabecero[137]);}
								if (!Fase5ResultadoArchivoPlano.getRET223().equals(Fase5ResultadoBD.getRET223())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRET223(), Fase5ResultadoBD.getRET223(), cabecero[138]);}
								if (!Fase5ResultadoArchivoPlano.getRET224().equals(Fase5ResultadoBD.getRET224())) {
									reportarError(Fase5ResultadoArchivoPlano.getRET224(), Fase5ResultadoBD.getRET224(), cabecero[139]);}
								if (!Fase5ResultadoArchivoPlano.getRET225().equals(Fase5ResultadoBD.getRET225())) {
									reportarError(Fase5ResultadoArchivoPlano.getRET225(), Fase5ResultadoBD.getRET225(), cabecero[140]);}
								if (!Fase5ResultadoArchivoPlano.getRET315().equals(Fase5ResultadoBD.getRET315())) {
									reportarError(Fase5ResultadoArchivoPlano.getRET315(), Fase5ResultadoBD.getRET315(), cabecero[141]);}
								if (!Fase5ResultadoArchivoPlano.getRET320().equals(Fase5ResultadoBD.getRET320())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRET320(), Fase5ResultadoBD.getRET320(), cabecero[142]);}
								if (!Fase5ResultadoArchivoPlano.getRET51().equals(Fase5ResultadoBD.getRET51())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRET51(), Fase5ResultadoBD.getRET51(), cabecero[143]);}
								if (!Fase5ResultadoArchivoPlano.getRET84().equals(Fase5ResultadoBD.getRET84())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRET84(), Fase5ResultadoBD.getRET84(), cabecero[144]);}
								if (!Fase5ResultadoArchivoPlano.getREV202().equals(Fase5ResultadoBD.getREV202())) {
									reportarError(Fase5ResultadoArchivoPlano.getREV202(), Fase5ResultadoBD.getREV202(), cabecero[145]);}
								if (!Fase5ResultadoArchivoPlano.getREV203().equals(Fase5ResultadoBD.getREV203())) {
									reportarError(Fase5ResultadoArchivoPlano.getREV203(), Fase5ResultadoBD.getREV203(), cabecero[146]);}
								if (!Fase5ResultadoArchivoPlano.getREV204().equals(Fase5ResultadoBD.getREV204())) {
									reportarError(Fase5ResultadoArchivoPlano.getREV204(), Fase5ResultadoBD.getREV204(), cabecero[147]);}
								if (!Fase5ResultadoArchivoPlano.getREV222().equals(Fase5ResultadoBD.getREV222())) {
									reportarError(Fase5ResultadoArchivoPlano.getREV222(), Fase5ResultadoBD.getREV222(), cabecero[148]);}
								if (!Fase5ResultadoArchivoPlano.getREV223().equals(Fase5ResultadoBD.getREV223())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREV223(), Fase5ResultadoBD.getREV223(), cabecero[149]);}
								if (!Fase5ResultadoArchivoPlano.getREV225().equals(Fase5ResultadoBD.getREV225())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREV225(), Fase5ResultadoBD.getREV225(), cabecero[150]);}
								if (!Fase5ResultadoArchivoPlano.getREV320().equals(Fase5ResultadoBD.getREV320())) {
									reportarError(Fase5ResultadoArchivoPlano.getREV320(), Fase5ResultadoBD.getREV320(), cabecero[151]);}
								if (!Fase5ResultadoArchivoPlano.getREV92().equals(Fase5ResultadoBD.getREV92())) {
									reportarError(Fase5ResultadoArchivoPlano.getREV92(), Fase5ResultadoBD.getREV92(), cabecero[152]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL01().equals(Fase5ResultadoBD.getREVBAL01())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL01(), Fase5ResultadoBD.getREVBAL01(), cabecero[153]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL02().equals(Fase5ResultadoBD.getREVBAL02())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL02(), Fase5ResultadoBD.getREVBAL02(), cabecero[154]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL03().equals(Fase5ResultadoBD.getREVBAL03())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL03(), Fase5ResultadoBD.getREVBAL03(), cabecero[155]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL04().equals(Fase5ResultadoBD.getREVBAL04())) {
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL04(), Fase5ResultadoBD.getREVBAL04(), cabecero[156]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL05().equals(Fase5ResultadoBD.getREVBAL05())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL05(), Fase5ResultadoBD.getREVBAL05(), cabecero[157]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL06().equals(Fase5ResultadoBD.getREVBAL06())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL06(), Fase5ResultadoBD.getREVBAL06(), cabecero[158]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL07().equals(Fase5ResultadoBD.getREVBAL07())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL07(), Fase5ResultadoBD.getREVBAL07(), cabecero[159]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL08().equals(Fase5ResultadoBD.getREVBAL08())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL08(), Fase5ResultadoBD.getREVBAL08(), cabecero[160]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL09().equals(Fase5ResultadoBD.getREVBAL09())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL09(), Fase5ResultadoBD.getREVBAL09(), cabecero[161]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL10().equals(Fase5ResultadoBD.getREVBAL10())) {
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL10(), Fase5ResultadoBD.getREVBAL10(), cabecero[162]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL11().equals(Fase5ResultadoBD.getREVBAL11())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL11(), Fase5ResultadoBD.getREVBAL11(), cabecero[163]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL12().equals(Fase5ResultadoBD.getREVBAL12())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL12(), Fase5ResultadoBD.getREVBAL12(), cabecero[164]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL13().equals(Fase5ResultadoBD.getREVBAL13())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL13(), Fase5ResultadoBD.getREVBAL13(), cabecero[165]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL14().equals(Fase5ResultadoBD.getREVBAL14())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL14(), Fase5ResultadoBD.getREVBAL14(), cabecero[166]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL15().equals(Fase5ResultadoBD.getREVBAL15())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL15(), Fase5ResultadoBD.getREVBAL15(), cabecero[167]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL16().equals(Fase5ResultadoBD.getREVBAL16())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL16(), Fase5ResultadoBD.getREVBAL16(), cabecero[168]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL17().equals(Fase5ResultadoBD.getREVBAL17())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL17(), Fase5ResultadoBD.getREVBAL17(), cabecero[169]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL18().equals(Fase5ResultadoBD.getREVBAL18())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL18(), Fase5ResultadoBD.getREVBAL18(), cabecero[170]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL19().equals(Fase5ResultadoBD.getREVBAL19())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL19(), Fase5ResultadoBD.getREVBAL19(), cabecero[171]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL20().equals(Fase5ResultadoBD.getREVBAL20())) {
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL20(), Fase5ResultadoBD.getREVBAL20(), cabecero[172]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL21().equals(Fase5ResultadoBD.getREVBAL21())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL21(), Fase5ResultadoBD.getREVBAL21(), cabecero[173]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL22().equals(Fase5ResultadoBD.getREVBAL22())) { 
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL22(), Fase5ResultadoBD.getREVBAL22(), cabecero[174]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL23().equals(Fase5ResultadoBD.getREVBAL23())) {
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL23(), Fase5ResultadoBD.getREVBAL23(), cabecero[175]);}
								if (!Fase5ResultadoArchivoPlano.getREVBAL24().equals(Fase5ResultadoBD.getREVBAL24())) {
									reportarError(Fase5ResultadoArchivoPlano.getREVBAL24(), Fase5ResultadoBD.getREVBAL24(), cabecero[176]);}
								if (!Fase5ResultadoArchivoPlano.getRI20S().equals(Fase5ResultadoBD.getRI20S())) {
									reportarError(Fase5ResultadoArchivoPlano.getRI20S(), Fase5ResultadoBD.getRI20S(), cabecero[177]);}
								if (!Fase5ResultadoArchivoPlano.getRI21S().equals(Fase5ResultadoBD.getRI21S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRI21S(), Fase5ResultadoBD.getRI21S(), cabecero[178]);}
								if (!Fase5ResultadoArchivoPlano.getRI24S().equals(Fase5ResultadoBD.getRI24S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRI24S(), Fase5ResultadoBD.getRI24S(), cabecero[179]);}
								if (!Fase5ResultadoArchivoPlano.getRI27S().equals(Fase5ResultadoBD.getRI27S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRI27S(), Fase5ResultadoBD.getRI27S(), cabecero[180]);}
								if (!Fase5ResultadoArchivoPlano.getRI29S().equals(Fase5ResultadoBD.getRI29S())) {
									reportarError(Fase5ResultadoArchivoPlano.getRI29S(), Fase5ResultadoBD.getRI29S(), cabecero[181]);}
								if (!Fase5ResultadoArchivoPlano.getRI30S().equals(Fase5ResultadoBD.getRI30S())) {
									reportarError(Fase5ResultadoArchivoPlano.getRI30S(), Fase5ResultadoBD.getRI30S(), cabecero[182]);}
								if (!Fase5ResultadoArchivoPlano.getRI31S().equals(Fase5ResultadoBD.getRI31S())) {
									reportarError(Fase5ResultadoArchivoPlano.getRI31S(), Fase5ResultadoBD.getRI31S(), cabecero[183]);}
								if (!Fase5ResultadoArchivoPlano.getRI32S().equals(Fase5ResultadoBD.getRI32S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRI32S(), Fase5ResultadoBD.getRI32S(), cabecero[184]);}
								if (!Fase5ResultadoArchivoPlano.getRLE904().equals(Fase5ResultadoBD.getRLE904())) {
									reportarError(Fase5ResultadoArchivoPlano.getRLE904(), Fase5ResultadoBD.getRLE904(), cabecero[185]);}
								if (!Fase5ResultadoArchivoPlano.getRLE905().equals(Fase5ResultadoBD.getRLE905())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRLE905(), Fase5ResultadoBD.getRLE905(), cabecero[186]);}
								if (!Fase5ResultadoArchivoPlano.getRR102S().equals(Fase5ResultadoBD.getRR102S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRR102S(), Fase5ResultadoBD.getRR102S(), cabecero[187]);}
								if (!Fase5ResultadoArchivoPlano.getRR201S().equals(Fase5ResultadoBD.getRR201S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRR201S(), Fase5ResultadoBD.getRR201S(), cabecero[188]);}
								if (!Fase5ResultadoArchivoPlano.getRT06S().equals(Fase5ResultadoBD.getRT06S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRT06S(), Fase5ResultadoBD.getRT06S(), cabecero[189]);}
								if (!Fase5ResultadoArchivoPlano.getRT201S().equals(Fase5ResultadoBD.getRT201S())) {
									reportarError(Fase5ResultadoArchivoPlano.getRT201S(), Fase5ResultadoBD.getRT201S(), cabecero[190]);}
								if (!Fase5ResultadoArchivoPlano.getRT31S().equals(Fase5ResultadoBD.getRT31S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRT31S(), Fase5ResultadoBD.getRT31S(), cabecero[191]);}
								if (!Fase5ResultadoArchivoPlano.getRVLR03().equals(Fase5ResultadoBD.getRVLR03())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRVLR03(), Fase5ResultadoBD.getRVLR03(), cabecero[192]);}
								if (!Fase5ResultadoArchivoPlano.getRVLR06().equals(Fase5ResultadoBD.getRVLR06())) { 
									reportarError(Fase5ResultadoArchivoPlano.getRVLR06(), Fase5ResultadoBD.getRVLR06(), cabecero[193]);}
								if (!Fase5ResultadoArchivoPlano.getS043S().equals(Fase5ResultadoBD.getS043S())) {
									reportarError(Fase5ResultadoArchivoPlano.getS043S(), Fase5ResultadoBD.getS043S(), cabecero[194]);}
								if (!Fase5ResultadoArchivoPlano.getS064D().equals(Fase5ResultadoBD.getS064D())) { 
									reportarError(Fase5ResultadoArchivoPlano.getS064D(), Fase5ResultadoBD.getS064D(), cabecero[195]);}
								if (!Fase5ResultadoArchivoPlano.getS209D().equals(Fase5ResultadoBD.getS209D())) { 
									reportarError(Fase5ResultadoArchivoPlano.getS209D(), Fase5ResultadoBD.getS209D(), cabecero[196]);}
								if (!Fase5ResultadoArchivoPlano.getSE21S().equals(Fase5ResultadoBD.getSE21S())) {
									reportarError(Fase5ResultadoArchivoPlano.getSE21S(), Fase5ResultadoBD.getSE21S(), cabecero[197]);}
								if (!Fase5ResultadoArchivoPlano.getSE34S().equals(Fase5ResultadoBD.getSE34S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getSE34S(), Fase5ResultadoBD.getSE34S(), cabecero[198]);}
								if (!Fase5ResultadoArchivoPlano.getTEL31S().equals(Fase5ResultadoBD.getTEL31S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTEL31S(), Fase5ResultadoBD.getTEL31S(), cabecero[199]);}
								if (!Fase5ResultadoArchivoPlano.getTEL32S().equals(Fase5ResultadoBD.getTEL32S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTEL32S(), Fase5ResultadoBD.getTEL32S(), cabecero[200]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL01().equals(Fase5ResultadoBD.getTRANBAL01())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL01(), Fase5ResultadoBD.getTRANBAL01(), cabecero[201]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL02().equals(Fase5ResultadoBD.getTRANBAL02())) {
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL02(), Fase5ResultadoBD.getTRANBAL02(), cabecero[202]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL03().equals(Fase5ResultadoBD.getTRANBAL03())) {
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL03(), Fase5ResultadoBD.getTRANBAL03(), cabecero[203]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL04().equals(Fase5ResultadoBD.getTRANBAL04())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL04(), Fase5ResultadoBD.getTRANBAL04(), cabecero[204]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL05().equals(Fase5ResultadoBD.getTRANBAL05())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL05(), Fase5ResultadoBD.getTRANBAL05(), cabecero[205]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL06().equals(Fase5ResultadoBD.getTRANBAL06())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL06(), Fase5ResultadoBD.getTRANBAL06(), cabecero[206]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL07().equals(Fase5ResultadoBD.getTRANBAL07())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL07(), Fase5ResultadoBD.getTRANBAL07(), cabecero[207]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL08().equals(Fase5ResultadoBD.getTRANBAL08())) {
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL08(), Fase5ResultadoBD.getTRANBAL08(), cabecero[208]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL09().equals(Fase5ResultadoBD.getTRANBAL09())) {
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL09(), Fase5ResultadoBD.getTRANBAL09(), cabecero[209]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL10().equals(Fase5ResultadoBD.getTRANBAL10())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL10(), Fase5ResultadoBD.getTRANBAL10(), cabecero[210]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL11().equals(Fase5ResultadoBD.getTRANBAL11())) {
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL11(), Fase5ResultadoBD.getTRANBAL11(), cabecero[211]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL12().equals(Fase5ResultadoBD.getTRANBAL12())) {
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL12(), Fase5ResultadoBD.getTRANBAL12(), cabecero[212]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL13().equals(Fase5ResultadoBD.getTRANBAL13())) {
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL13(), Fase5ResultadoBD.getTRANBAL13(), cabecero[213]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL14().equals(Fase5ResultadoBD.getTRANBAL14())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL14(), Fase5ResultadoBD.getTRANBAL14(), cabecero[214]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL15().equals(Fase5ResultadoBD.getTRANBAL15())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL15(), Fase5ResultadoBD.getTRANBAL15(), cabecero[215]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL16().equals(Fase5ResultadoBD.getTRANBAL16())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL16(), Fase5ResultadoBD.getTRANBAL16(), cabecero[216]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL17().equals(Fase5ResultadoBD.getTRANBAL17())) {
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL17(), Fase5ResultadoBD.getTRANBAL17(), cabecero[217]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL18().equals(Fase5ResultadoBD.getTRANBAL18())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL18(), Fase5ResultadoBD.getTRANBAL18(), cabecero[218]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL19().equals(Fase5ResultadoBD.getTRANBAL19())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL19(), Fase5ResultadoBD.getTRANBAL19(), cabecero[219]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL20().equals(Fase5ResultadoBD.getTRANBAL20())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL20(), Fase5ResultadoBD.getTRANBAL20(), cabecero[220]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL21().equals(Fase5ResultadoBD.getTRANBAL21())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL21(), Fase5ResultadoBD.getTRANBAL21(), cabecero[221]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL22().equals(Fase5ResultadoBD.getTRANBAL22())) {
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL22(), Fase5ResultadoBD.getTRANBAL22(), cabecero[222]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL23().equals(Fase5ResultadoBD.getTRANBAL23())) {
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL23(), Fase5ResultadoBD.getTRANBAL23(), cabecero[223]);}
								if (!Fase5ResultadoArchivoPlano.getTRANBAL24().equals(Fase5ResultadoBD.getTRANBAL24())) {
									reportarError(Fase5ResultadoArchivoPlano.getTRANBAL24(), Fase5ResultadoBD.getTRANBAL24(), cabecero[224]);}
								if (!Fase5ResultadoArchivoPlano.getTRV05().equals(Fase5ResultadoBD.getTRV05())) {
									reportarError(Fase5ResultadoArchivoPlano.getTRV05(), Fase5ResultadoBD.getTRV05(), cabecero[225]);}
								if (!Fase5ResultadoArchivoPlano.getTRV14().equals(Fase5ResultadoBD.getTRV14())) {
									reportarError(Fase5ResultadoArchivoPlano.getTRV14(), Fase5ResultadoBD.getTRV14(), cabecero[226]);}
								if (!Fase5ResultadoArchivoPlano.getTRV17().equals(Fase5ResultadoBD.getTRV17())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRV17(), Fase5ResultadoBD.getTRV17(), cabecero[227]);}
								if (!Fase5ResultadoArchivoPlano.getTRV18().equals(Fase5ResultadoBD.getTRV18())) { 
									reportarError(Fase5ResultadoArchivoPlano.getTRV18(), Fase5ResultadoBD.getTRV18(), cabecero[228]);}
								if (!Fase5ResultadoArchivoPlano.getUL01S().equals(Fase5ResultadoBD.getUL01S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getUL01S(), Fase5ResultadoBD.getUL01S(), cabecero[229]);}
								if (!Fase5ResultadoArchivoPlano.getUL06S().equals(Fase5ResultadoBD.getUL06S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getUL06S(), Fase5ResultadoBD.getUL06S(), cabecero[230]);}
								if (!Fase5ResultadoArchivoPlano.getUL21S().equals(Fase5ResultadoBD.getUL21S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getUL21S(), Fase5ResultadoBD.getUL21S(), cabecero[231]);}
								if (!Fase5ResultadoArchivoPlano.getUL25S().equals(Fase5ResultadoBD.getUL25S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getUL25S(), Fase5ResultadoBD.getUL25S(), cabecero[232]);}
								if (!Fase5ResultadoArchivoPlano.getUL30S().equals(Fase5ResultadoBD.getUL30S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getUL30S(), Fase5ResultadoBD.getUL30S(), cabecero[233]);}
								if (!Fase5ResultadoArchivoPlano.getUL32S().equals(Fase5ResultadoBD.getUL32S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getUL32S(), Fase5ResultadoBD.getUL32S(), cabecero[234]);}
								if (!Fase5ResultadoArchivoPlano.getUS20S().equals(Fase5ResultadoBD.getUS20S())) {
									reportarError(Fase5ResultadoArchivoPlano.getUS20S(), Fase5ResultadoBD.getUS20S(), cabecero[235]);}
								if (!Fase5ResultadoArchivoPlano.getUS25S().equals(Fase5ResultadoBD.getUS25S())) { 
									reportarError(Fase5ResultadoArchivoPlano.getUS25S(), Fase5ResultadoBD.getUS25S(), cabecero[236]);}
								if (!Fase5ResultadoArchivoPlano.getWALSHR07().equals(Fase5ResultadoBD.getWALSHR07())) {
									reportarError(Fase5ResultadoArchivoPlano.getWALSHR07(), Fase5ResultadoBD.getWALSHR07(), cabecero[237]);}
								if (!Fase5ResultadoArchivoPlano.getWD71().equals(Fase5ResultadoBD.getWD71())) {
									reportarError(Fase5ResultadoArchivoPlano.getWD71(), Fase5ResultadoBD.getWD71(), cabecero[238]);}			
								
	
								if (!test) {
									logger.error("Se encontraron errores en la comparacion de datos "
											+ " Consecutivo  " + idTerceroL);
									softAssert.fail("Se encontraron errores en la comparacion de datos  "
											 + " Consecutivo " + idTerceroL);

								}

								else {
									System.out
											.println(linea + " Consecutivo " + idTerceroL);
								}

							} else {

								imprimirReporte("Test_Archivo_",
										"Error en linea--> " + linea + " Consecutivo--> "
												+ Fase5ResultadoArchivoPlano.getSECUENCIA_TERCERO() 
											
												+ " No se genero informacion a la consulta en BD\n",
										true);

							}
						
					} else {
						imprimirReporte("Test_Archivo_", "Error! Numero de campos es diferente al establecido, en la linea--> "
								+ linea + " el archivo tiene --> " + data.split("\\|").length + "\n", true);

						softAssert.fail("Numero de campos es diferente al establecido, en la linea--> " + linea
								+ " el archivo tiene --> " + data.split("\\|").length + "\n");
					}
				}
				
				DataBaseUtils.closeConnection();
				imprimirReporte("Test_Archivo_", "Numero de registros analizados "+(linea-1)
						+	" errores encontrados "+ Errores+"\n", true);
				softAssert.assertAll();
				imprimirReporte("Test_Archivo_", "Prueba fue ejecutada sin errores, movimientos analizados--> " + (linea - 1),
						true);
			}
		 
		}	else {
			DataBaseUtils.closeConnection();
			softAssert.fail("Test de estructura no fue aprobado");
			softAssert.assertAll();
		}
	}

	private void reportarError(String ArchivoResultados, String ArchivoResultadosDb, String parametro) {

		 int resultado1 = Integer.parseInt(ArchivoResultados);
	
		 int resultado2 = Integer.parseInt(ArchivoResultadosDb);
		 int resultadoPatron =(resultado1)-(resultado2);
		 
		String data = linea + "\t"
				+ Fase5ResultadoArchivoPlano.getSECUENCIA_TERCERO()
				
				+ "\t" + parametro + "\t" + ArchivoResultados.replace(".", ",") + "\t"+ ArchivoResultadosDb.replace(".", ",") +"\t"+ resultadoPatron +"\n";
		
		imprimirReporte("Test_Archivo_", data, true);
		//imprimirReporte("Test_Roland_", data, true);
		
		logger.error("Error en la linea--> " + linea 
				+ " IdTercero--> " + Fase5ResultadoArchivoPlano.getSECUENCIA_TERCERO() + " Variable " + parametro + " File--> " + ArchivoResultados
				+ " DB--> " + ArchivoResultadosDb);
		test = false;
		Errores++;
	}


	private void imprimirReporte(String prueba, String data, Boolean escribir) {
		BufferedWriter bw = null;
		FileWriter fw = null;

		try {

			File file = new File(origenFile + prueba+fileName);
			// Si el archivo no existe, se crea!
			if (!file.exists()) {
				file.createNewFile();
			}
			// flag true, indica adjuntar información al archivo.
			fw = new FileWriter(file.getAbsoluteFile(), escribir);
			bw = new BufferedWriter(fw);
			bw.write(data);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				// Cierra instancias de FileWriter y BufferedWriter
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	private void consultarBD(String secuencia) throws Exception {
		listaQueries = ReadSqlFile.getQueriesFromFileByTagName("common.sql", "@FaseCincoCvBatch" );
		queriesResult1 = executedQueries(listaQueries, secuencia );

	}

	private static List<List<List<String>>> executedQueries(List<String> listaQueries, String secuencia ) throws Exception {
		List<List<List<String>>> queriesResult = new ArrayList<List<List<String>>>();
		List<List<String>> dataFromQueriesList = null;
		int queriesNumbers = listaQueries.size();
		for (int iteration = 0; iteration < queriesNumbers; iteration++) {
			DataBaseUtils.getResultSet(listaQueries.get(iteration).replace("[Secuencia]", secuencia));
			dataFromQueriesList = DataBaseUtils.getDataFromResultset();
			queriesResult.add(dataFromQueriesList);

		}
		return queriesResult;
	}

}