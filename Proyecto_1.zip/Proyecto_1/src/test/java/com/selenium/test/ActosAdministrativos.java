package com.selenium.test;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.selenium.database.Conectar;

import oracle.sql.DATE;

@RunWith(Parameterized.class)
public class ActosAdministrativos {
	
	Properties propiedades = new Properties();
    InputStream entrada = null;	
	
	private WebDriver driver;
	private Map<String, Object> vars;
	JavascriptExecutor js;

	//Ubicacion de Elementos


	By usuario = By.xpath("//*[@id=\"username\"]");
	By clave = By.id("password");
	By BotonIngresar = By.id("sId");
	By CheckForzar = By.xpath("//*[@id=\"forcelogin\"]");


	//String nombre_usuario = "90681";
	//String password = "H33std";


	//elementos 2do Formulario

	By BotonConfiguracionAvanzada = By.id("details-button");
	By LinkContinuar = By.id("proceed-link");

	//elementos 3r Formulario

	//By CampoBusqueda = By.id("search-query");
	By CampoBusqueda = By.xpath("//*[@id=\'search-query\']");
	
	  
	//ambiente dev
 	By MiCasaYa = By.xpath("//*[@id=\"id_69\"]/div/a"); 
	//By MiCasaYa = By.xpath("//*[@id=\"id_1\"]/div/a"); 
	 //Ambiente uat 
  //  By MiCasaYa = By.xpath("//*[@id=\'id_18\']/div/a");

	// elementos 4to Formulario
	By ActosAdministrativos = By.xpath("//*[@id=\'terceros:tbody_element\']/tr[4]/td/a"); //*[@id="terceros:tbody_element"]/tr[4]/td/a


	//Elementos 5 formulario Registro
	By IdentificadordeHogar = By.xpath("//*[@id=\'idFamilia\']");//*[@id="idFamilia"]
	By Fecha = By.xpath("//*[@id=\'FechaActo\']"); //*[@id="FechaActo"]
	By NúmerodeActoAdministrativo = By.xpath("//*[@id=\'numActo\']");
	By BotonLimpiar = By.xpath("//*[@id=\'content\']/input[2]");
	By BotonGenerar = By.xpath("//*[@id=\'content\']/input[1]");		 
	By BotonNuevo  = By.xpath("//*[@id='btnNuevo']");
	
	

	//arreglos de la base ded atos 
	@Parameterized.Parameters   

	public static Collection<Object[]> listaTextos() {

		List<Object[]> args = new ArrayList<>();



		try {

			Conectar oracle=new Conectar();
			Connection con;
			con=oracle.conectar();

			//  String sql = "Select * from mcy_hogar ho where ho.id_hogar=3577";
			//  String sql = "Select * from mcy_hogar";
			// String sql = "select Numero_identificacion,nombre from terceros WHERE ROWNUM <= 10";
			String sql = "select id_hogar from mcy_hogar WHERE estado_actual=3 and ROWNUM <= 2";

			Statement statement = con.createStatement();

			ResultSet result = statement.executeQuery(sql);

			//Extraer Data


			while (result.next()) {

				Object[] argumento = new Object[] { 

						result.getString(1),
						//result.getString(2),
						//result.getString(3),
						// result.getString(4),


				};


				args.add(argumento);

			}
		}
		catch (Exception ex) {
			//		 		  // Do nothing ... 
		}
		//		 		  
		return args;
		//
	}


	public static String id_hogar;
	//public static String FECHA;
	//public static String NumeroActoAdministrativo;



	public ActosAdministrativos(String id_hogar) {
		this.id_hogar = id_hogar;
		//this.FECHA = FECHA;
		//this.NumeroActoAdministrativo = NumeroActoAdministrativo;

	}



	@Before
	public void setUp() {

		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\wariela\\eclipse-workspace\\Proyecto_0\\driver\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\jpataco\\eclipse-workspace\\Proyecto_0\\driver\\chromedriver.exe");

		driver = new ChromeDriver();
		js = (JavascriptExecutor) driver;
		vars = new HashMap<String, Object>();
	}
	@After
	public void tearDown() {
		driver.quit();
	}
	@Test

	public void testRegistro() throws InterruptedException {
		
		try {
		 entrada = new  FileInputStream("datos.properties");
		 propiedades.load(entrada); 
		 
		 String url = propiedades.getProperty("url");
		 String usuario1 = propiedades.getProperty("usuario1");	 
		 String password = propiedades.getProperty("password1");
		 String fecha_acto = propiedades.getProperty("fecha_acto");
         String numero_acto = propiedades.getProperty("numero_acto"); 
		 
		System.out.println(id_hogar);
		//System.out.println(FECHA);
		//System.out.println(NumeroActoAdministrativo);

		//driver.get("http://10.1.104.75:9090/sso-auth-server/login");
		//driver.get("https://cifindesa2.asobancaria.com/cifin/idcons.jsp");
		//driver.get("https://cifindesa2.asobancaria.com/cifin/idcons.jsp");
		//driver.get("https://aplicaciones.cifin.co/sso-auth-server/login");

        driver.get(url);
		driver.findElement(usuario).click();
		driver.findElement(usuario).sendKeys(usuario1);
		driver.findElement(clave).click();
		driver.findElement(clave).sendKeys(password);
		driver.findElement(BotonIngresar).click();
		Thread.sleep(3000);
		
		//Forzar login
		Boolean b1 = driver.equals(CheckForzar);	     
		if (b1==true) {
			
			
			driver.findElement(CheckForzar).click();
			Thread.sleep(2000); 
			driver.findElement(usuario).click();
			driver.findElement(usuario).sendKeys(usuario1);
			driver.findElement(clave).click();
			driver.findElement(clave).sendKeys(password);
			driver.findElement(BotonIngresar).click();

		}
		//	2do Formulario/ Conexion no es privada
			driver.findElement(BotonConfiguracionAvanzada).click();
			driver.findElement(LinkContinuar).click();
			Thread.sleep(2000);

			//3er Formulario /menu escoger proyecto 
			driver.findElement(CampoBusqueda).click();
			driver.findElement(CampoBusqueda).sendKeys("Mi Casa Ya");
			driver.findElement(MiCasaYa).click();
			Thread.sleep(8000);

			//4to Formulario /Escoger Opcion Mi Casa Ya.
			driver.findElement(ActosAdministrativos).click();
			Thread.sleep(8000);

			
			driver.findElement(IdentificadordeHogar).click();
			//  driver.findElement(CampoCedula).sendKeys("1037479977");
			//  driver.findElement(CampoCedula).sendKeys(Integer.toString(id_hogar));
			driver.findElement(IdentificadordeHogar).sendKeys(id_hogar);
			//driver.findElement(Fecha).sendKeys("12/11/2020");
			driver.findElement(Fecha).sendKeys(fecha_acto);
			//driver.findElement(NúmerodeActoAdministrativo).sendKeys("44");
			driver.findElement(NúmerodeActoAdministrativo).sendKeys(numero_acto);
			
//			driver.findElement(BotonLimpiar).click();
//			Thread.sleep(10000);
			
			driver.findElement(BotonGenerar).click();
			Thread.sleep(10000);
			
			driver.findElement(BotonNuevo).click();
			Thread.sleep(10000);
			
			//redireccion url
			//driver = Webdriver.chrome();
			//driver.getCurrentUrl(https://cifindesa2.asobancaria.com/cifin/idcons.jsp);
			//driver.navigate();
			//driver.get("https://cifindesa2.asobancaria.com/cifin/idcons.jsp");
			//getCurrentUrl("https://cifindesa2.asobancaria.com/cifin/idcons.jsp");
			//driver.findElement(FechaNacimiento).sendKeys("19/02/1993");

		}  catch (IOException e) {
			 		// TODO Auto-generated catch block
			 		e.printStackTrace();
			 	}
		}
	
	}

