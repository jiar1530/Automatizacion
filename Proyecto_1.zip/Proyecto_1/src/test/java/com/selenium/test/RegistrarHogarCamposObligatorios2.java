package com.selenium.test;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.HashMap;
import java.util.Map;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import com.selenium.database.Conectar;
import com.selenium.database.MainConexionOracle;


@RunWith(Parameterized.class)
public class RegistrarHogarCamposObligatorios2 {
	
	Properties propiedades = new Properties();
    InputStream entrada = null;	
	
 
  private WebDriver driver;
  private Map<String, Object> vars;
  JavascriptExecutor js;
 // public static String Secuencia;
//  public static String Tipo_Identificacion;
 
    
  //Ubicacion de Elementos
 
  
  By usuario = By.xpath("//*[@id=\"username\"]");
  By clave = By.id("password");
  By BotonIngresar = By.id("sId");
  By CheckForzar = By.xpath("//*[@id=\"forcelogin\"]");
  
  
  //String nombre_usuario = "90681";
  //String password = "H33std";
  
  //elementos 2do Formulario
  
  By BotonConfiguracionAvanzada = By.id("details-button");
  By LinkContinuar = By.id("proceed-link");

  //elementos 3r Formulario
  
  By CampoBusqueda = By.id("search-query");
  By MiCasaYa = By.xpath("//*[@id=\"id_69\"]/div/a");

  //By MiCasaYa = By.xpath("//*[@id=\"id_18\"]/div/a");

  // elementos 4to Formulario
  By RegistrarHogar = By.xpath("//*[@id=\"terceros:tbody_element\"]/tr[2]/td/a");
  
  //Elementos 5 formulario Registro
  By BotonAdicionarIntegrante = By.xpath("//*[@id=\"addMemberButton\"]");
  By DesplegableTipoDocumento = By.xpath("//*[@id=\"tercerosLista:0:identificacion\"]");
  By OpcionCedula = By.xpath("//*[@id=\"tercerosLista:0:identificacion\"]/option[2]");
  By CampoCedula = By.xpath("//*[@id=\"tercerosLista:0:numIdentificacion\"]");
  By DesplegableDepartamento = By.xpath("//*[@id=\"form1:departamento\"]");
  By DesplegableMunicipio = By.xpath("//*[@id=\"form1:municipio\"]");
  By DesplegableRango = By.xpath("//*[@id=\"form1:rango\"]");
  By DesplegableTipoDeVivienda = By.xpath("//*[@id=\"form1:tipoVivienda\"]");
  By BotonValidar = By.xpath("//*[@id=\"validarButton\"]");		 
  By BotonNuevo = By.xpath("//*[@id=\"form1:botonNuevo\"]");
  
  
   @Parameterized.Parameters   
  
   public static Collection<Object[]> listaTextos() {
		  
	   List<Object[]> args = new ArrayList<>();
	     
	   

	 	 try {
	 		  
	 		Conectar oracle=new Conectar();
	 	 	Connection con;
	 	 	con=oracle.conectar();
	 		  
	 	     //  String sql = "Select * from mcy_hogar ho where ho.id_hogar=3577";
 		    //  String sql = "Select * from mcy_hogar";
 		    // String sql = "select Numero_identificacion,nombre from terceros WHERE ROWNUM <= 10";
	 	 	//String sql = "select Numero_identificacion,nombre, lugar_expedicion from terceros WHERE ROWNUM <= 10";
	 	 	String sql = "select a.Numero_identificacion,a.nombre,a.lugar_expedicion,b.nombre_departamento,a.fecha_nacimiento from terceros a,departamentos b where b.codigo_departamento = a.departamento_expedicion and ROWNUM <= 2"; 
	 	 	
	 		  Statement statement = con.createStatement();
	 		  
	 		  ResultSet result = statement.executeQuery(sql);
	 		
	 		//Extraer Data
	 		   
	 		 
	 		  while (result.next()) {
	 			  
	 			  Object[] argumento = new Object[] { 
	 					  
	 					   result.getString(1),
	 					   result.getString(2),
	 					   result.getString(3),
	 					   result.getString(4),
	 					   result.getString(5),
	 					 
	 			  };
	 		 // }  
	 			  
	 			    args.add(argumento);
	 			//    result.close();
	 			//    statement.close();
	 		//	 System.out.println(repo);
	 		  }
	 		}
	 	catch (Exception ex) {
//	 		  // Do nothing ... 
	 	}
//	 		  
	 	return args;
//
	 	}
	 	   
 
//   public static String Cedula;
//   public static String Tipo_Identificacion;
//   public static String Municipio;
////   public static String Nombre;
   public static String Cedula;
   public static String Nombre;
   public static String Lugar_expedicion;
   public static String Nombre_Departamento;
   public static String Fecha_Nacimiento1;
   
   
   //public RegistrarHogar_1(String Secuencia, String Tipo_Identificacion,String Cedula,String Nombre) {
   public RegistrarHogarCamposObligatorios2 (String Cedula, String Nombre, String Lugar_expedicion,String Nombre_Departamento, String Fecha_Nacimiento1) {
	   this.Cedula = Cedula;
	   this.Nombre = Nombre;
	   this.Lugar_expedicion = Lugar_expedicion;
	   this.Nombre_Departamento = Nombre_Departamento;
	   this.Fecha_Nacimiento1 = Fecha_Nacimiento1;
   }
   
   
      
  
 
  @Before
  public void setUp() throws InterruptedException, FileNotFoundException {
	  
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\jpataco\\eclipse-workspace\\Proyecto_0\\driver\\chromedriver.exe");
	
    driver = new ChromeDriver();
    js = (JavascriptExecutor) driver;
    vars = new HashMap<String, Object>();
    
    try {
		entrada = new FileInputStream("datos.properties");
		 propiedades.load(entrada); 
		 
		 String url = propiedades.getProperty("url");
		 String usuario1 = propiedades.getProperty("usuario1");	 
		 String password = propiedades.getProperty("password1");
		 
		 driver.get(url);
	     driver.findElement(usuario).click();
	     driver.findElement(usuario).sendKeys(usuario1);
	     driver.findElement(clave).click();
	     driver.findElement(clave).sendKeys(password);
	     driver.findElement(BotonIngresar).click();
	     Thread.sleep(2000);
	    
	     //Forzar login
		  
	     Boolean b1 = driver.equals(CheckForzar);
	     System.out.println("CheckForzar :" + b1);
	  
	      if (b1==true) {

	        driver.findElement(CheckForzar).click();
	        Thread.sleep(2000); 
	        driver.findElement(usuario).click();
	        driver.findElement(usuario).sendKeys(usuario1);
	        driver.findElement(clave).click();
	        driver.findElement(clave).sendKeys(password);
	        driver.findElement(BotonIngresar).click();
	        
	      }
	      
	    
	    //2do Formulario/ Conexion no es privada
	    driver.findElement(BotonConfiguracionAvanzada).click();
	    Thread.sleep(2000);
	    driver.findElement(LinkContinuar).click();
	    Thread.sleep(2000);

	    //3er Formulario /menu escoger proyecto 
	    driver.findElement(CampoBusqueda).click();
	    driver.findElement(CampoBusqueda).sendKeys("Mi Casa Ya");
	    driver.findElement(MiCasaYa).click();
	    Thread.sleep(2000);
	    
	    //4to Formulario /Escoger Opcion Mi Casa Ya.
	    driver.findElement(RegistrarHogar).click();
	    Thread.sleep(2000);
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

    
    
  }
  @After
  public void tearDown() {
    driver.quit();
  }
  @Test
  
  public void testRegistro() throws InterruptedException {
	  
	  try {
			entrada = new FileInputStream("datos.properties");
			 propiedades.load(entrada); 
			 
			 String url = propiedades.getProperty("url");
			 String usuario1 = propiedades.getProperty("usuario1");	 
			 String password = propiedades.getProperty("password1");
	  
			 System.out.println(Cedula);
			 System.out.println(Nombre);
			 System.out.println(Lugar_expedicion);
		     System.out.println(Nombre_Departamento); 
		     System.out.println(Fecha_Nacimiento1);
  
     //driver.get("http://10.1.104.75:9090/sso-auth-server/login");
	 	    
     
    
    //5to Formulario //Formulario Registro Hogar
     driver.findElement(BotonAdicionarIntegrante).click();
     Thread.sleep(3000);
     driver.findElement(DesplegableTipoDocumento).click();
     Thread.sleep(2000);
     driver.findElement(OpcionCedula).click();
   //  driver.findElement(CampoCedula).sendKeys("1037479977");
   //  driver.findElement(CampoCedula).sendKeys(Integer.toString(id_hogar));
     driver.findElement(CampoCedula).sendKeys(Cedula);
   //  Thread.sleep(2000);
   // driver.findElement(BotonAdicionarIntegrante).click();
     
     js.executeScript("window.scrollBy(0,1000)");
     Thread.sleep(3000);
     driver.findElement(DesplegableDepartamento).click();
    // driver.findElement(DesplegableDepartamento).sendKeys("BOGOTA DISTRITO C.A");
     driver.findElement(DesplegableDepartamento).sendKeys(Nombre_Departamento);
     driver.findElement(DesplegableDepartamento).click();
     Thread.sleep(3000);
     driver.findElement(DesplegableMunicipio).click();
     //driver.findElement(DesplegableMunicipio).sendKeys("BOGOTA");
     driver.findElement(DesplegableMunicipio).sendKeys(Lugar_expedicion);
     driver.findElement(DesplegableMunicipio).click();
     Thread.sleep(2000);
     driver.findElement(DesplegableRango).click();
     driver.findElement(DesplegableRango).click();
     driver.findElement(DesplegableRango).sendKeys("3-Hasta 2 smmlv");
     driver.findElement(DesplegableRango).click();
     Thread.sleep(2000);
     driver.findElement(DesplegableTipoDeVivienda).click();
     driver.findElement(DesplegableTipoDeVivienda).sendKeys("VIS");
     Thread.sleep(2000);
     driver.findElement(DesplegableTipoDeVivienda).click();
     Thread.sleep(3000);
     driver.findElement(BotonValidar).click();
     Thread.sleep(3000);
     driver.findElement(BotonNuevo).click();
     Thread.sleep(5000);
     
     
	  } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }
}