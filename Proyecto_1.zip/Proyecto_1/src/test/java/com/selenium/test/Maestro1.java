package com.selenium.test;

import java.sql.Connection;
import java.sql.SQLException;
import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses ({RegistrarHogarCamposObligatorios.class, RegistrarHogarCamposNoObligatorios2.class, MarcarHogarObligatorios.class,
	MarcarHogarCamposNoObligatorios.class,MarcarHogarObligatorios.class,Renuncias.class,ActosAdministrativos.class})

public class Maestro1 {}
