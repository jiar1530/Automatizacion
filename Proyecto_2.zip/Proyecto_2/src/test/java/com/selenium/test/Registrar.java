package com.selenium.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
//import org.apache.commons.io.FileUtils;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestRule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.Assert.*;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.reporters.Files;
import org.apache.commons.io.FileUtils;

import com.selenium.database.Conectar;


public class Registrar {


	private WebDriver driver;
	private Map<String, Object> vars;
	JavascriptExecutor js;
	
	@Before
	public void setUp() throws Exception {
	
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\jpataco\\eclipse-workspace\\Proyecto_0\\driver\\chromedriver.exe");
		
	    driver = new ChromeDriver();
	    js = (JavascriptExecutor) driver;
	    vars = new HashMap<String, Object>();
	  
	}
	
//	public String getDate() {
//		  DateFormat dateFormat = new SimpleDateFormat("dd-MM-yy");
//		//DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
//		
//		Date date = new Date();
//		//return dateFormat.format(date);	
//		
//	}
	
	public static String getCurrentTimeStamp() {
	       SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//dd/MM/yyyy
	       Date now = new Date();
	       String strDate = sdfDate.format(now);
	       return strDate;
	}
	
	@Rule
	public TestRule watcher = new TestWatcher() {
      @Override
        protected void  failed(Throwable throwable, Description description) {
    	  File screenshotFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
    	   try {
    		 // FileUtils.copyFile(screenshotFile, new File ("error_"+description.getMethodName()+getDate()+".jpg")); 
    		  FileUtils.copyFile(screenshotFile, new File ("error_"+description.getMethodName()+getCurrentTimeStamp()+".jpg")); 
    		     
    	   	} catch (Exception e) {
    	   	   e.printStackTrace();
    	   	}
    	   }
      	  @Override
      	  protected void finished(Description description) {
            driver.quit();
      	  }
      };
	
	@Test
	public void test () {
		  driver.get("https://www.google.com");
		  WebElement searchBox = driver.findElement(By.name("q"));
		  searchBox.clear();
		  searchBox.submit();
		  File screenshotFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		//  FileUtils.copyFile(screenshotFile, new File ("error_"+getCurrentTimeStamp()+".jpg"));
		  
		  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		  
		  assertEquals ("Esto ocasionara un error", driver.getTitle());
		  
		}
	
	}
	
	

